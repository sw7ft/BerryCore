# Virtual Keyboard – App Builder Context

Reusable virtual keyboard component. ES5-only, single script file.

## Path

`tools/virtual-keyboard/keyboard.js`  
`tools/virtual-keyboard/index.html` (demo)

## Inclusion

```html
<script src="../virtual-keyboard/keyboard.js"></script>
```

Auto-inits. Or call `VirtualKeyboard.init()` after DOM ready.

## Layout

| Row | Keys |
|-----|------|
| 1 | ` 1 2 3 4 5 6 7 8 9 0 - = [Backspace] |
| 2 | [Tab] q w e r t y u i o p [ ] \ |
| 3 | [Caps] a s d f g h j k l ; ' [Enter] |
| 4 | [Shift] z x c v b n m , . / [Shift] |
| 5 | [Space] |

Shift toggles symbols/uppercase. Caps Lock toggles uppercase.

## Key Functions

| Function | Purpose |
|----------|---------|
| `insertText(str)` | Insert into document.activeElement (textarea/input/contenteditable) |
| `onKeyClick(key)` | Handle key press; special keys: {bksp}, {tab}, {enter}, {space}, {shift}, {caps} |
| `renderKeys()` | Rebuild key layout (shift/caps state) |
| `createKeyboard()` | Build DOM; append to body |
| `createTrigger()` | Build ⌨ button; append to body |

## DOM

- `#virtual-keyboard-root`: Container; `.vk-open` shows keyboard
- `.vk-trigger`: Button (bottom right)
- `.vk-keys`: Key rows

## ES5

- `var`, `function`, string concat
- `createEvent` / `initEvent` for input events
- `createEvent("KeyboardEvent")` / `initKeyboardEvent` for backspace in contenteditable
