# Drawing Board – App Builder Context

Pencil-style diagram/whiteboard app for BB10 browser. Single-file HTML, ES5-only, no build step.

## Overview

- **Path:** `tools/drawing-board/index.html`
- **Canvas:** 1440×1440 px
- **Target:** BB10 WebKit (touch + mouse)
- **Storage:** localStorage + JSON file export/import

## Shape Types

| Type   | Properties                          | Description                    |
|--------|-------------------------------------|--------------------------------|
| `rect` | id, x, y, w, h, text, fillColor, textSize | Rectangle with optional text   |
| `line` | id, type, x1, y1, x2, y2           | Line segment                   |
| `text` | id, type, x, y, text, fontSize      | Standalone canvas text         |

Rectangles default: `fillColor: "#fafafa"`, `textSize: 17`. Lines and text have no fill.

## Modes

| Mode    | Behavior                                                                 |
|---------|---------------------------------------------------------------------------|
| `rect`  | Drag to create rectangles. Fill color from Rectangle ▾ dropdown.          |
| `line`  | Drag to create lines.                                                     |
| `text`  | Two submodes: `inbox` (edit rect text) or `canvas` (add/edit canvas text) |
| `select`| Click to select, drag to move, drag handles to resize. Delete/Backspace.  |

## Toolbar Structure

```
[Rectangle ▾] [Text ▾] [Select] [Copy] [Paste] [−] [+] [☰]
```

- **Rectangle ▾:** Rectangle, Lines, Fill colors (White, Yellow, Light blue, etc.)
- **Text ▾:** In box, On canvas
- **Select:** Select mode; double-click rect or canvas text to edit
- **☰:** Save, Open, Clear, Fullscreen

## Key Functions

| Function          | Purpose                                      |
|-------------------|----------------------------------------------|
| `getShapeAt(x,y)` | Hit test; returns shape under point           |
| `getHandleAt(x,y)`| Hit test for resize handles (select mode)    |
| `redraw()`        | Clear canvas, draw shapes, handles, preview  |
| `scheduleRedraw()`| requestAnimationFrame-batched redraw         |
| `openTextEdit(s)` | Open editor for canvas text                  |
| `openBoxTextEdit(s)` | Open editor for rect text                 |
| `doSave()`        | Save to localStorage + download JSON        |
| `doLoad()`        | Load from localStorage on init              |
| `setData(data)`   | Load shapes from JSON; used by Open + init   |

## Event Flow

- **onDown:** Mode-specific handling; double-tap detection for edit
- **onMove:** Drag (move/resize), or draw preview (rect/line)
- **onUp:** Finish shape creation, clear drag state
- **onDblClick:** Edit canvas text or box text in Select mode

Touch: `touchstart`/`touchmove`/`touchend` + `changedTouches` for end positions. Document listeners for touchend/touchcancel so gestures end outside canvas.

## Storage Format

```json
{
  "shapes": [...],
  "zoom": 1,
  "version": 1
}
```

Shapes: `{ id, type?, x, y, w?, h?, text?, fillColor?, textSize?, x1?, y1?, x2?, y2?, fontSize? }`
- Rect: x, y, w, h, text, fillColor, textSize
- Line: type:"line", x1, y1, x2, y2
- Text: type:"text", x, y, text, fontSize

## ES5 Constraints

- `var` only (no `let`/`const`)
- `function () {}` (no arrows)
- String concatenation (no template literals)
- No classes
- `requestAnimationFrame` with `webkit` prefix and `setTimeout` fallback

## Constants

- `BOARD_W`, `BOARD_H`: 1440
- `HANDLE_SIZE`: 22
- `STORAGE_KEY`: "drawing-board-data"
- `ZOOM_MIN`: 0.25, `ZOOM_MAX`: 4, `ZOOM_STEP`: 1.25

## UI Elements

- `#text-input-wrap`: Modal for text input; `#font-row` (canvas text size), `#box-font-row` (box text size)
- `#file-input`: Hidden file input for Open
- `#save-toast`: "Saved!" feedback
