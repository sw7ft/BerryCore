# Code Editor – BB10

Browser-based code editor with syntax highlighting. ES5-only, no build step.

## Features

- **Edit** – Write code in a textarea
- **Preview** – Syntax-highlighted output
- **Split** – Edit and preview side by side
- **Save** – localStorage + download .js/.json/.html/.css/.sh
- **Open** – Load from file; language auto-detected
- **New** / **Clear** – Start fresh
- **☰ Menu** – Language selector (JS, Python, JSON, HTML, CSS, Shell, Plain) + code snippets
- **Indentation** – Tab inserts 4 spaces; Enter preserves/copies indent; Python adds indent after `:`

## Languages

| Language | Extensions |
|----------|------------|
| JavaScript | .js |
| Python | .py |
| JSON | .json |
| HTML | .html, .htm |
| CSS | .css |
| Shell | .sh |
| Plain | .txt |

## Usage

```bash
# Serve on port 8766 (drawing board 8765, markdown 8766)
python3 -m http.server 8767
# Open http://localhost:8767/tools/code-editor/
```

## BB10 / ES5

- Pure ES5, no dependencies
- Touch and mouse supported
- Works in BB10 WebKit browser
