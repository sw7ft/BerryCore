# Berry Bot — Command-Line Teaching Assistant

Non-AI teaching assistant for Linux, QNX, bash, and BerryCore commands. Knowledge base in SQLite, invoked as `bot`.

## Overview

| Item | Value |
|------|-------|
| **Port** | berrybot |
| **Binary** | bin/bot |
| **Data** | share/berrybot/berrybot.sqlite |
| **Source** | data/*.json (build with build_db.py) |

## Usage

```bash
bot [query]           # Search (e.g. bot grep, bot how to search)
bot <command>        # Full info for command (e.g. bot grep)
bot lessons          # List lessons
bot lesson <slug>    # Show lesson (e.g. bot lesson bash-basics)
bot help             # Help
```

## Adding Content

1. Edit `data/commands.json` — add commands with name, category, description, syntax, keywords, examples
2. Edit `data/lessons.json` — add lessons with title, slug, level, summary, content
3. Run `python3 build_db.py` to rebuild berrybot.sqlite
4. Rebuild: `./build-bot.sh`

### commands.json format

```json
{
  "name": "grep",
  "category": "linux",
  "description": "Search for patterns in files.",
  "syntax": "grep [OPTIONS] PATTERN [FILE...]",
  "man_ref": "grep(1)",
  "keywords": ["search", "find", "pattern"],
  "examples": [
    {"example": "grep 'error' log.txt", "explanation": "Find lines containing error"}
  ]
}
```

Categories: `linux`, `qnx`, `bash`, `berrycore`

### lessons.json format

```json
{
  "title": "Bash Basics",
  "slug": "bash-basics",
  "level": "beginner",
  "summary": "Essential bash concepts.",
  "content": "# Bash Basics\n\n...",
  "ord": 1
}
```

## Build

```bash
./build-bot.sh
```

Requires: SQLite amalgamation (sqlite3.c, sqlite3.h) in directory. Download from https://sqlite.org/download.html if missing.

## Data Path

Bot looks for berrybot.sqlite in:
1. `$BERRYBOT_DATA/berrybot.sqlite`
2. `./berrybot.sqlite`
3. `./share/berrybot/berrybot.sqlite`
4. `/accounts/1000/shared/misc/share/berrybot/berrybot.sqlite`
