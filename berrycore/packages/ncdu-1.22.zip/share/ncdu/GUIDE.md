# ncdu 1.22 — BB10 QNX port

Cross-compiled **[ncdu](https://dev.yorhel.nl/ncdu)** (NCurses Disk Usage) for **arm-blackberry-qnx8eabi**.

Interactive `du` — drill into folders, see what's eating space, delete from the UI.

## Quick build

```bash
cd /root/ports/ncdu
bash build-ncdu.sh
bash build-berrycore-port.sh   # → /root/ports/ncdu-bb10-1.22.tgz
```

## Deploy (from Linux)

```bash
cd /root/ports/ncdu/output/accounts/1000/shared/misc
tar cf - ncdu | ssh passport 'mkdir -p /accounts/1000/shared/misc && cd /accounts/1000/shared/misc && tar xf -'
```

## On device

```sh
export PATH=/accounts/1000/shared/misc/ncdu/bin:$PATH
export TERM=xterm-256color

ncdu --version
ncdu /accounts/1000/r          # SD card — use Term49 or ssh -t
ncdu /accounts/1000/shared/misc
```

### Keys (in TUI)

| Key | Action |
|-----|--------|
| ↑↓ | Move |
| Enter | Enter directory |
| d | Delete highlighted item |
| n | Sort by name |
| s | Sort by size |
| C | Sort by items |
| g | Show % graph |
| q | Quit |

### Non-interactive scan (works over plain SSH)

```sh
ncdu -o /var/tmp/scan.json /path/to/scan
ncdu -f /var/tmp/scan.json     # browse saved scan later (needs TTY)
```

## Runtime libraries

- `libncursesw.so.1` (system)
- `libsocket.so.3`, `libc.so.3`

Same stack as zsh 5.9 — no extra BerryCore libs.

## QNX notes

| Issue | Fix |
|-------|-----|
| Linker wants `-ltinfo` | Build with `LIBS="-lncursesw"` |
| `/tmp` unreliable | Use `/var/tmp` for `-o` exports |
| TUI needs TTY | Term49 or `ssh -t passport` |

## Why 1.22 not 2.x?

ncdu 2.x is **Zig** — no ARMv7 QNX target. The **1.22 C LTS** branch is maintained and ports cleanly.
