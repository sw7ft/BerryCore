/**
 * VoiceAgent - BB10 Voice Assistant Frontend
 * ES5 compatible - BB10 WebKit with WebRTC enabled
 *
 * Recording strategy (in order of preference):
 *   1. getUserMedia + MediaRecorder (if both available)
 *   2. getUserMedia + AudioContext + ScriptProcessorNode
 *   3. HTML5 <input type="file" accept="audio/*" capture> (native recorder)
 *   4. Server-side recording (waverec / ffmpeg on device)
 */

/* -------------------------------------------------------------------
   State
   ------------------------------------------------------------------- */

var isRecording = false;
var isProcessing = false;
var currentAudio = null;
var recordingMode = 'none';

var canMediaRecorder = false;
var canWebAudio = false;
var hasGetUserMedia = false;

/* MediaRecorder state */
var mediaRecorder = null;
var mediaChunks = [];

/* Web Audio recording state */
var audioContext = null;
var audioStream = null;
var scriptNode = null;
var sourceNode = null;
var recordedBuffers = [];
var recordedLength = 0;

/* -------------------------------------------------------------------
   XHR helpers (ES5, replaces fetch)
   ------------------------------------------------------------------- */

function xhr(method, url, data, contentType, callback) {
    var req = new XMLHttpRequest();
    req.open(method, url, true);
    if (contentType) req.setRequestHeader('Content-Type', contentType);
    req.onreadystatechange = function() {
        if (req.readyState !== 4) return;
        var resp = null;
        try { resp = JSON.parse(req.responseText); } catch(e) {}
        if (req.status >= 200 && req.status < 300) {
            callback(null, resp);
        } else {
            callback((resp && resp.error) ? resp.error : ('HTTP ' + req.status), resp);
        }
    };
    req.onerror = function() { callback('Network error', null); };
    req.send(data || null);
}

function xhrSendBlob(url, blob, callback) {
    var req = new XMLHttpRequest();
    req.open('POST', url, true);
    req.setRequestHeader('Content-Type', blob.type || 'audio/wav');
    req.onreadystatechange = function() {
        if (req.readyState !== 4) return;
        var resp = null;
        try { resp = JSON.parse(req.responseText); } catch(e) {}
        if (req.status >= 200 && req.status < 300) {
            callback(null, resp);
        } else {
            callback((resp && resp.error) ? resp.error : ('HTTP ' + req.status), resp);
        }
    };
    req.onerror = function() { callback('Network error', null); };
    req.send(blob);
}

/* Upload a File object (from <input type="file">) */
function xhrSendFile(url, file, callback) {
    var req = new XMLHttpRequest();
    req.open('POST', url, true);
    /* Send the original file type so server knows the format */
    req.setRequestHeader('Content-Type', file.type || 'audio/wav');
    req.onreadystatechange = function() {
        if (req.readyState !== 4) return;
        var resp = null;
        try { resp = JSON.parse(req.responseText); } catch(e) {}
        if (req.status >= 200 && req.status < 300) {
            callback(null, resp);
        } else {
            callback((resp && resp.error) ? resp.error : ('HTTP ' + req.status), resp);
        }
    };
    req.onerror = function() { callback('Network error', null); };
    req.send(file);
}

function log(msg) {
    if (typeof console !== 'undefined' && console.log) {
        console.log('[VoiceAgent] ' + msg);
    }
}

/* -------------------------------------------------------------------
   Initialization
   ------------------------------------------------------------------- */

if (document.addEventListener) {
    document.addEventListener('DOMContentLoaded', init, false);
} else {
    window.onload = init;
}

function init() {
    checkConfig();
    detectCapabilities();

    var textInput = document.getElementById('text-input');
    if (textInput) {
        textInput.onkeydown = function(e) {
            var key = e.keyCode || e.which;
            if (key === 13) {
                if (e.preventDefault) e.preventDefault();
                sendText();
            }
        };
    }
}

/* -------------------------------------------------------------------
   Capability Detection
   ------------------------------------------------------------------- */

function getGetUserMedia() {
    var gum = navigator.webkitGetUserMedia || navigator.getUserMedia || navigator.mozGetUserMedia;
    if (gum) {
        return function(constraints, onSuccess, onError) {
            gum.call(navigator, constraints, onSuccess, onError);
        };
    }
    if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        return function(constraints, onSuccess, onError) {
            navigator.mediaDevices.getUserMedia(constraints).then(onSuccess, onError);
        };
    }
    return null;
}

function tryCreateAudioContext() {
    var ac = null;
    try { if (window.AudioContext) ac = new window.AudioContext(); } catch(e) {}
    if (ac) return ac;
    try { if (window.webkitAudioContext) ac = new window.webkitAudioContext(); } catch(e) {}
    if (ac) return ac;
    try { ac = new AudioContext(); } catch(e) {}
    if (ac) return ac;
    try { ac = new webkitAudioContext(); } catch(e) {}
    return ac;
}

function detectCapabilities() {
    var gum = getGetUserMedia();
    hasGetUserMedia = !!gum;

    var gumType = 'none';
    if (navigator.webkitGetUserMedia) gumType = 'webkitGetUserMedia';
    else if (navigator.getUserMedia) gumType = 'getUserMedia';
    else if (navigator.mozGetUserMedia) gumType = 'mozGetUserMedia';
    else if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) gumType = 'mediaDevices';

    var mrType = 'none';
    if (window.MediaRecorder) mrType = 'MediaRecorder';
    else if (window.webkitMediaRecorder) mrType = 'webkitMediaRecorder';

    var acType = 'none';
    var testAC = tryCreateAudioContext();
    if (testAC) {
        acType = testAC.constructor.name || 'AudioContext';
        if (testAC.close) try { testAC.close(); } catch(e) {}
    }

    var MR = window.MediaRecorder || window.webkitMediaRecorder;
    canMediaRecorder = hasGetUserMedia && !!MR;
    canWebAudio = hasGetUserMedia && !!testAC;

    log('=== Capability Detection ===');
    log('  getUserMedia: ' + gumType);
    log('  MediaRecorder: ' + mrType);
    log('  AudioContext: ' + acType);
    log('  userAgent: ' + navigator.userAgent);
    log('  canMediaRecorder: ' + canMediaRecorder);
    log('  canWebAudio: ' + canWebAudio);
    log('  hasGetUserMedia: ' + hasGetUserMedia);

    if (canMediaRecorder) {
        log('  -> Primary: MediaRecorder');
    } else if (canWebAudio) {
        log('  -> Primary: WebAudio ScriptProcessor');
    } else {
        log('  -> Primary: Native audio capture (<input capture>) + server fallback');
    }

    var label = document.getElementById('mic-label');
    if (label) label.innerHTML = 'Tap to speak';
}

/* -------------------------------------------------------------------
   classList helpers
   ------------------------------------------------------------------- */

function addClass(el, cls) {
    if (!el) return;
    if (el.classList) { el.classList.add(cls); }
    else if ((' ' + el.className + ' ').indexOf(' ' + cls + ' ') === -1) {
        el.className += ' ' + cls;
    }
}

function removeClass(el, cls) {
    if (!el) return;
    if (el.classList) { el.classList.remove(cls); }
    else {
        el.className = el.className.replace(
            new RegExp('(^|\\s)' + cls + '(\\s|$)', 'g'), ' '
        ).replace(/\s+/g, ' ').replace(/^\s|\s$/g, '');
    }
}

/* -------------------------------------------------------------------
   API Key Setup / Config
   ------------------------------------------------------------------- */

function saveApiKey() {
    var input = document.getElementById('api-key-input');
    var errEl = document.getElementById('setup-error');
    var key = input ? input.value.replace(/^\s+|\s+$/g, '') : '';
    if (!key) { showSetupError('Please enter your OpenAI API key'); return; }
    if (key.length < 10) { showSetupError("That doesn't look like a valid API key"); return; }
    addClass(errEl, 'hidden');
    xhr('POST', '/api/config', JSON.stringify({ openai_api_key: key }), 'application/json', function(err, data) {
        if (!err && data && data.success) { showScreen('chat'); }
        else { showSetupError(err || 'Failed to save'); }
    });
}

function showSetupError(msg) {
    var el = document.getElementById('setup-error');
    if (el) { el.innerHTML = msg; removeClass(el, 'hidden'); }
}

function checkConfig() {
    xhr('GET', '/api/config', null, null, function(err, cfg) {
        if (!err && cfg && cfg.api_key_set) {
            showScreen('chat');
            loadHistory();
        } else {
            showScreen('setup');
        }
    });
}

function showScreen(name) {
    var screens = document.querySelectorAll('.screen');
    for (var i = 0; i < screens.length; i++) {
        screens[i].className = screens[i].className.replace(' hidden', '') + ' hidden';
    }
    var el = document.getElementById(name + '-screen');
    if (el) el.className = el.className.replace(' hidden', '');
}

/* -------------------------------------------------------------------
   WAV Encoder (pure JavaScript, ES5)
   ------------------------------------------------------------------- */

function encodeWAV(samples, rate) {
    var numSamples = samples.length;
    var buffer = new ArrayBuffer(44 + numSamples * 2);
    var view = new DataView(buffer);
    writeString(view, 0, 'RIFF');
    view.setUint32(4, 36 + numSamples * 2, true);
    writeString(view, 8, 'WAVE');
    writeString(view, 12, 'fmt ');
    view.setUint32(16, 16, true);
    view.setUint16(20, 1, true);
    view.setUint16(22, 1, true);
    view.setUint32(24, rate, true);
    view.setUint32(28, rate * 2, true);
    view.setUint16(32, 2, true);
    view.setUint16(34, 16, true);
    writeString(view, 36, 'data');
    view.setUint32(40, numSamples * 2, true);
    var offset = 44;
    for (var i = 0; i < numSamples; i++) {
        var s = Math.max(-1, Math.min(1, samples[i]));
        view.setInt16(offset, s < 0 ? s * 0x8000 : s * 0x7FFF, true);
        offset += 2;
    }
    return new Blob([view], { type: 'audio/wav' });
}

function writeString(view, offset, str) {
    for (var i = 0; i < str.length; i++) view.setUint8(offset + i, str.charCodeAt(i));
}

function flattenBuffers(buffers, totalLength) {
    var result = new Float32Array(totalLength);
    var off = 0;
    for (var i = 0; i < buffers.length; i++) { result.set(buffers[i], off); off += buffers[i].length; }
    return result;
}

function downsample(buffer, fromRate, toRate) {
    if (fromRate === toRate) return buffer;
    var ratio = fromRate / toRate;
    var len = Math.round(buffer.length / ratio);
    var result = new Float32Array(len);
    for (var i = 0; i < len; i++) { result[i] = buffer[Math.round(i * ratio)] || 0; }
    return result;
}

/* ===================================================================
   RECORDING
   =================================================================== */

var lastToggleTime = 0;

function toggleRecording() {
    var now = new Date().getTime();
    if (now - lastToggleTime < 500) return;
    lastToggleTime = now;
    if (isProcessing) return;

    if (isRecording) {
        if (recordingMode === 'mediarecorder') stopMediaRecorderRec();
        else if (recordingMode === 'webaudio') stopWebAudioRec();
        else if (recordingMode === 'server') {
            isRecording = false;
            setRecordingUI(false);
            stopServerRecording();
        }
    } else {
        startRecording();
    }
}

function startRecording() {
    if (isProcessing || isRecording) return;

    if (canMediaRecorder) {
        log('Trying MediaRecorder...');
        startMediaRecorderRec();
    } else if (canWebAudio) {
        log('Trying WebAudio...');
        startWebAudioRec();
    } else if (hasGetUserMedia) {
        /*
         * We have getUserMedia (WebRTC) but no AudioContext / MediaRecorder
         * to process the stream. Call getUserMedia anyway to:
         *   1. Trigger the BB10 browser mic permission prompt
         *   2. Confirm mic access works
         * Then hand off to native capture or server recording.
         */
        log('Requesting mic permission via getUserMedia...');
        requestMicPermission();
    } else {
        log('No getUserMedia. Trying native capture...');
        triggerNativeCapture();
    }
}

/**
 * Call getUserMedia to trigger the browser permission prompt.
 * Once granted, release the stream and proceed to recording.
 */
function requestMicPermission() {
    var gum = getGetUserMedia();
    setMicLabel('Requesting mic permission...');

    gum({ audio: true },
        function onGranted(stream) {
            log('Mic permission GRANTED');
            /* We got the stream but can't process it without AudioContext.
               Release it and proceed to native capture / server recording. */
            stopStream(stream);
            triggerNativeCapture();
        },
        function onDenied(err) {
            var msg = (err && err.name) ? err.name : String(err);
            log('Mic permission denied: ' + msg);
            if (msg === 'PermissionDeniedError' || msg === 'NotAllowedError') {
                showMicError('Mic permission denied. Please allow and try again.');
            } else {
                /* Permission might have failed for other reasons, try native anyway */
                log('getUserMedia failed (' + msg + '), trying native capture...');
                triggerNativeCapture();
            }
        }
    );
}

/* -------------------------------------------------------------------
   Helpers
   ------------------------------------------------------------------- */

function stopStream(stream) {
    if (!stream) return;
    try {
        if (stream.getTracks) {
            var t = stream.getTracks();
            for (var i = 0; i < t.length; i++) t[i].stop();
        } else if (stream.stop) stream.stop();
    } catch(e) {}
}

function setRecordingUI(recording) {
    var micBtn = document.getElementById('mic-btn');
    var micLabel = document.getElementById('mic-label');
    if (recording) {
        addClass(micBtn, 'recording');
        if (micLabel) {
            micLabel.innerHTML = 'Recording... Tap to stop';
            micLabel.style.color = '';
            addClass(micLabel, 'recording-label');
        }
    } else {
        removeClass(micBtn, 'recording');
        if (micLabel) {
            micLabel.innerHTML = 'Processing...';
            micLabel.style.color = '#8888a0';
            removeClass(micLabel, 'recording-label');
        }
    }
}

function showMicError(msg) {
    var ml = document.getElementById('mic-label');
    if (ml) {
        ml.innerHTML = msg;
        ml.style.color = '#ff4757';
        setTimeout(function() { ml.innerHTML = 'Tap to speak'; ml.style.color = ''; }, 5000);
    }
}

/* -------------------------------------------------------------------
   Tier 1: MediaRecorder
   ------------------------------------------------------------------- */

function startMediaRecorderRec() {
    var gum = getGetUserMedia();
    setMicLabel('Requesting mic...');

    gum({ audio: true },
        function(stream) {
            audioStream = stream;
            mediaChunks = [];
            var MR = window.MediaRecorder || window.webkitMediaRecorder;
            try {
                var opts = {};
                if (MR.isTypeSupported && MR.isTypeSupported('audio/webm')) opts.mimeType = 'audio/webm';
                mediaRecorder = new MR(stream, opts);
            } catch(e) {
                try { mediaRecorder = new MR(stream); } catch(e2) {
                    log('MediaRecorder failed: ' + e2);
                    stopStream(stream); audioStream = null; canMediaRecorder = false;
                    if (canWebAudio) startWebAudioRec(); else triggerNativeCapture();
                    return;
                }
            }
            mediaRecorder.ondataavailable = function(e) {
                if (e.data && e.data.size > 0) mediaChunks.push(e.data);
            };
            mediaRecorder.onstop = function() {
                var mime = (mediaRecorder && mediaRecorder.mimeType) || 'audio/webm';
                var blob = new Blob(mediaChunks, { type: mime });
                mediaChunks = [];
                stopStream(audioStream); audioStream = null; mediaRecorder = null;
                if (blob.size > 100) sendAudio(blob);
                else showMicError('No audio captured.');
            };
            mediaRecorder.start();
            isRecording = true;
            recordingMode = 'mediarecorder';
            setRecordingUI(true);
            log('MediaRecorder started');
        },
        function(err) {
            log('getUserMedia error (MR): ' + ((err && err.name) || err));
            canMediaRecorder = false;
            if (canWebAudio) startWebAudioRec(); else triggerNativeCapture();
        }
    );
}

function stopMediaRecorderRec() {
    isRecording = false; recordingMode = 'none';
    setRecordingUI(false);
    if (mediaRecorder && mediaRecorder.state !== 'inactive') mediaRecorder.stop();
}

/* -------------------------------------------------------------------
   Tier 2: WebAudio (AudioContext + ScriptProcessorNode)
   ------------------------------------------------------------------- */

function startWebAudioRec() {
    var gum = getGetUserMedia();
    if (!gum) { triggerNativeCapture(); return; }
    setMicLabel('Requesting mic...');

    gum({ audio: true },
        function(stream) {
            audioStream = stream;
            recordedBuffers = [];
            recordedLength = 0;
            audioContext = tryCreateAudioContext();
            if (!audioContext) {
                stopStream(stream); audioStream = null; canWebAudio = false;
                triggerNativeCapture(); return;
            }
            var nativeRate = audioContext.sampleRate;
            sourceNode = audioContext.createMediaStreamSource(stream);
            var createSPN = audioContext.createScriptProcessor || audioContext.createJavaScriptNode;
            if (!createSPN) {
                stopStream(stream); audioStream = null;
                if (audioContext.close) try { audioContext.close(); } catch(e) {}
                audioContext = null; canWebAudio = false;
                triggerNativeCapture(); return;
            }
            scriptNode = createSPN.call(audioContext, 4096, 1, 1);
            scriptNode.onaudioprocess = function(e) {
                if (!isRecording) return;
                var inp = e.inputBuffer.getChannelData(0);
                var copy = new Float32Array(inp.length);
                copy.set(inp);
                recordedBuffers.push(copy);
                recordedLength += copy.length;
            };
            sourceNode.connect(scriptNode);
            scriptNode.connect(audioContext.destination);
            isRecording = true;
            recordingMode = 'webaudio';
            setRecordingUI(true);
            log('WebAudio recording started. Rate: ' + nativeRate);
        },
        function(err) {
            log('getUserMedia error (WA): ' + ((err && err.name) || err));
            canWebAudio = false;
            triggerNativeCapture();
        }
    );
}

function stopWebAudioRec() {
    isRecording = false; recordingMode = 'none';
    setRecordingUI(false);
    try { if (scriptNode) { scriptNode.disconnect(); scriptNode = null; } } catch(e) {}
    try { if (sourceNode) { sourceNode.disconnect(); sourceNode = null; } } catch(e) {}
    stopStream(audioStream); audioStream = null;

    if (recordedLength > 0 && audioContext) {
        var nativeRate = audioContext.sampleRate;
        var raw = flattenBuffers(recordedBuffers, recordedLength);
        var ds = downsample(raw, nativeRate, 16000);
        var wav = encodeWAV(ds, 16000);
        if (audioContext.close) try { audioContext.close(); } catch(e) {}
        audioContext = null; recordedBuffers = []; recordedLength = 0;
        sendAudio(wav);
    } else {
        if (audioContext && audioContext.close) try { audioContext.close(); } catch(e) {}
        audioContext = null; recordedBuffers = []; recordedLength = 0;
        showMicError('No audio captured.');
    }
}

/* -------------------------------------------------------------------
   Tier 3: Native audio capture via <input type="file" capture>
   Triggers BB10's native voice recorder app.
   User records, file is returned to us, we upload it.
   ------------------------------------------------------------------- */

function triggerNativeCapture() {
    var fileInput = document.getElementById('audio-file-input');
    if (fileInput) {
        log('Opening native audio recorder via <input capture>...');
        setMicLabel('Opening recorder...');
        /* Reset the input so the same file can be re-selected */
        fileInput.value = '';
        fileInput.click();
    } else {
        log('No <input capture> element found, trying server recording');
        startServerRecording();
    }
}

/* Called from the HTML onchange handler */
function handleAudioFileSelected(input) {
    if (!input.files || input.files.length === 0) {
        log('No file selected from native recorder');
        setMicLabel('Tap to speak');
        return;
    }

    var file = input.files[0];
    log('Native audio file: ' + file.name + ', size: ' + file.size + ', type: ' + file.type);

    if (file.size < 100) {
        showMicError('Recording too short. Try again.');
        return;
    }

    isProcessing = true;
    showStatus('Processing your voice...');
    setMicLabel('Processing...');

    xhrSendFile('/api/voice', file, function(err, data) {
        isProcessing = false;
        hideStatus();
        setMicLabel('Tap to speak');

        if (err) { addSystemMessage('Error: ' + err); return; }
        if (data && data.success) {
            addMessage('user', data.user_text);
            addMessage('assistant', data.assistant_text);
            if (data.audio_url) playAudio(data.audio_url);
        } else if (data && data.error) {
            addSystemMessage('Error: ' + data.error);
        }
    });

    /* Reset so the same file can be chosen again */
    input.value = '';
}

/* -------------------------------------------------------------------
   Tier 4: Server-side recording (waverec / ffmpeg on device)
   ------------------------------------------------------------------- */

function startServerRecording() {
    setMicLabel('Starting mic (server)...');

    xhr('POST', '/api/record/start', '{}', 'application/json', function(err, data) {
        if (!err && data && data.success) {
            isRecording = true;
            recordingMode = 'server';
            setRecordingUI(true);
            log('Server recording started');
        } else {
            var errMsg = err || 'unknown';
            log('Server recording failed: ' + errMsg);
            if (errMsg.indexOf('404') !== -1 || errMsg === 'Not found') {
                showMicError('Server outdated. Run: voiceagent restart');
            } else {
                showMicError('Mic error: ' + errMsg);
            }
        }
    });
}

function stopServerRecording() {
    recordingMode = 'none';
    isProcessing = true;
    showStatus('Processing your voice...');

    xhr('POST', '/api/record/stop', '{}', 'application/json', function(err, data) {
        isProcessing = false;
        hideStatus();
        setMicLabel('Tap to speak');

        if (err) { addSystemMessage('Error: ' + err); return; }
        if (data && data.success) {
            addMessage('user', data.user_text);
            addMessage('assistant', data.assistant_text);
            if (data.audio_url) playAudio(data.audio_url);
        } else if (data && data.error) {
            addSystemMessage('Error: ' + data.error);
        }
    });
}

/* -------------------------------------------------------------------
   Send audio to server
   ------------------------------------------------------------------- */

function sendAudio(blob) {
    if (isProcessing) return;
    isProcessing = true;
    showStatus('Processing your voice...');
    log('Sending audio: ' + blob.size + ' bytes, type: ' + blob.type);

    xhrSendBlob('/api/voice', blob, function(err, data) {
        isProcessing = false;
        hideStatus();
        setMicLabel('Tap to speak');

        if (err) { addSystemMessage('Error: ' + err); return; }
        if (data && data.success) {
            addMessage('user', data.user_text);
            addMessage('assistant', data.assistant_text);
            if (data.audio_url) playAudio(data.audio_url);
        } else if (data && data.error) {
            addSystemMessage('Error: ' + data.error);
        }
    });
}

function sendText() {
    var input = document.getElementById('text-input');
    var text = input ? input.value.replace(/^\s+|\s+$/g, '') : '';
    if (!text || isProcessing) return;
    input.value = '';
    isProcessing = true;
    showStatus('Thinking...');
    addMessage('user', text);

    xhr('POST', '/api/text', JSON.stringify({ text: text }), 'application/json', function(err, data) {
        isProcessing = false;
        hideStatus();
        if (err) { addSystemMessage('Error: ' + err); return; }
        if (data && data.success) {
            addMessage('assistant', data.assistant_text);
            if (data.audio_url) playAudio(data.audio_url);
        } else if (data && data.error) {
            addSystemMessage('Error: ' + data.error);
        }
    });
}

/* -------------------------------------------------------------------
   Mic label helper
   ------------------------------------------------------------------- */

function setMicLabel(text) {
    var ml = document.getElementById('mic-label');
    if (ml) { ml.innerHTML = text; ml.style.color = '#8888a0'; }
}

/* -------------------------------------------------------------------
   Audio Playback
   ------------------------------------------------------------------- */

function playAudio(url) {
    if (currentAudio) { try { currentAudio.pause(); } catch(e) {} currentAudio = null; }
    try {
        var audio = new Audio(url);
        currentAudio = audio;
        audio.onerror = function() {};
        audio.play();
    } catch(e) {}
}

/* -------------------------------------------------------------------
   Chat UI
   ------------------------------------------------------------------- */

function addMessage(role, text) {
    var container = document.getElementById('chat-messages');
    if (!container) return;
    var welcome = container.querySelector('.welcome-msg');
    if (welcome && welcome.parentNode) welcome.parentNode.removeChild(welcome);
    var msg = document.createElement('div');
    msg.className = 'message ' + role;
    var label = document.createElement('div');
    label.className = 'message-label';
    label.innerHTML = (role === 'user') ? 'You' : 'VoiceAgent';
    var bubble = document.createElement('div');
    bubble.className = 'message-bubble';
    bubble.innerHTML = escapeHtml(text);
    msg.appendChild(label);
    msg.appendChild(bubble);
    container.appendChild(msg);
    container.scrollTop = container.scrollHeight;
}

function addSystemMessage(text) {
    var container = document.getElementById('chat-messages');
    if (!container) return;
    var msg = document.createElement('div');
    msg.className = 'message assistant';
    var bubble = document.createElement('div');
    bubble.className = 'message-bubble';
    bubble.style.color = '#ff4757';
    bubble.style.borderColor = 'rgba(255,71,87,0.3)';
    bubble.innerHTML = escapeHtml(text);
    msg.appendChild(bubble);
    container.appendChild(msg);
    container.scrollTop = container.scrollHeight;
}

function escapeHtml(str) {
    if (!str) return '';
    return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function showStatus(text) {
    var bar = document.getElementById('status-bar');
    var txt = document.getElementById('status-text');
    if (bar) removeClass(bar, 'hidden');
    if (txt) txt.innerHTML = text;
}

function hideStatus() {
    var bar = document.getElementById('status-bar');
    if (bar) addClass(bar, 'hidden');
}

/* -------------------------------------------------------------------
   History
   ------------------------------------------------------------------- */

function loadHistory() {
    xhr('GET', '/api/history', null, null, function(err, data) {
        if (!err && data && data.history && data.history.length > 0) {
            for (var i = 0; i < data.history.length; i++) {
                addMessage(data.history[i].role, data.history[i].content);
            }
        }
    });
}

function clearHistory() {
    if (!confirm('Clear conversation history?')) return;
    xhr('POST', '/api/clear', null, null, function() {
        var container = document.getElementById('chat-messages');
        if (container) {
            container.innerHTML =
                '<div class="welcome-msg"><div class="welcome-icon">' +
                '<svg viewBox="0 0 24 24" width="32" height="32" fill="none" stroke="currentColor" stroke-width="1.5">' +
                '<path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"/>' +
                '<path d="M19 10v2a7 7 0 0 1-14 0v-2"/>' +
                '<line x1="12" y1="19" x2="12" y2="23"/><line x1="8" y1="23" x2="16" y2="23"/>' +
                '</svg></div><p>Tap the microphone to speak, or type a message below.</p></div>';
        }
    });
}

/* -------------------------------------------------------------------
   Settings
   ------------------------------------------------------------------- */

function openSettings() {
    var modal = document.getElementById('settings-modal');
    if (modal) removeClass(modal, 'hidden');
    xhr('GET', '/api/config', null, null, function(err, cfg) {
        if (err || !cfg) return;
        var v = document.getElementById('settings-voice');
        var m = document.getElementById('settings-model');
        var p = document.getElementById('settings-prompt');
        if (v && cfg.tts_voice) v.value = cfg.tts_voice;
        if (m && cfg.model) m.value = cfg.model;
        if (p && cfg.system_prompt) p.value = cfg.system_prompt;
    });
}

function closeSettings() {
    var modal = document.getElementById('settings-modal');
    if (modal) addClass(modal, 'hidden');
}

function saveSettings() {
    var keyEl = document.getElementById('settings-api-key');
    var voiceEl = document.getElementById('settings-voice');
    var modelEl = document.getElementById('settings-model');
    var promptEl = document.getElementById('settings-prompt');
    var updates = {};
    if (keyEl && keyEl.value.replace(/^\s+|\s+$/g, '')) updates.openai_api_key = keyEl.value.replace(/^\s+|\s+$/g, '');
    if (voiceEl) updates.tts_voice = voiceEl.value;
    if (modelEl) updates.model = modelEl.value;
    if (promptEl) updates.system_prompt = promptEl.value;
    xhr('POST', '/api/config', JSON.stringify(updates), 'application/json', function(err, data) {
        if (!err && data && data.success) { closeSettings(); if (keyEl) keyEl.value = ''; }
        else { alert('Failed to save: ' + (err || 'unknown error')); }
    });
}
