# BerryCore Dashboard

Tech dashboard with live device data and quick links to tools.

## Features

- **BerryCore** ASCII art header (green)
- **Live data:** Battery, Local IP, Geolocation, Accelerometer, Gyroscope
- **Tool shortcuts:** Drawing Board, Markdown, Code Editor, Keyboard, Messenger

## Usage

```
http://server:8765/tools/dashboard/
```

## Data Sources

| Card | API |
|------|-----|
| Battery | navigator.getBattery() |
| Local IP | WebRTC ICE candidates |
| Location | navigator.geolocation |
| Accel X/Y/Z | DeviceMotionEvent |
| Alpha/Beta/Gamma | DeviceOrientationEvent |
