#!/usr/bin/env python3
"""
QNX Desktop - A Windows 98 style file explorer for QNX BlackBerry devices
Provides web-based access to QNX file system paths with retro UI
Compatible with QNX Task Manager system
"""

import os
import json
import mimetypes
from pathlib import Path
from flask import Flask, render_template, request, jsonify, send_file, redirect, url_for
from werkzeug.utils import secure_filename
import stat
import time
import requests
import imaplib
import smtplib
import email
import email.utils
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders
from email.header import decode_header
import ssl
import base64
import threading
import re
from datetime import datetime

# Port configuration for task manager compatibility
PORT = 8029

app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = 100 * 1024 * 1024  # 100MB max file size

# QNX paths we want to provide access to
QNX_PATHS = {
    'shared': '/accounts/1000/shared',
    'sdcard': '/accounts/1000/removable/sdcard'
}

# Mail configuration directory
MAIL_CONFIG_DIR = os.path.join(QNX_PATHS['shared'], 'documents', 'mail')
MAIL_CONFIG_FILE = os.path.join(MAIL_CONFIG_DIR, 'config.json')

# Ensure mail config directory exists
os.makedirs(MAIL_CONFIG_DIR, exist_ok=True)

class MailManager:
    """Handles IMAP/SMTP operations for the mail client"""
    
    def __init__(self):
        self.imap_connection = None
        self.smtp_connection = None
        self.config = self.load_config()
        self.cache = {}
        
    def load_config(self):
        """Load mail configuration from file"""
        try:
            if os.path.exists(MAIL_CONFIG_FILE):
                with open(MAIL_CONFIG_FILE, 'r') as f:
                    return json.load(f)
        except Exception as e:
            print(f"Error loading mail config: {e}")
        
        return {
            'imap_server': '',
            'imap_port': 993,
            'smtp_server': '',
            'smtp_port': 587,
            'username': '',
            'password': '',
            'use_ssl': True,
            'use_tls': True
        }
    
    def save_config(self, config):
        """Save mail configuration to file"""
        try:
            self.config = config
            with open(MAIL_CONFIG_FILE, 'w') as f:
                json.dump(config, f, indent=2)
            return True
        except Exception as e:
            print(f"Error saving mail config: {e}")
            return False
    
    def connect_imap(self):
        """Connect to IMAP server"""
        try:
            if not self.config.get('imap_server') or not self.config.get('username'):
                return False, "IMAP server or username not configured"
            
            # Disconnect existing connection if any
            self.disconnect_imap()
            
            if self.config.get('use_ssl', True):
                self.imap_connection = imaplib.IMAP4_SSL(
                    self.config['imap_server'], 
                    self.config.get('imap_port', 993)
                )
            else:
                self.imap_connection = imaplib.IMAP4(
                    self.config['imap_server'], 
                    self.config.get('imap_port', 143)
                )
            
            # Login with better error handling
            try:
                login_result = self.imap_connection.login(
                    self.config['username'], 
                    self.config['password']
                )
                print(f"IMAP login result: {login_result}")
            except Exception as login_error:
                self.imap_connection = None
                return False, f"Login failed: {str(login_error)}"
            
            return True, "Connected successfully"
            
        except Exception as e:
            self.imap_connection = None
            return False, f"IMAP connection failed: {str(e)}"
    
    def disconnect_imap(self):
        """Disconnect from IMAP server"""
        try:
            if self.imap_connection:
                self.imap_connection.logout()
                self.imap_connection = None
        except:
            pass
    
    def get_folders(self):
        """Get list of mail folders"""
        try:
            if not self.imap_connection:
                success, msg = self.connect_imap()
                if not success:
                    return []
            
            status, folders = self.imap_connection.list()
            if status != 'OK':
                return ['INBOX', 'SENT', 'DRAFTS', 'TRASH']
            
            folder_list = []
            for folder in folders:
                # Parse folder name from IMAP response
                folder_name = folder.decode().split('"')[-2] if '"' in folder.decode() else folder.decode().split()[-1]
                folder_list.append(folder_name)
            
            return folder_list if folder_list else ['INBOX', 'SENT', 'DRAFTS', 'TRASH']
            
        except Exception as e:
            print(f"Error getting folders: {e}")
            return ['INBOX', 'SENT', 'DRAFTS', 'TRASH']
    
    def get_emails(self, folder='INBOX', page=1, limit=25):
        """Get emails from specified folder with pagination"""
        try:
            if not self.imap_connection:
                success, msg = self.connect_imap()
                if not success:
                    return {'emails': [], 'total': 0, 'pages': 1, 'error': msg}
            
            # Select folder with better error handling
            try:
                status, messages = self.imap_connection.select(folder)
                if status != 'OK':
                    return {'emails': [], 'total': 0, 'pages': 1, 'error': f'Cannot select folder {folder}: {status}'}
                
                # Parse message count more safely
                if not messages or not messages[0]:
                    return {'emails': [], 'total': 0, 'pages': 1}
                
                # Handle case where messages[0] might contain extra data
                msg_count_str = messages[0].decode() if isinstance(messages[0], bytes) else str(messages[0])
                # Extract just the number from the response
                import re
                numbers = re.findall(r'\d+', msg_count_str)
                total_messages = int(numbers[0]) if numbers else 0
                
            except Exception as select_error:
                print(f"Folder selection error: {select_error}")
                return {'emails': [], 'total': 0, 'pages': 1, 'error': f'Folder selection failed: {str(select_error)}'}
            
            total_pages = max(1, (total_messages + limit - 1) // limit)
            
            if total_messages == 0:
                return {'emails': [], 'total': 0, 'pages': 1}
            
            # Calculate message range for pagination
            start_msg = max(1, total_messages - (page * limit) + 1)
            end_msg = min(total_messages, total_messages - ((page - 1) * limit))
            
            if start_msg > end_msg:
                return {'emails': [], 'total': total_messages, 'pages': total_pages}
            
            # Fetch message headers
            emails = []
            for msg_num in range(end_msg, start_msg - 1, -1):  # Reverse order (newest first)
                try:
                    # Fetch with more specific header request
                    status, msg_data = self.imap_connection.fetch(str(msg_num), '(BODY.PEEK[HEADER])')
                    if status != 'OK':
                        # Fallback to RFC822.HEADER if BODY.PEEK fails
                        status, msg_data = self.imap_connection.fetch(str(msg_num), '(RFC822.HEADER)')
                    
                    if status == 'OK' and msg_data and msg_data[0] and len(msg_data[0]) > 1:
                        # Parse the email message
                        header_data = msg_data[0][1]
                        if isinstance(header_data, bytes):
                            email_message = email.message_from_bytes(header_data)
                        else:
                            email_message = email.message_from_string(str(header_data))
                        
                        # Decode headers safely
                        subject = self.decode_header_value(email_message.get('Subject', '')) or f'Message {msg_num}'
                        from_addr = self.decode_header_value(email_message.get('From', '')) or 'Unknown Sender'
                        to_addr = self.decode_header_value(email_message.get('To', '')) or ''
                        date_str = email_message.get('Date', '')
                        
                        # Parse date safely
                        try:
                            if date_str:
                                date_obj = email.utils.parsedate_to_datetime(date_str)
                                formatted_date = date_obj.isoformat()
                            else:
                                formatted_date = datetime.now().isoformat()
                        except Exception as date_error:
                            print(f"Date parsing error for message {msg_num}: {date_error}")
                            formatted_date = datetime.now().isoformat()
                        
                        # Check if message is unread (safely)
                        is_unread = True  # Default to unread
                        try:
                            status, flags = self.imap_connection.fetch(str(msg_num), '(FLAGS)')
                            if status == 'OK' and flags and flags[0]:
                                flag_str = flags[0].decode() if isinstance(flags[0], bytes) else str(flags[0])
                                is_unread = '\\Seen' not in flag_str
                        except Exception as flag_error:
                            print(f"Flag checking error for message {msg_num}: {flag_error}")
                        
                        emails.append({
                            'id': msg_num,
                            'subject': subject,
                            'from': from_addr,
                            'to': to_addr,
                            'date': formatted_date,
                            'unread': is_unread,
                            'size': len(header_data) if header_data else 0
                        })
                        
                except Exception as e:
                    print(f"Error processing message {msg_num}: {e}")
                    # Add a placeholder entry so we don't lose track of message numbers
                    emails.append({
                        'id': msg_num,
                        'subject': f'Error loading message {msg_num}',
                        'from': 'System',
                        'to': '',
                        'date': datetime.now().isoformat(),
                        'unread': False,
                        'size': 0
                    })
                    continue
            
            return {
                'emails': emails,
                'total': total_messages,
                'pages': total_pages,
                'current_page': page
            }
            
        except Exception as e:
            print(f"Error getting emails: {e}")
            return {'emails': [], 'total': 0, 'pages': 1, 'error': str(e)}
    
    def get_email_content(self, email_id, folder='INBOX'):
        """Get full email content by ID"""
        try:
            if not self.imap_connection:
                success, msg = self.connect_imap()
                if not success:
                    return {'error': msg}
            
            # Select folder
            self.imap_connection.select(folder)
            
            # Fetch full message
            status, msg_data = self.imap_connection.fetch(str(email_id), '(RFC822)')
            if status != 'OK' or not msg_data[0]:
                return {'error': 'Email not found'}
            
            email_message = email.message_from_bytes(msg_data[0][1])
            
            # Extract email content
            subject = self.decode_header_value(email_message.get('Subject', ''))
            from_addr = self.decode_header_value(email_message.get('From', ''))
            to_addr = self.decode_header_value(email_message.get('To', ''))
            date_str = email_message.get('Date', '')
            
            # Get email body
            body = self.extract_email_body(email_message)
            
            return {
                'id': email_id,
                'subject': subject,
                'from': from_addr,
                'to': to_addr,
                'date': date_str,
                'body': body
            }
            
        except Exception as e:
            print(f"Error getting email content: {e}")
            return {'error': str(e)}
    
    def decode_header_value(self, header_value):
        """Decode email header value"""
        if not header_value:
            return ''
        
        try:
            decoded_parts = decode_header(header_value)
            decoded_string = ''
            for part, encoding in decoded_parts:
                if isinstance(part, bytes):
                    decoded_string += part.decode(encoding or 'utf-8', errors='ignore')
                else:
                    decoded_string += part
            return decoded_string
        except:
            return str(header_value)
    
    def extract_email_body(self, email_message):
        """Extract email body content"""
        body = ""
        
        if email_message.is_multipart():
            for part in email_message.walk():
                content_type = part.get_content_type()
                content_disposition = str(part.get("Content-Disposition", ""))
                
                if content_type == "text/plain" and "attachment" not in content_disposition:
                    try:
                        body = part.get_payload(decode=True).decode('utf-8', errors='ignore')
                        break
                    except:
                        continue
                elif content_type == "text/html" and "attachment" not in content_disposition and not body:
                    try:
                        body = part.get_payload(decode=True).decode('utf-8', errors='ignore')
                    except:
                        continue
        else:
            try:
                body = email_message.get_payload(decode=True).decode('utf-8', errors='ignore')
            except:
                body = str(email_message.get_payload())
        
        return body or "No content available"
    
    def send_email(self, to_addr, subject, body, cc=None, bcc=None):
        """Send an email via SMTP"""
        try:
            if not self.config.get('smtp_server') or not self.config.get('username'):
                return False, "SMTP server or username not configured"
            
            # Create message
            msg = MIMEMultipart()
            msg['From'] = self.config['username']
            msg['To'] = to_addr
            msg['Subject'] = subject
            
            if cc:
                msg['Cc'] = cc
            if bcc:
                msg['Bcc'] = bcc
            
            # Add body
            msg.attach(MIMEText(body, 'plain'))
            
            # Connect to SMTP server
            if self.config.get('use_ssl', True):
                server = smtplib.SMTP_SSL(
                    self.config['smtp_server'], 
                    self.config.get('smtp_port', 465)
                )
            else:
                server = smtplib.SMTP(
                    self.config['smtp_server'], 
                    self.config.get('smtp_port', 587)
                )
                if self.config.get('use_tls', True):
                    server.starttls()
            
            server.login(self.config['username'], self.config['password'])
            
            # Send email
            recipients = [to_addr]
            if cc:
                recipients.extend(cc.split(','))
            if bcc:
                recipients.extend(bcc.split(','))
            
            server.send_message(msg, to_addrs=recipients)
            server.quit()
            
            return True, "Email sent successfully"
            
        except Exception as e:
            print(f"Error sending email: {e}")
            return False, f"Failed to send email: {str(e)}"
    
    def delete_emails(self, email_ids, folder='INBOX'):
        """Delete emails by moving them to Trash or marking as deleted"""
        try:
            if not self.imap_connection:
                success, msg = self.connect_imap()
                if not success:
                    return False, msg
            
            # Select the folder with error handling
            try:
                status, messages = self.imap_connection.select(folder)
                if status != 'OK':
                    return False, f"Cannot select folder {folder}: {status}"
            except Exception as select_error:
                print(f"Folder selection error during delete: {select_error}")
                return False, f"Folder selection failed: {str(select_error)}"
            
            deleted_count = 0
            failed_deletes = []
            
            for email_id in email_ids:
                try:
                    # Mark message as deleted with better error handling
                    status, response = self.imap_connection.store(str(email_id), '+FLAGS', '\\Deleted')
                    
                    if status == 'OK':
                        deleted_count += 1
                        print(f"Successfully marked message {email_id} for deletion")
                    else:
                        print(f"Failed to mark message {email_id} for deletion: {status} - {response}")
                        failed_deletes.append(str(email_id))
                        
                except Exception as e:
                    print(f"Error deleting message {email_id}: {e}")
                    failed_deletes.append(str(email_id))
                    continue
            
            # Expunge to permanently delete (with error handling)
            try:
                if deleted_count > 0:
                    expunge_status, expunge_response = self.imap_connection.expunge()
                    if expunge_status != 'OK':
                        print(f"Expunge warning: {expunge_status} - {expunge_response}")
                        # Continue anyway as messages might still be marked for deletion
            except Exception as expunge_error:
                print(f"Expunge error (messages may still be deleted): {expunge_error}")
                # Don't fail the operation as messages are likely still marked for deletion
            
            # Prepare result message
            if deleted_count > 0:
                message = f"Deleted {deleted_count} email(s) successfully"
                if failed_deletes:
                    message += f" (failed to delete {len(failed_deletes)} emails: {', '.join(failed_deletes[:3])}{'...' if len(failed_deletes) > 3 else ''})"
                return True, message
            else:
                if failed_deletes:
                    return False, f"Failed to delete all {len(failed_deletes)} emails"
                else:
                    return False, "No emails were deleted"
                
        except Exception as e:
            print(f"Error deleting emails: {e}")
            return False, f"Failed to delete emails: {str(e)}"
    
    def mark_as_read(self, email_ids, folder='INBOX'):
        """Mark emails as read"""
        try:
            if not self.imap_connection:
                success, msg = self.connect_imap()
                if not success:
                    return False, msg
            
            # Select the folder with error handling
            try:
                status, messages = self.imap_connection.select(folder)
                if status != 'OK':
                    return False, f"Cannot select folder {folder}: {status}"
            except Exception as select_error:
                print(f"Folder selection error during mark as read: {select_error}")
                return False, f"Folder selection failed: {str(select_error)}"
            
            marked_count = 0
            failed_marks = []
            
            for email_id in email_ids:
                try:
                    status, response = self.imap_connection.store(str(email_id), '+FLAGS', '\\Seen')
                    if status == 'OK':
                        marked_count += 1
                        print(f"Successfully marked message {email_id} as read")
                    else:
                        print(f"Failed to mark message {email_id} as read: {status} - {response}")
                        failed_marks.append(str(email_id))
                except Exception as e:
                    print(f"Error marking message {email_id} as read: {e}")
                    failed_marks.append(str(email_id))
                    continue
            
            if marked_count > 0:
                message = f"Marked {marked_count} email(s) as read"
                if failed_marks:
                    message += f" (failed: {len(failed_marks)} emails)"
                return True, message
            else:
                return False, f"Failed to mark emails as read"
                
        except Exception as e:
            print(f"Error marking emails as read: {e}")
            return False, f"Failed to mark emails as read: {str(e)}"
    
    def mark_as_unread(self, email_ids, folder='INBOX'):
        """Mark emails as unread"""
        try:
            if not self.imap_connection:
                success, msg = self.connect_imap()
                if not success:
                    return False, msg
            
            # Select the folder with error handling
            try:
                status, messages = self.imap_connection.select(folder)
                if status != 'OK':
                    return False, f"Cannot select folder {folder}: {status}"
            except Exception as select_error:
                print(f"Folder selection error during mark as unread: {select_error}")
                return False, f"Folder selection failed: {str(select_error)}"
            
            marked_count = 0
            failed_marks = []
            
            for email_id in email_ids:
                try:
                    status, response = self.imap_connection.store(str(email_id), '-FLAGS', '\\Seen')
                    if status == 'OK':
                        marked_count += 1
                        print(f"Successfully marked message {email_id} as unread")
                    else:
                        print(f"Failed to mark message {email_id} as unread: {status} - {response}")
                        failed_marks.append(str(email_id))
                except Exception as e:
                    print(f"Error marking message {email_id} as unread: {e}")
                    failed_marks.append(str(email_id))
                    continue
            
            if marked_count > 0:
                message = f"Marked {marked_count} email(s) as unread"
                if failed_marks:
                    message += f" (failed: {len(failed_marks)} emails)"
                return True, message
            else:
                return False, f"Failed to mark emails as unread"
                
        except Exception as e:
            print(f"Error marking emails as unread: {e}")
            return False, f"Failed to mark emails as unread: {str(e)}"

# Global mail manager instance
mail_manager = MailManager()

def get_file_info(filepath):
    """Get detailed file information"""
    try:
        stat_info = os.stat(filepath)
        return {
            'name': os.path.basename(filepath),
            'path': filepath,
            'size': stat_info.st_size,
            'modified': time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(stat_info.st_mtime)),
            'is_dir': os.path.isdir(filepath),
            'is_file': os.path.isfile(filepath),
            'permissions': oct(stat_info.st_mode)[-3:],
            'mimetype': mimetypes.guess_type(filepath)[0] if os.path.isfile(filepath) else None
        }
    except (OSError, IOError) as e:
        return {
            'name': os.path.basename(filepath),
            'path': filepath,
            'error': str(e),
            'is_dir': False,
            'is_file': False
        }

def format_file_size(size_bytes):
    """Format file size in human readable format"""
    if size_bytes == 0:
        return "0 B"
    size_names = ["B", "KB", "MB", "GB", "TB"]
    i = 0
    while size_bytes >= 1024 and i < len(size_names) - 1:
        size_bytes /= 1024.0
        i += 1
    return f"{size_bytes:.1f} {size_names[i]}"

def get_file_icon(filepath, is_dir=False):
    """Get appropriate icon for file type"""
    if is_dir:
        return 'directory_closed.ico'
    
    ext = os.path.splitext(filepath)[1].lower()
    icon_map = {
        '.txt': 'notepad_file.ico',
        '.doc': 'WINWORD_1.ico',
        '.docx': 'WINWORD_2.ico',
        '.pdf': 'pdf.png',
        '.exe': 'application_hourglass.ico',
        '.zip': 'erase_file.ico',
        '.jpg': 'desktop.png',
        '.jpeg': 'desktop.png',
        '.png': 'desktop.png',
        '.gif': 'desktop.png',
        '.mp3': 'winamp.ico',
        '.wav': 'volume.ico',
        '.html': 'msie1.ico',
        '.htm': 'msie2.ico'
    }
    return icon_map.get(ext, 'notepad_file.ico')

@app.route('/')
def desktop():
    """Main desktop interface"""
    return render_template('desktop.html')

@app.route('/api/browse/<path_type>')
@app.route('/api/browse/<path_type>/<path:subpath>')
def browse_files(path_type, subpath=''):
    """Browse files in QNX paths"""
    if path_type not in QNX_PATHS:
        return jsonify({'error': 'Invalid path type'}), 400
    
    base_path = QNX_PATHS[path_type]
    full_path = os.path.join(base_path, subpath) if subpath else base_path
    
    # Security check - ensure we stay within allowed paths
    try:
        full_path = os.path.realpath(full_path)
        if not full_path.startswith(os.path.realpath(base_path)):
            return jsonify({'error': 'Access denied'}), 403
    except Exception as e:
        return jsonify({'error': f'Path error: {str(e)}'}), 400
    
    try:
        if not os.path.exists(full_path):
            return jsonify({'error': 'Path does not exist'}), 404
        
        if os.path.isfile(full_path):
            # Return file info for single file
            file_info = get_file_info(full_path)
            file_info['icon'] = get_file_icon(full_path, False)
            file_info['formatted_size'] = format_file_size(file_info.get('size', 0))
            return jsonify({'file': file_info})
        
        # List directory contents
        items = []
        try:
            for item_name in sorted(os.listdir(full_path)):
                if item_name.startswith('.'):  # Skip hidden files
                    continue
                    
                item_path = os.path.join(full_path, item_name)
                file_info = get_file_info(item_path)
                file_info['icon'] = get_file_icon(item_path, file_info['is_dir'])
                file_info['formatted_size'] = format_file_size(file_info.get('size', 0)) if not file_info['is_dir'] else ''
                items.append(file_info)
        except PermissionError:
            return jsonify({'error': 'Permission denied'}), 403
        
        # Build breadcrumb navigation
        breadcrumbs = []
        current_path = ''
        path_parts = subpath.split('/') if subpath else []
        
        # Add root
        breadcrumbs.append({
            'name': path_type.title(),
            'path': '',
            'url': f'/api/browse/{path_type}'
        })
        
        # Add intermediate paths
        for part in path_parts:
            if part:
                current_path = f"{current_path}/{part}" if current_path else part
                breadcrumbs.append({
                    'name': part,
                    'path': current_path,
                    'url': f'/api/browse/{path_type}/{current_path}'
                })
        
        return jsonify({
            'path_type': path_type,
            'current_path': subpath,
            'full_path': full_path,
            'breadcrumbs': breadcrumbs,
            'items': items,
            'total_items': len(items)
        })
        
    except Exception as e:
        return jsonify({'error': f'Error browsing path: {str(e)}'}), 500

@app.route('/api/download/<path_type>/<path:filepath>')
def download_file(path_type, filepath):
    """Download a file from QNX paths"""
    if path_type not in QNX_PATHS:
        return jsonify({'error': 'Invalid path type'}), 400
    
    base_path = QNX_PATHS[path_type]
    full_path = os.path.join(base_path, filepath)
    
    # Security check
    try:
        full_path = os.path.realpath(full_path)
        if not full_path.startswith(os.path.realpath(base_path)):
            return jsonify({'error': 'Access denied'}), 403
    except Exception as e:
        return jsonify({'error': f'Path error: {str(e)}'}), 400
    
    if not os.path.exists(full_path) or not os.path.isfile(full_path):
        return jsonify({'error': 'File not found'}), 404
    
    try:
        return send_file(full_path, as_attachment=True)
    except Exception as e:
        return jsonify({'error': f'Error downloading file: {str(e)}'}), 500

@app.route('/api/upload/<path_type>', methods=['POST'])
@app.route('/api/upload/<path_type>/<path:dirpath>', methods=['POST'])
def upload_file(path_type, dirpath=''):
    """Upload a file to QNX paths"""
    if path_type not in QNX_PATHS:
        return jsonify({'error': 'Invalid path type'}), 400
    
    if 'file' not in request.files:
        return jsonify({'error': 'No file provided'}), 400
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No file selected'}), 400
    
    base_path = QNX_PATHS[path_type]
    upload_dir = os.path.join(base_path, dirpath) if dirpath else base_path
    
    # Security check
    try:
        upload_dir = os.path.realpath(upload_dir)
        if not upload_dir.startswith(os.path.realpath(base_path)):
            return jsonify({'error': 'Access denied'}), 403
    except Exception as e:
        return jsonify({'error': f'Path error: {str(e)}'}), 400
    
    # Create upload directory if it doesn't exist
    if not os.path.exists(upload_dir):
        try:
            os.makedirs(upload_dir, exist_ok=True)
        except Exception as e:
            return jsonify({'error': f'Could not create directory: {str(e)}'}), 500
    elif not os.path.isdir(upload_dir):
        return jsonify({'error': 'Upload path exists but is not a directory'}), 400
    
    try:
        filename = secure_filename(file.filename)
        filepath = os.path.join(upload_dir, filename)
        
        # Check if file already exists (but allow overwrite if force=true)
        force_overwrite = request.form.get('force', 'false').lower() == 'true'
        if os.path.exists(filepath) and not force_overwrite:
            return jsonify({'error': 'File already exists'}), 409
        
        file.save(filepath)
        
        # Return info about uploaded file
        file_info = get_file_info(filepath)
        file_info['icon'] = get_file_icon(filepath, False)
        file_info['formatted_size'] = format_file_size(file_info.get('size', 0))
        
        return jsonify({
            'message': 'File uploaded successfully',
            'file': file_info
        })
        
    except Exception as e:
        return jsonify({'error': f'Error uploading file: {str(e)}'}), 500

@app.route('/api/mkdir/<path_type>/<path:dirpath>', methods=['POST'])
def create_directory(path_type, dirpath=''):
    """Create a new directory"""
    if path_type not in QNX_PATHS:
        return jsonify({'error': 'Invalid path type'}), 400
    
    data = request.get_json()
    if not data or 'name' not in data:
        return jsonify({'error': 'Directory name required'}), 400
    
    dir_name = secure_filename(data['name'])
    if not dir_name:
        return jsonify({'error': 'Invalid directory name'}), 400
    
    base_path = QNX_PATHS[path_type]
    parent_dir = os.path.join(base_path, dirpath) if dirpath else base_path
    new_dir_path = os.path.join(parent_dir, dir_name)
    
    # Security check
    try:
        new_dir_path = os.path.realpath(new_dir_path)
        if not new_dir_path.startswith(os.path.realpath(base_path)):
            return jsonify({'error': 'Access denied'}), 403
    except Exception as e:
        return jsonify({'error': f'Path error: {str(e)}'}), 400
    
    try:
        if os.path.exists(new_dir_path):
            return jsonify({'error': 'Directory already exists'}), 409
        
        os.makedirs(new_dir_path)
        
        # Return info about created directory
        dir_info = get_file_info(new_dir_path)
        dir_info['icon'] = get_file_icon(new_dir_path, True)
        
        return jsonify({
            'message': 'Directory created successfully',
            'directory': dir_info
        })
        
    except Exception as e:
        return jsonify({'error': f'Error creating directory: {str(e)}'}), 500

@app.route('/api/delete/<path_type>/<path:filepath>', methods=['DELETE'])
def delete_item(path_type, filepath):
    """Delete a file or directory"""
    if path_type not in QNX_PATHS:
        return jsonify({'error': 'Invalid path type'}), 400
    
    base_path = QNX_PATHS[path_type]
    full_path = os.path.join(base_path, filepath)
    
    # Security check
    try:
        full_path = os.path.realpath(full_path)
        if not full_path.startswith(os.path.realpath(base_path)):
            return jsonify({'error': 'Access denied'}), 403
    except Exception as e:
        return jsonify({'error': f'Path error: {str(e)}'}), 400
    
    if not os.path.exists(full_path):
        return jsonify({'error': 'Item not found'}), 404
    
    try:
        if os.path.isfile(full_path):
            os.remove(full_path)
            return jsonify({'message': 'File deleted successfully'})
        elif os.path.isdir(full_path):
            os.rmdir(full_path)  # Only removes empty directories
            return jsonify({'message': 'Directory deleted successfully'})
        else:
            return jsonify({'error': 'Unknown item type'}), 400
            
    except OSError as e:
        if e.errno == 39:  # Directory not empty
            return jsonify({'error': 'Directory not empty'}), 400
        else:
            return jsonify({'error': f'Error deleting item: {str(e)}'}), 500
    except Exception as e:
        return jsonify({'error': f'Error deleting item: {str(e)}'}), 500

@app.route('/api/system/info')
def system_info():
    """Get system information"""
    info = {
        'hostname': os.uname().nodename if hasattr(os, 'uname') else 'QNX-Desktop',
        'platform': 'QNX BlackBerry',
        'paths': QNX_PATHS,
        'uptime': 'Unknown',
        'app_name': 'QNX Desktop',
        'app_version': '1.0.0',
        'port': PORT
    }
    
    # Check if paths exist and are accessible
    for name, path in QNX_PATHS.items():
        try:
            info[f'{name}_accessible'] = os.path.exists(path) and os.access(path, os.R_OK)
            if info[f'{name}_accessible']:
                stat_info = os.statvfs(path)
                total_space = stat_info.f_frsize * stat_info.f_blocks
                free_space = stat_info.f_frsize * stat_info.f_available
                info[f'{name}_total_space'] = format_file_size(total_space)
                info[f'{name}_free_space'] = format_file_size(free_space)
        except Exception:
            info[f'{name}_accessible'] = False
    
    return jsonify(info)

@app.route('/health')
def health_check():
    """Health check endpoint for task manager"""
    return jsonify({
        'status': 'healthy',
        'app': 'QNX Desktop',
        'port': PORT,
        'timestamp': time.time()
    })

# AI Chat endpoints
AI_SETTINGS_FILE = os.path.join(QNX_PATHS['shared'], 'documents', 'AI', 'settings.json')

def ensure_ai_directory():
    """Ensure AI directory exists"""
    ai_dir = os.path.join(QNX_PATHS['shared'], 'documents', 'AI')
    if not os.path.exists(ai_dir):
        os.makedirs(ai_dir, exist_ok=True)
    return ai_dir

@app.route('/api/aichat/settings', methods=['GET'])
def get_aichat_settings():
    """Get AI Chat settings"""
    try:
        full_key = request.args.get('full_key') == 'true'
        print(f"AI Settings request - full_key: {full_key}, file exists: {os.path.exists(AI_SETTINGS_FILE)}")
        
        if os.path.exists(AI_SETTINGS_FILE):
            with open(AI_SETTINGS_FILE, 'r') as f:
                settings = json.load(f)
                print(f"AI Settings loaded - has api_key: {'api_key' in settings and bool(settings.get('api_key'))}")
                
                # Check if this is a request for the full API key (from Desktop Assistant)
                if not full_key:
                    # Don't send the full API key for security (UI display)
                    if 'api_key' in settings and settings['api_key']:
                        settings['api_key'] = settings['api_key'][:8] + '...' if len(settings['api_key']) > 8 else settings['api_key']
                return jsonify(settings)
        else:
            return jsonify({
                'api_key': '',
                'system_prompt': 'You are a helpful AI assistant running on a QNX BlackBerry device. Be concise but informative.',
                'model': 'claude-3-haiku-20240307'
            })
    except Exception as e:
        return jsonify({'error': f'Error loading settings: {str(e)}'}), 500

@app.route('/api/aichat/settings', methods=['POST'])
def save_aichat_settings():
    """Save AI Chat settings"""
    try:
        ensure_ai_directory()
        data = request.get_json()
        
        # Load existing settings to preserve full API key
        existing_settings = {}
        if os.path.exists(AI_SETTINGS_FILE):
            try:
                with open(AI_SETTINGS_FILE, 'r') as f:
                    existing_settings = json.load(f)
            except:
                pass
        
        # Update settings
        settings = {
            'api_key': data.get('api_key', existing_settings.get('api_key')),
            'system_prompt': data.get('system_prompt', 'You are a helpful AI assistant.'),
            'model': data.get('model', existing_settings.get('model', 'claude-3-haiku-20240307'))
        }
        
        with open(AI_SETTINGS_FILE, 'w') as f:
            json.dump(settings, f, indent=2)
        
        return jsonify({'message': 'Settings saved successfully'})
    except Exception as e:
        return jsonify({'error': f'Error saving settings: {str(e)}'}), 500

@app.route('/api/aichat/send', methods=['POST'])
def send_aichat_message():
    """Send message to Claude API"""
    try:
        data = request.get_json()
        message = data.get('message', '').strip()
        conversation = data.get('conversation', [])
        system_prompt = data.get('system_prompt', 'You are a helpful AI assistant.')
        model = data.get('model', 'claude-3-haiku-20240307')
        
        if not message:
            return jsonify({'error': 'Message is required'}), 400
        
        # Load API key from settings
        api_key = None
        if os.path.exists(AI_SETTINGS_FILE):
            try:
                with open(AI_SETTINGS_FILE, 'r') as f:
                    settings = json.load(f)
                    api_key = settings.get('api_key')
            except:
                pass
        
        if not api_key:
            return jsonify({'error': 'Claude API key not configured. Please set it in Settings → API Configuration.'}), 400
        
        # Add user message to conversation
        conversation.append({
            'role': 'user',
            'content': message
        })
        
        # Prepare Claude API request
        claude_messages = []
        for msg in conversation:
            claude_messages.append({
                'role': msg['role'],
                'content': msg['content']
            })
        
        claude_request = {
            'model': model,
            'max_tokens': 1000,
            'system': system_prompt,
            'messages': claude_messages
        }
        
        # Send request to Claude API
        headers = {
            'Content-Type': 'application/json',
            'x-api-key': api_key,
            'anthropic-version': '2023-06-01'
        }
        
        response = requests.post(
            'https://api.anthropic.com/v1/messages',
            headers=headers,
            json=claude_request,
            timeout=30
        )
        
        if response.status_code == 200:
            claude_response = response.json()
            assistant_message = claude_response['content'][0]['text']
            
            # Add assistant response to conversation
            conversation.append({
                'role': 'assistant',
                'content': assistant_message
            })
            
            return jsonify({
                'response': assistant_message,
                'conversation': conversation
            })
        else:
            error_msg = f'Claude API error: {response.status_code}'
            try:
                error_data = response.json()
                if 'error' in error_data:
                    error_msg = error_data['error'].get('message', error_msg)
            except:
                pass
            
            return jsonify({'error': error_msg}), 400
            
    except requests.exceptions.Timeout:
        return jsonify({'error': 'Request timeout. Please try again.'}), 408
    except requests.exceptions.RequestException as e:
        return jsonify({'error': f'Network error: {str(e)}'}), 500
    except Exception as e:
        return jsonify({'error': f'Error processing request: {str(e)}'}), 500

# Mail API Routes
@app.route('/api/mail/config', methods=['GET'])
def get_mail_config():
    """Get mail configuration (without password)"""
    try:
        config = mail_manager.config.copy()
        # Don't send password to client
        config['password'] = '***' if config.get('password') else ''
        return jsonify(config)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/mail/config', methods=['POST'])
def save_mail_config():
    """Save mail configuration"""
    try:
        data = request.get_json()
        if not data:
            return jsonify({'error': 'No configuration data provided'}), 400
        
        # Validate required fields
        required_fields = ['imap_server', 'smtp_server', 'username']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'error': f'Missing required field: {field}'}), 400
        
        # Don't update password if it's the placeholder
        if data.get('password') == '***':
            data['password'] = mail_manager.config.get('password', '')
        
        success = mail_manager.save_config(data)
        if success:
            return jsonify({'success': True, 'message': 'Configuration saved successfully'})
        else:
            return jsonify({'error': 'Failed to save configuration'}), 500
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/mail/test-connection', methods=['POST'])
def test_mail_connection():
    """Test IMAP connection with current settings"""
    try:
        success, message = mail_manager.connect_imap()
        if success:
            mail_manager.disconnect_imap()
            return jsonify({'success': True, 'message': message})
        else:
            return jsonify({'success': False, 'message': message})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)})

@app.route('/api/mail/folders', methods=['GET'])
def get_mail_folders():
    """Get list of mail folders"""
    try:
        folders = mail_manager.get_folders()
        return jsonify({'folders': folders})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/mail/folder/<folder_name>', methods=['GET'])
def get_mail_folder_emails(folder_name):
    """Get emails from specified folder with pagination"""
    try:
        page = int(request.args.get('page', 1))
        limit = int(request.args.get('limit', 25))
        
        result = mail_manager.get_emails(folder_name, page, limit)
        
        if 'error' in result:
            return jsonify(result), 500
        
        return jsonify({
            'emails': result['emails'],
            'totalPages': result['pages'],
            'currentPage': result.get('current_page', page),
            'totalEmails': result['total']
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/mail/email/<int:email_id>', methods=['GET'])
def get_mail_email_content(email_id):
    """Get full email content by ID"""
    try:
        folder = request.args.get('folder', 'INBOX')
        result = mail_manager.get_email_content(email_id, folder)
        
        if 'error' in result:
            return jsonify(result), 404
        
        return jsonify(result)
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/mail/send', methods=['POST'])
def send_mail():
    """Send an email"""
    try:
        data = request.get_json()
        if not data:
            return jsonify({'error': 'No email data provided'}), 400
        
        # Validate required fields
        required_fields = ['to', 'subject', 'body']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'error': f'Missing required field: {field}'}), 400
        
        success, message = mail_manager.send_email(
            data['to'],
            data['subject'],
            data['body'],
            data.get('cc'),
            data.get('bcc')
        )
        
        if success:
            return jsonify({'success': True, 'message': message})
        else:
            return jsonify({'success': False, 'message': message}), 500
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/mail/status', methods=['GET'])
def get_mail_status():
    """Get mail connection status"""
    try:
        is_connected = mail_manager.imap_connection is not None
        config_complete = bool(
            mail_manager.config.get('imap_server') and 
            mail_manager.config.get('username') and 
            mail_manager.config.get('password')
        )
        
        return jsonify({
            'connected': is_connected,
            'configured': config_complete,
            'username': mail_manager.config.get('username', ''),
            'imap_server': mail_manager.config.get('imap_server', '')
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/mail/delete', methods=['POST'])
def delete_mail_emails():
    """Delete selected emails"""
    try:
        data = request.get_json()
        if not data or 'email_ids' not in data:
            return jsonify({'error': 'No email IDs provided'}), 400
        
        email_ids = data['email_ids']
        folder = data.get('folder', 'INBOX')
        
        if not email_ids:
            return jsonify({'error': 'No email IDs provided'}), 400
        
        success, message = mail_manager.delete_emails(email_ids, folder)
        
        if success:
            return jsonify({'success': True, 'message': message})
        else:
            return jsonify({'success': False, 'message': message}), 500
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/mail/mark-read', methods=['POST'])
def mark_mail_as_read():
    """Mark emails as read"""
    try:
        data = request.get_json()
        if not data or 'email_ids' not in data:
            return jsonify({'error': 'No email IDs provided'}), 400
        
        email_ids = data['email_ids']
        folder = data.get('folder', 'INBOX')
        
        if not email_ids:
            return jsonify({'error': 'No email IDs provided'}), 400
        
        success, message = mail_manager.mark_as_read(email_ids, folder)
        
        if success:
            return jsonify({'success': True, 'message': message})
        else:
            return jsonify({'success': False, 'message': message}), 500
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/mail/mark-unread', methods=['POST'])
def mark_mail_as_unread():
    """Mark emails as unread"""
    try:
        data = request.get_json()
        if not data or 'email_ids' not in data:
            return jsonify({'error': 'No email IDs provided'}), 400
        
        email_ids = data['email_ids']
        folder = data.get('folder', 'INBOX')
        
        if not email_ids:
            return jsonify({'error': 'No email IDs provided'}), 400
        
        success, message = mail_manager.mark_as_unread(email_ids, folder)
        
        if success:
            return jsonify({'success': True, 'message': message})
        else:
            return jsonify({'success': False, 'message': message}), 500
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    print(f"Starting QNX Desktop on port {PORT}...")
    print("Available paths:")
    for name, path in QNX_PATHS.items():
        accessible = os.path.exists(path) and os.access(path, os.R_OK)
        print(f"  {name}: {path} {'✓' if accessible else '✗'}")
    
    # Task manager compatibility - run without debug in production
    debug_mode = os.environ.get('FLASK_DEBUG', 'False').lower() == 'true'
    app.run(host='0.0.0.0', port=PORT, debug=debug_mode)
