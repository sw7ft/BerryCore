"""QNX Sound Architecture (libasound) capture for BB10.

Raw os.read(/dev/snd/...) returns 0 bytes. Capture has to go through
snd_pcm_plugin_read after plugin_params / plugin_prepare. Prefer
audio_manager_snd_pcm_open_name so io-audio actually routes the mic.
"""
from ctypes import (
    CDLL, POINTER, Structure, byref, c_char, c_char_p, c_int, c_int32,
    c_uint, c_uint8, c_uint32, c_void_p, create_string_buffer, sizeof,
)
import os
import time

SND_PCM_OPEN_CAPTURE = 0x0002
SND_PCM_CHANNEL_CAPTURE = 1
SND_PCM_MODE_BLOCK = 1
SND_PCM_SFMT_S16_LE = 4
SND_PCM_START_DATA = 1
SND_PCM_STOP_STOP = 1

AUDIO_TYPE_VOICE_RECOGNITION = 2
AUDIO_TYPE_VOICE_RECORDING = 5

EAGAIN = 11
EWOULDBLOCK = 11
EINVAL = 22
EIO = 5

NAMES = (
    'voice',
    'pcmPreferredc',
    'pcmPreferred',
    '/dev/snd/pcmC0D0c',
    '/dev/snd/voicec',
    '/dev/snd/defaultc',
)


class Format(Structure):
    _fields_ = [
        ('_flags', c_uint32),
        ('format', c_int32),
        ('rate', c_int32),
        ('voices', c_int32),
        ('special', c_int32),
        ('reserved', c_uint8 * 124),
    ]


class BlockBuf(Structure):
    _fields_ = [
        ('frag_size', c_int32),
        ('frags_min', c_int32),
        ('frags_max', c_int32),
        ('frags_buffered_max', c_uint32),
        ('reserved', c_uint8 * 120),
    ]


class Params(Structure):
    _fields_ = [
        ('channel', c_int32),
        ('mode', c_int32),
        ('sync', c_uint8 * 16),
        ('format', Format),
        ('digital', c_uint8 * 304),
        ('start_mode', c_int32),
        ('stop_mode', c_int32),
        ('time_flags', c_int32),
        ('why_failed', c_uint32),
        ('buf', BlockBuf),
        ('sw_mixer_subchn_name', c_char * 32),
        ('cross_core_handle', c_uint32),
        ('reserved', c_uint8 * 92),
    ]


def _find_lib(names):
    dirs = ('/lib', '/usr/lib', '/lib/dll', '/proc/boot')
    for d in dirs:
        try:
            for fn in os.listdir(d):
                for prefix in names:
                    if fn == prefix or fn.startswith(prefix + '.'):
                        path = os.path.join(d, fn)
                        if os.path.isfile(path) or os.path.islink(path):
                            return path
        except Exception:
            pass
    for n in names:
        for d in dirs:
            p = os.path.join(d, n)
            if os.path.exists(p):
                return p
    return ''


def _load():
    asound_path = _find_lib(('libasound.so',))
    if not asound_path:
        raise RuntimeError('libasound not found')
    asound = CDLL(asound_path)
    asound.snd_pcm_open_name.argtypes = [POINTER(c_void_p), c_char_p, c_int]
    asound.snd_pcm_open_name.restype = c_int
    asound.snd_pcm_open_preferred.argtypes = [
        POINTER(c_void_p), POINTER(c_int), POINTER(c_int), c_int]
    asound.snd_pcm_open_preferred.restype = c_int
    asound.snd_pcm_open.argtypes = [POINTER(c_void_p), c_int, c_int, c_int]
    asound.snd_pcm_open.restype = c_int
    asound.snd_pcm_plugin_params.argtypes = [c_void_p, POINTER(Params)]
    asound.snd_pcm_plugin_params.restype = c_int
    asound.snd_pcm_plugin_prepare.argtypes = [c_void_p, c_int]
    asound.snd_pcm_plugin_prepare.restype = c_int
    asound.snd_pcm_plugin_read.argtypes = [c_void_p, c_void_p, c_uint]
    asound.snd_pcm_plugin_read.restype = c_int
    asound.snd_pcm_close.argtypes = [c_void_p]
    asound.snd_pcm_close.restype = c_int
    asound.snd_strerror.argtypes = [c_int]
    asound.snd_strerror.restype = c_char_p
    mgr = None
    mgr_path = _find_lib(('libaudio_manager.so',))
    if mgr_path:
        mgr = CDLL(mgr_path)
        mgr.audio_manager_snd_pcm_open_name.argtypes = [
            c_int, POINTER(c_void_p), POINTER(c_uint), c_char_p, c_int]
        mgr.audio_manager_snd_pcm_open_name.restype = c_int
        mgr.audio_manager_snd_pcm_open_preferred.argtypes = [
            c_int, POINTER(c_void_p), POINTER(c_uint),
            POINTER(c_int), POINTER(c_int), c_int]
        mgr.audio_manager_snd_pcm_open_preferred.restype = c_int
        mgr.audio_manager_free_handle.argtypes = [c_uint]
        mgr.audio_manager_free_handle.restype = c_int
    return asound, mgr, asound_path, mgr_path


def _err(asound, rc):
    try:
        s = asound.snd_strerror(int(rc))
        if s:
            return '%s (%s)' % (s.decode('ascii', 'replace'), rc)
    except Exception:
        pass
    return 'rc=%s' % rc


def _fill_params(rate, voices, frag):
    p = Params()
    p.channel = SND_PCM_CHANNEL_CAPTURE
    p.mode = SND_PCM_MODE_BLOCK
    p.format._flags = 1
    p.format.format = SND_PCM_SFMT_S16_LE
    p.format.rate = rate
    p.format.voices = voices
    p.start_mode = SND_PCM_START_DATA
    p.stop_mode = SND_PCM_STOP_STOP
    p.buf.frag_size = frag
    p.buf.frags_min = 1
    p.buf.frags_max = 3
    return p


def _open_attempts(asound, mgr):
    attempts = []
    if mgr is not None:
        for typ in (AUDIO_TYPE_VOICE_RECORDING, AUDIO_TYPE_VOICE_RECOGNITION):
            for name in ('voice', 'pcmPreferredc', 'pcmPreferred'):
                attempts.append(('mgr_name', typ, name))
            attempts.append(('mgr_pref', typ, ''))
    for name in NAMES:
        attempts.append(('name', 0, name))
    attempts.append(('pref', 0, ''))
    attempts.append(('card', 0, '0:0'))
    return attempts


def _open_one(asound, mgr, kind, typ, name):
    pcm = c_void_p()
    amh = c_uint(0)
    card = c_int(0)
    dev = c_int(0)
    if kind == 'mgr_name':
        rc = mgr.audio_manager_snd_pcm_open_name(
            typ, byref(pcm), byref(amh), name.encode('ascii'),
            SND_PCM_OPEN_CAPTURE)
        label = 'audio_manager name=%s type=%s' % (name, typ)
    elif kind == 'mgr_pref':
        rc = mgr.audio_manager_snd_pcm_open_preferred(
            typ, byref(pcm), byref(amh), byref(card), byref(dev),
            SND_PCM_OPEN_CAPTURE)
        label = 'audio_manager preferred type=%s card=%s dev=%s' % (
            typ, card.value, dev.value)
    elif kind == 'name':
        rc = asound.snd_pcm_open_name(
            byref(pcm), name.encode('ascii'), SND_PCM_OPEN_CAPTURE)
        label = 'open_name %s' % name
    elif kind == 'pref':
        rc = asound.snd_pcm_open_preferred(
            byref(pcm), byref(card), byref(dev), SND_PCM_OPEN_CAPTURE)
        label = 'open_preferred card=%s dev=%s' % (card.value, dev.value)
    else:
        rc = asound.snd_pcm_open(byref(pcm), 0, 0, SND_PCM_OPEN_CAPTURE)
        label = 'open card=0 device=0'
    return rc, pcm, amh, label


def capture_pcm(seconds, log=None, stop=None):
    """Record mono S16_LE PCM. Returns dict with ok/pcm/rate/dev/message."""
    def note(msg):
        if log:
            log(msg)
    def stopped():
        return bool(stop) and stop.is_set()

    asound, mgr, asound_path, mgr_path = _load()
    note('libasound %s  audio_manager %s  params=%s' % (
        asound_path, mgr_path or 'none', sizeof(Params)))
    last_err = 'no capture device opened'
    for kind, typ, name in _open_attempts(asound, mgr):
        if stopped():
            return {'ok': False, 'pcm': b'', 'rate': 0, 'voices': 1, 'dev': '',
                    'message': 'stopped'}
        rc, pcm, amh, label = _open_one(asound, mgr, kind, typ, name)
        if rc != 0 or not pcm.value:
            note('open fail %s %s' % (label, _err(asound, rc)))
            last_err = '%s: %s' % (label, _err(asound, rc))
            continue
        note('opened %s' % label)
        got = None
        for rate, voices, frag in (
            (16000, 1, 2048),
            (16000, 1, 4096),
            (44100, 1, 4096),
            (48000, 1, 4096),
            (16000, 2, 4096),
        ):
            params = _fill_params(rate, voices, frag)
            prc = asound.snd_pcm_plugin_params(pcm, byref(params))
            if prc != 0:
                note('params rate=%s voices=%s frag=%s fail %s why=%s' % (
                    rate, voices, frag, _err(asound, prc), params.why_failed))
                continue
            prep = asound.snd_pcm_plugin_prepare(pcm, SND_PCM_CHANNEL_CAPTURE)
            if prep != 0:
                note('prepare fail %s' % _err(asound, prep))
                continue
            raw = bytearray()
            buf = create_string_buffer(frag)
            t0 = time.time()
            while (not stopped()) and (time.time() - t0) < seconds:
                n = asound.snd_pcm_plugin_read(pcm, buf, frag)
                if n > 0:
                    raw.extend(buf.raw[:n])
                elif n == 0 or n in (-EAGAIN, -EWOULDBLOCK):
                    time.sleep(0.005)
                else:
                    asound.snd_pcm_plugin_prepare(pcm, SND_PCM_CHANNEL_CAPTURE)
                    time.sleep(0.01)
            if len(raw) > 0:
                got = {
                    'ok': True,
                    'pcm': bytes(raw),
                    'rate': rate,
                    'voices': voices,
                    'dev': label,
                    'message': '',
                }
                break
            note('read 0 bytes after %.2fs rate=%s' % (time.time() - t0, rate))
        try:
            asound.snd_pcm_close(pcm)
        except Exception:
            pass
        if mgr is not None and amh.value:
            try:
                mgr.audio_manager_free_handle(amh)
            except Exception:
                pass
        if got:
            return got
        last_err = '%s opened but plugin_read returned 0 bytes' % label
    return {'ok': False, 'pcm': b'', 'rate': 0, 'voices': 1, 'dev': '',
            'message': last_err}


if __name__ == '__main__':
    import sys
    sec = float(sys.argv[1]) if len(sys.argv) > 1 else 1.0
    r = capture_pcm(sec, log=lambda m: sys.stderr.write(m + '\n'))
    sys.stderr.flush()
    print('ok=%s bytes=%s rate=%s voices=%s dev=%s msg=%s' % (
        r.get('ok'), len(r.get('pcm') or b''), r.get('rate'),
        r.get('voices'), r.get('dev'), r.get('message')))
