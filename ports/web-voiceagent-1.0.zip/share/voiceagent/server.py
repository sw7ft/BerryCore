#!/usr/bin/env python3
"""
VoiceAgent - BB10 Voice Agent Server
A voice assistant for BlackBerry 10 powered by OpenAI APIs.

Uses only Python 3.11 built-in modules + curl subprocess for API calls.
No pip packages required.

APIs used:
  - OpenAI Whisper (speech-to-text)
  - OpenAI GPT-4o (chat completions)
  - OpenAI TTS-1 (text-to-speech)
"""

import http.server
import json
import os
import subprocess
import sys
import tempfile
import time
import uuid
import base64
import urllib.parse
import mimetypes
import signal
import threading
import shutil
import struct
from pathlib import Path

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

SCRIPT_DIR = Path(__file__).resolve().parent
STATIC_DIR = SCRIPT_DIR / "static"
CONFIG_FILE = SCRIPT_DIR / "config.json"
AUDIO_DIR = SCRIPT_DIR / "audio_cache"
LOG_FILE = SCRIPT_DIR / "voiceagent.log"

DEFAULT_CONFIG = {
    "openai_api_key": "",
    "model": "gpt-4o",
    "whisper_model": "whisper-1",
    "tts_model": "tts-1",
    "tts_voice": "alloy",
    "system_prompt": (
        "You are a helpful, friendly voice assistant running on a BlackBerry 10 device. "
        "Keep responses concise and conversational since they will be spoken aloud. "
        "Limit responses to 2-3 sentences unless the user asks for detail."
    ),
    "max_history": 20,
    "port": 8085,
}

# In-memory conversation history (reset on server restart)
conversation_history = []

# Server-side recording state
recording_process = None
recording_file = None

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def log(msg):
    """Write a log message to stderr and optionally to log file."""
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{ts}] {msg}"
    print(line, file=sys.stderr, flush=True)


def load_config():
    """Load or create config.json."""
    if CONFIG_FILE.exists():
        try:
            with open(CONFIG_FILE, "r") as f:
                cfg = json.load(f)
            # Merge with defaults for any missing keys
            for k, v in DEFAULT_CONFIG.items():
                cfg.setdefault(k, v)
            return cfg
        except Exception as e:
            log(f"Config load error: {e}, using defaults")
    return dict(DEFAULT_CONFIG)


def save_config(cfg):
    """Persist config to disk."""
    with open(CONFIG_FILE, "w") as f:
        json.dump(cfg, f, indent=2)
    log("Config saved")


def find_curl():
    """Locate curl binary - check BerryCore paths first."""
    for p in [
        os.environ.get("NATIVE_TOOLS", "") + "/bin/curl",
        "/accounts/1000/shared/misc/berrycore/bin/curl",
        "/usr/bin/curl",
    ]:
        if p and os.path.isfile(p) and os.access(p, os.X_OK):
            return p
    # Fallback: hope it's in PATH
    return "curl"


def find_ca_certs():
    """Locate CA certificate bundle for HTTPS."""
    for p in [
        os.environ.get("NATIVE_TOOLS", "") + "/etc/ssl/certs/cacert.pem",
        os.environ.get("NATIVE_TOOLS", "") + "/share/cacert/cacert.pem",
        "/accounts/1000/shared/misc/berrycore/etc/ssl/certs/cacert.pem",
        "/accounts/1000/shared/misc/berrycore/share/cacert/cacert.pem",
        "/etc/ssl/certs/ca-certificates.crt",
        "/etc/ssl/certs/cacert.pem",
    ]:
        if p and os.path.isfile(p):
            return p
    return None


CURL_BIN = find_curl()
CA_CERTS = find_ca_certs()


def curl_base_args():
    """Common curl arguments."""
    args = [CURL_BIN, "-s", "--max-time", "60"]
    if CA_CERTS:
        args += ["--cacert", CA_CERTS]
    else:
        # Fallback: allow insecure if no CA certs found (dev only)
        args += ["-k"]
    return args


# ---------------------------------------------------------------------------
# OpenAI API calls (via curl subprocess)
# ---------------------------------------------------------------------------

def whisper_transcribe(audio_path):
    """
    Send audio file to OpenAI Whisper API for transcription.
    Returns transcribed text or raises on error.
    """
    cfg = load_config()
    api_key = cfg.get("openai_api_key", "")
    if not api_key:
        raise ValueError("OpenAI API key not configured")

    cmd = curl_base_args() + [
        "-X", "POST",
        "https://api.openai.com/v1/audio/transcriptions",
        "-H", f"Authorization: Bearer {api_key}",
        "-F", f"file=@{audio_path}",
        "-F", f"model={cfg.get('whisper_model', 'whisper-1')}",
        "-F", "response_format=json",
    ]

    log(f"Whisper: transcribing {audio_path}")
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=120)

    if result.returncode != 0:
        raise RuntimeError(f"curl failed: {result.stderr}")

    resp = json.loads(result.stdout)
    if "error" in resp:
        raise RuntimeError(f"Whisper error: {resp['error']}")

    text = resp.get("text", "").strip()
    log(f"Whisper result: {text[:80]}...")
    return text


def chat_completion(user_text):
    """
    Send conversation to GPT-4o and return assistant response.
    Maintains conversation history in memory.
    """
    cfg = load_config()
    api_key = cfg.get("openai_api_key", "")
    if not api_key:
        raise ValueError("OpenAI API key not configured")

    # Build messages array
    messages = [{"role": "system", "content": cfg.get("system_prompt", "")}]
    messages.extend(conversation_history)
    messages.append({"role": "user", "content": user_text})

    payload = {
        "model": cfg.get("model", "gpt-4o"),
        "messages": messages,
        "max_tokens": 300,
    }

    payload_json = json.dumps(payload)

    cmd = curl_base_args() + [
        "-X", "POST",
        "https://api.openai.com/v1/chat/completions",
        "-H", f"Authorization: Bearer {api_key}",
        "-H", "Content-Type: application/json",
        "-d", payload_json,
    ]

    log(f"GPT-4o: sending message ({len(user_text)} chars)")
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=120)

    if result.returncode != 0:
        raise RuntimeError(f"curl failed: {result.stderr}")

    resp = json.loads(result.stdout)
    if "error" in resp:
        raise RuntimeError(f"GPT error: {resp['error']}")

    assistant_text = resp["choices"][0]["message"]["content"].strip()
    log(f"GPT-4o result: {assistant_text[:80]}...")

    # Update conversation history
    conversation_history.append({"role": "user", "content": user_text})
    conversation_history.append({"role": "assistant", "content": assistant_text})

    # Trim history if too long
    max_h = cfg.get("max_history", 20) * 2  # pairs of user+assistant
    while len(conversation_history) > max_h:
        conversation_history.pop(0)

    return assistant_text


def tts_speak(text):
    """
    Send text to OpenAI TTS API and return path to audio file.
    Returns (file_path, content_type).
    """
    cfg = load_config()
    api_key = cfg.get("openai_api_key", "")
    if not api_key:
        raise ValueError("OpenAI API key not configured")

    AUDIO_DIR.mkdir(parents=True, exist_ok=True)
    audio_file = AUDIO_DIR / f"tts_{uuid.uuid4().hex[:8]}.mp3"

    payload = {
        "model": cfg.get("tts_model", "tts-1"),
        "voice": cfg.get("tts_voice", "alloy"),
        "input": text,
    }

    cmd = curl_base_args() + [
        "-X", "POST",
        "https://api.openai.com/v1/audio/speech",
        "-H", f"Authorization: Bearer {api_key}",
        "-H", "Content-Type: application/json",
        "-d", json.dumps(payload),
        "--output", str(audio_file),
    ]

    log(f"TTS: generating speech ({len(text)} chars)")
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=120)

    if result.returncode != 0:
        raise RuntimeError(f"curl failed: {result.stderr}")

    if not audio_file.exists() or audio_file.stat().st_size < 100:
        # Check if error was returned as text
        if audio_file.exists():
            err_text = audio_file.read_text(errors="replace")
            if "error" in err_text:
                audio_file.unlink(missing_ok=True)
                raise RuntimeError(f"TTS error: {err_text[:200]}")
        raise RuntimeError("TTS produced no audio")

    log(f"TTS: saved {audio_file} ({audio_file.stat().st_size} bytes)")
    return str(audio_file), "audio/mpeg"


def cleanup_old_audio():
    """Remove audio files older than 10 minutes."""
    if not AUDIO_DIR.exists():
        return
    cutoff = time.time() - 600
    for f in AUDIO_DIR.iterdir():
        try:
            if f.stat().st_mtime < cutoff:
                f.unlink()
        except Exception:
            pass


# ---------------------------------------------------------------------------
# HTTP Server
# ---------------------------------------------------------------------------

class VoiceAgentHandler(http.server.BaseHTTPRequestHandler):
    """HTTP request handler for the Voice Agent."""

    server_version = "VoiceAgent/1.0"

    def log_message(self, format, *args):
        """Override to use our logger."""
        log(f"HTTP: {format % args}")

    # -- Routing --

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path.rstrip("/") or "/"

        if path == "/":
            self.serve_static("index.html")
        elif path == "/style.css":
            self.serve_static("style.css")
        elif path == "/app.js":
            self.serve_static("app.js")
        elif path == "/api/config":
            self.handle_get_config()
        elif path == "/api/history":
            self.handle_get_history()
        elif path.startswith("/audio_cache/"):
            self.serve_audio(path)
        elif path == "/api/health":
            self.send_json({"status": "ok", "version": "1.0"})
        elif path == "/api/record/status":
            self.send_json({
                "recording": recording_process is not None,
                "ffmpeg": FFMPEG_BIN,
            })
        elif path == "/api/record/start":
            # Also handle via GET in case browser sends GET instead of POST
            self.handle_record_start()
        elif path == "/api/record/stop":
            self.handle_record_stop()
        else:
            self.send_error_json(404, "Not found")

    def do_POST(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path.rstrip("/")
        log(f"POST {path}")

        if path == "/api/voice":
            self.handle_voice()
        elif path == "/api/text":
            self.handle_text()
        elif path == "/api/config":
            self.handle_set_config()
        elif path == "/api/clear":
            self.handle_clear_history()
        elif path == "/api/record/start":
            self.handle_record_start()
        elif path == "/api/record/stop":
            self.handle_record_stop()
        else:
            log(f"POST 404: {path}")
            self.send_error_json(404, "Not found")

    def do_OPTIONS(self):
        """Handle CORS preflight."""
        self.send_response(200)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

    # -- Static files --

    def serve_static(self, filename):
        filepath = STATIC_DIR / filename
        if not filepath.exists():
            self.send_error_json(404, f"File not found: {filename}")
            return

        content_type, _ = mimetypes.guess_type(str(filepath))
        if content_type is None:
            content_type = "application/octet-stream"

        data = filepath.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", len(data))
        self.send_header("Cache-Control", "no-cache")
        self.end_headers()
        self.wfile.write(data)

    def serve_audio(self, path):
        """Serve cached audio files."""
        filename = path.split("/")[-1]
        filepath = AUDIO_DIR / filename
        if not filepath.exists():
            self.send_error_json(404, "Audio not found")
            return

        data = filepath.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", "audio/mpeg")
        self.send_header("Content-Length", len(data))
        self.end_headers()
        self.wfile.write(data)

    # -- API Handlers --

    def handle_voice(self):
        """
        Handle voice input: receive audio, transcribe, chat, speak.
        Expects multipart/form-data with 'audio' file field,
        OR raw audio bytes with Content-Type header.
        """
        try:
            content_type = self.headers.get("Content-Type", "")
            content_length = int(self.headers.get("Content-Length", 0))

            if content_length == 0 or content_length > 25 * 1024 * 1024:
                self.send_error_json(400, "Invalid audio size (max 25MB)")
                return

            body = self.rfile.read(content_length)

            # Determine audio format and save to temp file
            if "webm" in content_type:
                ext = ".webm"
            elif "ogg" in content_type:
                ext = ".ogg"
            elif "wav" in content_type:
                ext = ".wav"
            elif "mp4" in content_type or "m4a" in content_type:
                ext = ".m4a"
            elif "mpeg" in content_type or "mp3" in content_type:
                ext = ".mp3"
            elif "amr" in content_type:
                ext = ".amr"
            elif "3gpp" in content_type or "3gp" in content_type:
                ext = ".3gp"
            elif "aac" in content_type:
                ext = ".aac"
            else:
                # Try to detect from magic bytes
                if body[:4] == b'RIFF':
                    ext = ".wav"
                elif body[:3] == b'#!A':
                    ext = ".amr"
                elif body[:4] == b'ftyp' or (len(body) > 4 and body[4:8] == b'ftyp'):
                    ext = ".m4a"
                else:
                    ext = ".wav"  # default fallback

            # Save uploaded audio to temp file
            AUDIO_DIR.mkdir(parents=True, exist_ok=True)
            audio_path = AUDIO_DIR / f"input_{uuid.uuid4().hex[:8]}{ext}"
            audio_path.write_bytes(body)
            log(f"Received audio: {len(body)} bytes, type={content_type}, saved={audio_path}")

            # If format isn't directly supported by Whisper, convert via ffmpeg
            whisper_supported = (".mp3", ".wav", ".m4a", ".webm", ".mp4", ".ogg", ".flac")
            whisper_path = audio_path
            if ext not in whisper_supported:
                converted = AUDIO_DIR / f"converted_{uuid.uuid4().hex[:8]}.wav"
                log(f"Converting {ext} to .wav for Whisper...")
                ffmpeg_convert(str(audio_path), str(converted))
                if converted.exists() and converted.stat().st_size > 50:
                    whisper_path = converted
                else:
                    log(f"Conversion failed, trying original file")

            # Pipeline: STT -> Chat -> TTS
            transcript = whisper_transcribe(str(whisper_path))
            if not transcript:
                self.send_error_json(400, "Could not transcribe audio - no speech detected")
                return

            response_text = chat_completion(transcript)
            audio_file, audio_content_type = tts_speak(response_text)

            # Build response
            audio_filename = Path(audio_file).name
            result = {
                "success": True,
                "user_text": transcript,
                "assistant_text": response_text,
                "audio_url": f"/audio_cache/{audio_filename}",
            }

            self.send_json(result)

            # Cleanup in background
            threading.Thread(target=cleanup_old_audio, daemon=True).start()

        except ValueError as e:
            self.send_error_json(401, str(e))
        except Exception as e:
            log(f"Voice error: {e}")
            self.send_error_json(500, f"Voice processing failed: {e}")

    def handle_text(self):
        """Handle text-only input (type a message instead of speaking)."""
        try:
            body = self._read_json_body()
            if not body:
                return

            user_text = body.get("text", "").strip()
            if not user_text:
                self.send_error_json(400, "No text provided")
                return

            response_text = chat_completion(user_text)
            audio_file, _ = tts_speak(response_text)
            audio_filename = Path(audio_file).name

            result = {
                "success": True,
                "user_text": user_text,
                "assistant_text": response_text,
                "audio_url": f"/audio_cache/{audio_filename}",
            }
            self.send_json(result)

            threading.Thread(target=cleanup_old_audio, daemon=True).start()

        except ValueError as e:
            self.send_error_json(401, str(e))
        except Exception as e:
            log(f"Text error: {e}")
            self.send_error_json(500, f"Text processing failed: {e}")

    def handle_get_config(self):
        """Return current config (API key masked)."""
        cfg = load_config()
        safe_cfg = dict(cfg)
        key = safe_cfg.get("openai_api_key", "")
        if key:
            safe_cfg["openai_api_key"] = key[:7] + "..." + key[-4:] if len(key) > 11 else "***"
            safe_cfg["api_key_set"] = True
        else:
            safe_cfg["api_key_set"] = False
        self.send_json(safe_cfg)

    def handle_set_config(self):
        """Update config from JSON body."""
        body = self._read_json_body()
        if not body:
            return

        cfg = load_config()

        # Update allowed fields
        allowed = ["openai_api_key", "model", "tts_voice", "system_prompt", "max_history"]
        for key in allowed:
            if key in body and body[key] is not None:
                cfg[key] = body[key]

        save_config(cfg)
        self.send_json({"success": True, "message": "Configuration saved"})

    def handle_get_history(self):
        """Return conversation history."""
        self.send_json({"history": conversation_history})

    def handle_clear_history(self):
        """Clear conversation history."""
        global conversation_history
        conversation_history = []
        self.send_json({"success": True, "message": "History cleared"})

    def handle_record_start(self):
        """Start server-side audio recording via ffmpeg."""
        # Drain any POST body
        try:
            cl = int(self.headers.get("Content-Length", 0))
            if cl > 0:
                self.rfile.read(cl)
        except Exception:
            pass

        try:
            ok, msg = start_server_recording()
            log(f"Record start result: ok={ok}, msg={msg}")
            if ok:
                self.send_json({"success": True, "message": msg})
            else:
                self.send_error_json(500, msg)
        except Exception as e:
            log(f"Record start error: {e}")
            self.send_error_json(500, str(e))

    def handle_record_stop(self):
        """Stop server-side recording, then run full voice pipeline."""
        # Drain any POST body
        try:
            cl = int(self.headers.get("Content-Length", 0))
            if cl > 0:
                self.rfile.read(cl)
        except Exception:
            pass

        try:
            audio_path, msg = stop_server_recording()
            if not audio_path:
                self.send_error_json(500, msg)
                return

            # Run the full pipeline: STT -> Chat -> TTS
            transcript = whisper_transcribe(audio_path)
            if not transcript:
                self.send_error_json(400, "Could not transcribe audio - no speech detected")
                return

            response_text = chat_completion(transcript)
            audio_file, audio_content_type = tts_speak(response_text)

            audio_filename = Path(audio_file).name
            result = {
                "success": True,
                "user_text": transcript,
                "assistant_text": response_text,
                "audio_url": f"/audio_cache/{audio_filename}",
            }
            self.send_json(result)

            threading.Thread(target=cleanup_old_audio, daemon=True).start()

        except ValueError as e:
            self.send_error_json(401, str(e))
        except Exception as e:
            log(f"Record stop error: {e}")
            self.send_error_json(500, f"Voice processing failed: {e}")

    # -- Utilities --

    def _read_json_body(self):
        """Read and parse JSON body. Returns dict or None on error."""
        try:
            length = int(self.headers.get("Content-Length", 0))
            if length == 0:
                self.send_error_json(400, "Empty body")
                return None
            raw = self.rfile.read(length)
            return json.loads(raw)
        except (json.JSONDecodeError, ValueError) as e:
            self.send_error_json(400, f"Invalid JSON: {e}")
            return None

    def send_json(self, data, status=200):
        """Send a JSON response."""
        body = json.dumps(data).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", len(body))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def send_error_json(self, status, message):
        """Send a JSON error response."""
        self.send_json({"error": message}, status=status)


def find_binary(names, extra_paths=None):
    """Find a binary by checking multiple names and paths."""
    paths = [
        os.environ.get("NATIVE_TOOLS", "") + "/bin",
        "/accounts/1000/shared/misc/berrycore/bin",
        "/usr/bin",
        "/usr/local/bin",
        "/opt/bin",
    ]
    if extra_paths:
        paths = extra_paths + paths
    for name in names:
        for d in paths:
            p = os.path.join(d, name)
            if p and os.path.isfile(p) and os.access(p, os.X_OK):
                return p
        # Try PATH
        found = shutil.which(name)
        if found:
            return found
    return None


FFMPEG_BIN = find_binary(["ffmpeg"]) or "ffmpeg"
WAVEREC_BIN = find_binary(["waverec"])

# Recording method: 'waverec', 'ffmpeg', or None
RECORD_METHOD = None
RECORD_AUDIO_INPUT = None


def find_pcm_capture_devices():
    """Find QNX PCM capture device paths under /dev/snd/."""
    devices = []
    snd_dir = "/dev/snd"
    if os.path.isdir(snd_dir):
        try:
            for entry in os.listdir(snd_dir):
                # Capture devices end in 'c' (e.g., pcmC0D0c)
                if entry.startswith("pcm") and entry.endswith("c"):
                    devices.append(os.path.join(snd_dir, entry))
        except Exception:
            pass
    return devices


def detect_recording_method():
    """
    Detect the best available recording method on this system.
    Returns ('waverec', None), ('ffmpeg', audio_input_args), or (None, None).
    """
    # Method 1: waverec (QNX native, best for BB10)
    if WAVEREC_BIN:
        log(f"Found waverec: {WAVEREC_BIN}")
        # Quick test: try a very short recording
        try:
            AUDIO_DIR.mkdir(parents=True, exist_ok=True)
            test_file = str(AUDIO_DIR / "waverec_test.wav")
            result = subprocess.run(
                [WAVEREC_BIN, "-m", "-r", "16000", "-t", "1", test_file],
                capture_output=True, text=True, timeout=5
            )
            if result.returncode == 0 and os.path.exists(test_file) and os.path.getsize(test_file) > 50:
                os.unlink(test_file)
                log("waverec test: SUCCESS")
                return "waverec", None
            else:
                log(f"waverec test failed: rc={result.returncode}, stderr={result.stderr[:200]}")
                try:
                    os.unlink(test_file)
                except Exception:
                    pass
        except Exception as e:
            log(f"waverec test error: {e}")

    # Method 2: ffmpeg with various audio inputs
    # Build list of inputs to try, including discovered PCM devices
    ffmpeg_inputs = [
        # QNX QSA
        ["-f", "qsa", "-i", "default"],
        # ALSA
        ["-f", "alsa", "-i", "default"],
        ["-f", "alsa", "-i", "hw:0,0"],
    ]
    # Add any discovered PCM capture devices
    for dev in find_pcm_capture_devices():
        ffmpeg_inputs.append(["-f", "qsa", "-i", dev])
        ffmpeg_inputs.append(["-f", "alsa", "-i", dev])
    # Generic fallbacks
    ffmpeg_inputs += [
        ["-f", "oss", "-i", "/dev/dsp"],
        ["-f", "oss", "-i", "/dev/audio"],
        ["-f", "pulse", "-i", "default"],
        ["-f", "sndio", "-i", "default"],
    ]

    for input_args in ffmpeg_inputs:
        try:
            AUDIO_DIR.mkdir(parents=True, exist_ok=True)
            test_file = str(AUDIO_DIR / "ffmpeg_test.wav")
            cmd = [FFMPEG_BIN, "-y"] + input_args + [
                "-t", "0.1", "-ar", "16000", "-ac", "1", test_file
            ]
            result = subprocess.run(
                cmd, capture_output=True, text=True, timeout=5
            )
            if result.returncode == 0 and os.path.exists(test_file) and os.path.getsize(test_file) > 50:
                os.unlink(test_file)
                log(f"ffmpeg audio input detected: {' '.join(input_args)}")
                return "ffmpeg", input_args
            else:
                log(f"ffmpeg tried {' '.join(input_args)}: rc={result.returncode}")
        except Exception as e:
            log(f"ffmpeg tried {' '.join(input_args)}: error {e}")
        finally:
            try:
                if os.path.exists(test_file):
                    os.unlink(test_file)
            except Exception:
                pass

    # Method 3: Direct PCM device read (Python)
    for dev in find_pcm_capture_devices():
        try:
            # Try opening the device for reading
            fd = os.open(dev, os.O_RDONLY | os.O_NONBLOCK)
            os.close(fd)
            log(f"PCM capture device readable: {dev}")
            return "pcm_raw", [dev]
        except Exception:
            pass

    log("WARNING: No recording method detected")
    return None, None


def start_server_recording():
    """Start recording audio on the device."""
    global recording_process, recording_file, RECORD_METHOD, RECORD_AUDIO_INPUT

    if recording_process is not None:
        log("Recording already in progress")
        return False, "Already recording"

    # Detect recording method if not cached
    if RECORD_METHOD is None:
        RECORD_METHOD, RECORD_AUDIO_INPUT = detect_recording_method()

    if RECORD_METHOD is None:
        return False, "No audio input device found. Check microphone access."

    AUDIO_DIR.mkdir(parents=True, exist_ok=True)
    recording_file = str(AUDIO_DIR / f"rec_{uuid.uuid4().hex[:8]}.wav")

    if RECORD_METHOD == "waverec":
        # waverec -m (mono) -r 16000 -t 30 (max 30 sec) output.wav
        cmd = [WAVEREC_BIN, "-m", "-r", "16000", "-t", "30", recording_file]
        log(f"Starting waverec: {' '.join(cmd)}")
        try:
            recording_process = subprocess.Popen(
                cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE
            )
            return True, "Recording started (waverec)"
        except Exception as e:
            recording_process = None
            recording_file = None
            return False, str(e)

    elif RECORD_METHOD == "ffmpeg":
        cmd = [FFMPEG_BIN, "-y"] + RECORD_AUDIO_INPUT + [
            "-ar", "16000", "-ac", "1", "-acodec", "pcm_s16le",
            recording_file
        ]
        log(f"Starting ffmpeg recording: {' '.join(cmd)}")
        try:
            recording_process = subprocess.Popen(
                cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE
            )
            return True, "Recording started (ffmpeg)"
        except Exception as e:
            recording_process = None
            recording_file = None
            return False, str(e)

    elif RECORD_METHOD == "pcm_raw":
        # Direct PCM device read - start a Python thread to read raw audio
        dev_path = RECORD_AUDIO_INPUT[0]
        log(f"Starting raw PCM capture from {dev_path}")
        import threading

        def pcm_record_thread(device, outfile):
            """Read raw PCM data from QNX audio device and write WAV."""
            try:
                fd = os.open(device, os.O_RDONLY)
                raw_data = bytearray()
                start = time.time()
                while recording_process is not None and (time.time() - start) < 30:
                    try:
                        chunk = os.read(fd, 4096)
                        if chunk:
                            raw_data.extend(chunk)
                    except Exception:
                        time.sleep(0.01)
                os.close(fd)

                # Write WAV file
                sample_rate = 16000
                num_channels = 1
                bits_per_sample = 16
                data_size = len(raw_data)
                with open(outfile, 'wb') as f:
                    f.write(b'RIFF')
                    f.write(struct.pack('<I', 36 + data_size))
                    f.write(b'WAVE')
                    f.write(b'fmt ')
                    f.write(struct.pack('<I', 16))
                    f.write(struct.pack('<H', 1))  # PCM
                    f.write(struct.pack('<H', num_channels))
                    f.write(struct.pack('<I', sample_rate))
                    f.write(struct.pack('<I', sample_rate * num_channels * bits_per_sample // 8))
                    f.write(struct.pack('<H', num_channels * bits_per_sample // 8))
                    f.write(struct.pack('<H', bits_per_sample))
                    f.write(b'data')
                    f.write(struct.pack('<I', data_size))
                    f.write(raw_data)
                log(f"Raw PCM recording saved: {outfile} ({data_size} bytes)")
            except Exception as e:
                log(f"Raw PCM recording error: {e}")

        recording_process = "pcm_thread"  # sentinel
        t = threading.Thread(target=pcm_record_thread, args=(dev_path, recording_file))
        t.daemon = True
        t.start()
        return True, "Recording started (raw PCM)"

    return False, "Unknown recording method"


def stop_server_recording():
    """Stop recording and return the audio file path."""
    global recording_process, recording_file

    if recording_process is None:
        return None, "Not recording"

    if RECORD_METHOD == "waverec":
        # waverec runs for -t seconds then exits. Kill it early.
        try:
            if hasattr(recording_process, 'kill'):
                recording_process.terminate()
                recording_process.wait(timeout=3)
        except Exception:
            try:
                recording_process.kill()
                recording_process.wait(timeout=2)
            except Exception:
                pass

    elif RECORD_METHOD == "ffmpeg":
        # Send 'q' to ffmpeg stdin to stop gracefully
        try:
            recording_process.stdin.write(b"q")
            recording_process.stdin.flush()
        except Exception:
            pass
        try:
            recording_process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            recording_process.kill()
            recording_process.wait(timeout=2)

    elif RECORD_METHOD == "pcm_raw":
        # Just set sentinel to None; the thread checks this
        pass

    time.sleep(0.5)  # Give a moment for file to flush

    proc = recording_process
    path = recording_file
    recording_process = None
    recording_file = None

    if path and os.path.exists(path) and os.path.getsize(path) > 100:
        log(f"Recording saved: {path} ({os.path.getsize(path)} bytes)")
        return path, "OK"
    else:
        log(f"Recording failed: file missing or empty at {path}")
        return None, "Recording produced no audio"


def ffmpeg_convert(input_path, output_path):
    """Convert audio via ffmpeg (available from BerryCore)."""
    cmd = [FFMPEG_BIN, "-y", "-i", input_path, "-ar", "16000", "-ac", "1", output_path]
    log(f"ffmpeg: converting {input_path} -> {output_path}")
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
    if result.returncode != 0:
        log(f"ffmpeg error: {result.stderr[:200]}")
        raise RuntimeError(f"ffmpeg conversion failed: {result.stderr[:200]}")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    cfg = load_config()
    port = cfg.get("port", 8085)

    # Create audio cache directory
    AUDIO_DIR.mkdir(parents=True, exist_ok=True)

    # Save default config if none exists
    if not CONFIG_FILE.exists():
        save_config(cfg)
        log(f"Created default config at {CONFIG_FILE}")

    # Detect recording method for server-side recording
    global RECORD_METHOD, RECORD_AUDIO_INPUT
    log("Detecting recording method...")
    RECORD_METHOD, RECORD_AUDIO_INPUT = detect_recording_method()
    if RECORD_METHOD:
        log(f"Recording method: {RECORD_METHOD} {RECORD_AUDIO_INPUT or ''}")
    else:
        log("No server-side recording method found")
        log("  (Voice recording will rely on browser <input capture> or getUserMedia)")

    server = http.server.HTTPServer(("0.0.0.0", port), VoiceAgentHandler)
    log(f"VoiceAgent server v1.2 starting on port {port}")
    log(f"Open http://127.0.0.1:{port} in BB10 browser")
    log(f"curl: {CURL_BIN}")
    log(f"ffmpeg: {FFMPEG_BIN}")
    log(f"waverec: {WAVEREC_BIN or 'not found'}")
    log(f"CA certs: {CA_CERTS or 'not found (using -k)'}")
    log(f"Endpoints: /api/voice, /api/text, /api/record/start, /api/record/stop")

    def shutdown_handler(sig, frame):
        log("Shutting down...")
        server.shutdown()
        sys.exit(0)

    signal.signal(signal.SIGINT, shutdown_handler)
    signal.signal(signal.SIGTERM, shutdown_handler)

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        log("Interrupted, shutting down")
        server.shutdown()


if __name__ == "__main__":
    main()
