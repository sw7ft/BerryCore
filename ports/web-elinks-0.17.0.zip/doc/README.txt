ELinks 0.17.0 - FINAL BUILD - SSL + JavaScript!
================================================

✅ SSL/TLS: ENABLED (OpenSSL 1.0.1i)
✅ JavaScript: ENABLED (QuickJS ES2020+)
✅ CSS: ENABLED (libcss + libdom)
✅ Static C++ Runtime (no crashes!)
✅ App Sandbox Compatible!

WHAT'S NEW IN THIS BUILD
-------------------------
✓ SSL/TLS support now WORKING (https:// sites!)
✓ OpenSSL 1.0.1i from QNX system
✓ Launcher detects app sandbox and fixes HOME
✓ Works in Android-style sandboxed environments
✓ Falls back to /tmp if HOME is read-only

FEATURES
--------
- Browse HTTPS sites securely
- Full JavaScript engine (QuickJS)
- CSS rendering
- HTML5 parsing
- HTTP/HTTPS/FTP protocols
- Cookies, bookmarks, history
- UTF-8 support

SSL VERIFICATION
----------------
To verify SSL is working:
  ./bin/elinks -dump https://example.com

You should see the page content, NOT an error!

APP SANDBOX FIX
---------------
If your HOME is in an app sandbox like:
  /accounts/1000/appdata/com.example.*/data/

The launcher automatically:
1. Detects the sandbox
2. Uses /tmp for config instead
3. Creates temporary HOME
4. Falls back to -no-home if needed

INSTALLATION
------------
1. Extract:
   tar xzf ELinks_0.17.0_QNX8_FINAL.tar.gz

2. Run with launcher (recommended):
   ./elinks_run.sh https://example.com

3. Or run directly:
   ./bin/elinks https://example.com

USAGE EXAMPLES
--------------
# Open HTTPS site:
./elinks_run.sh https://www.google.com

# Dump HTTPS page:
./bin/elinks -dump https://example.com

# Offline mode:
./bin/elinks -no-connect

# Skip config (no HOME needed):
./bin/elinks -no-home https://example.com

VERIFYING SSL
-------------
Test SSL works:
  ./bin/elinks -dump https://www.google.com

If you see HTML content = SSL WORKS!
If you see "SSL not supported" = something wrong

BROWSER COMMANDS
----------------
While browsing:
  g        - Go to URL
  /        - Search in page
  n        - Next search result
  ESC      - Main menu
  s        - Save page
  d        - Download link
  Backspace - Go back
  q        - Quit
  ?        - Help

JAVASCRIPT INFO
---------------
JavaScript is enabled by default!
To disable: Press ESC → Setup → Options → ECMAScript

DEPENDENCIES
------------
Runtime libraries (provided by QNX):
- libcurl.so
- libssl.so, libcrypto.so (OpenSSL 1.0.1i)
- libsqlite3.so
- libiconv.so
- libicu* (Unicode support)
- Kerberos suite
- Standard C library

NOTE: C++ runtime is statically linked (no libcpp-ne.so.4 needed!)

BUILD INFO
----------
Version: ELinks 0.17.0
SSL: OpenSSL 1.0.1i-fips (from QNX)
JavaScript: QuickJS (static)
CSS: libcss 0.9.2 (static)
DOM: libdom (static)
C++ Runtime: Static (libcpp-ne.a)
Compiler: GCC 9.3.0 + 4.6.3 C++ lib
Target: ARMv7-A EABI5 (32-bit)
Binary: ~2.3MB stripped
Build Date: October 31, 2025

TROUBLESHOOTING
---------------
Q: "Unable to create config directory"
A: Use the launcher script (elinks_run.sh) - it handles this!

Q: "This version does not contain SSL/TLS support"
A: This build DOES have SSL! Make sure you're using the latest binary.

Q: Certificate errors?
A: OpenSSL 1.0.1 is old, some sites may have issues.
   Try: ./bin/elinks -dump https://example.com
   (older sites work better)

Q: Memory fault?
A: This build has static C++ - should be fixed!

Q: Slow performance?
A: Text browser - should be fast. Check your network.

CREDITS
-------
- ELinks: https://github.com/rkd77/elinks
- QuickJS: Fabrice Bellard
- OpenSSL: QNX 8 system libraries
- NetSurf libraries: netsurf-browser.org
- Built with persistence through 200+ compilation fixes!

THANKS FOR STICKING WITH IT! 🎉
