# shellcheck shell=sh
# Berry Bridge agent — shared helpers (POSIX sh)

bb_agent_home() {
	if [ -n "${BB_AGENT_HOME:-}" ]; then
		CDPATH= cd -- "$BB_AGENT_HOME" && pwd
		return 0
	fi
	# Invoked from bin/berrybridge-* : $0 is .../bin/runner
	case "$0" in
	*/bin/*)
		CDPATH= cd -- "$(dirname -- "$0")/.." && pwd
		;;
	*)
		CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd
		;;
	esac
}

bb_load_conf() {
	_agent_home="$(bb_agent_home)"
	_conf="${_agent_home}/etc/berrybridge/agent.conf"
	if [ ! -f "$_conf" ]; then
		printf 'berrybridge: missing %s\n' "$_conf" >&2
		return 1
	fi
	# shellcheck disable=SC1090
	. "$_conf"
	export BB_AGENT_HOME="$_agent_home"
	export AGENT_VERSION BERRYCORE_PATH DOCUMENTS BRIDGE_ROOT INBOX PROCESSED
	export STATUS_FILE AGENT_LOG SSHD_PIDFILE SSH_DIR AUTHORIZED_KEYS
	export SSH_PORT SSH_USER POLL_INTERVAL
	unset _conf _agent_home
	return 0
}

bb_log() {
	_ts=$(date -u +%Y-%m-%dT%H:%M:%SZ 2>/dev/null || date +%Y-%m-%dT%H:%M:%SZ)
	printf '%s %s\n' "$_ts" "$*" >>"$AGENT_LOG"
	printf '%s %s\n' "$_ts" "$*"
}

bb_ensure_dirs() {
	mkdir -p "$INBOX" "$PROCESSED" "$BRIDGE_ROOT" 2>/dev/null || return 1
	touch "$AGENT_LOG" 2>/dev/null || true
	return 0
}

bb_path_allowed() {
	_path="$1"
	case "$_path" in
	/accounts/1000/shared/documents/*) return 0 ;;
	/accounts/1000/.ssh/*) return 0 ;;
	/accounts/1000/.ssh) return 0 ;;
	/accounts/1000/shared/misc/berrycore/*) return 0 ;;
	/accounts/1000/shared/misc/berrycore) return 0 ;;
	esac
	return 1
}

bb_json_field() {
	# Usage: bb_json_field file key
	_file="$1"
	_key="$2"
	if command -v jq >/dev/null 2>&1; then
		jq -r --arg k "$_key" '.[$k] // empty' "$_file" 2>/dev/null | head -1
		return
	fi
	sed -n "s/.*\"${_key}\"[[:space:]]*:[[:space:]]*\"\\([^\"]*\\)\".*/\\1/p" "$_file" | head -1
}

bb_json_field_num() {
	_file="$1"
	_key="$2"
	if command -v jq >/dev/null 2>&1; then
		jq -r --arg k "$_key" '.[$k] // empty' "$_file" 2>/dev/null | head -1
		return
	fi
	sed -n "s/.*\"${_key}\"[[:space:]]*:[[:space:]]*\\([0-9][0-9]*\\).*/\\1/p" "$_file" | head -1
}

bb_source_berrycore() {
	if [ -n "${NATIVE_TOOLS:-}" ] && [ -f "${NATIVE_TOOLS}/env.sh" ]; then
		BERRYCORE_PATH="$NATIVE_TOOLS"
	fi
	_env="${BERRYCORE_PATH}/env.sh"
	if [ ! -f "$_env" ]; then
		bb_log "ERROR: BerryCore not installed ($_env missing)"
		return 1
	fi
	# shellcheck disable=SC1090
	. "$_env"
	export BERRYCORE_PATH="${NATIVE_TOOLS:-$BERRYCORE_PATH}"
	return 0
}

bb_require_openssh() {
	if ! bb_source_berrycore; then
		return 1
	fi
	_missing=""
	for _tool in ssh-keygen sshd; do
		if command -v "$_tool" >/dev/null 2>&1; then
			continue
		fi
		for _p in \
			"${BERRYCORE_PATH}/bin/${_tool}" \
			"${BERRYCORE_PATH}/sbin/${_tool}"; do
			if [ -x "$_p" ]; then
				export PATH="${BERRYCORE_PATH}/bin:${BERRYCORE_PATH}/sbin:${PATH}"
				break
			fi
		done
		if ! command -v "$_tool" >/dev/null 2>&1; then
			_missing="${_missing} ${_tool}"
		fi
	done
	if [ -n "$_missing" ]; then
		bb_log "ERROR: OpenSSH missing:${_missing}. Install BerryCore package openssh-7.1p2.zip (pbpkgadd packages/openssh-7.1p2.zip)"
		BB_LAST_ERROR="OpenSSH not installed — run pbpkgadd on packages/openssh-7.1p2.zip"
		return 1
	fi
	return 0
}

bb_berrycore_version() {
	if [ -f "${BERRYCORE_PATH}/VERSION" ]; then
		head -1 "${BERRYCORE_PATH}/VERSION" | tr -d '\r\n'
	elif [ -f "${DOCUMENTS}/berrycore.zip" ]; then
		unzip -p "${DOCUMENTS}/berrycore.zip" VERSION 2>/dev/null | tr -d '\r\n'
	else
		printf 'unknown'
	fi
}

bb_port_listening() {
	_port="${1:-$SSH_PORT}"
	if command -v netstat >/dev/null 2>&1; then
		netstat -an 2>/dev/null | grep "\.${_port} .*LISTEN" >/dev/null 2>&1 && return 0
	fi
	if command -v sockstat >/dev/null 2>&1; then
		sockstat 2>/dev/null | grep ":${_port} " >/dev/null 2>&1 && return 0
	fi
	# Fallback: try local connect
	if command -v nc >/dev/null 2>&1; then
		nc -z 127.0.0.1 "$_port" 2>/dev/null && return 0
	fi
	return 1
}

bb_key_fingerprint() {
	_line="$1"
	if command -v ssh-keygen >/dev/null 2>&1; then
		printf '%s' "$_line" | ssh-keygen -lf /dev/stdin 2>/dev/null | awk '{print $2}'
		return
	fi
	printf '%s' "$_line" | awk '{print $2}' | head -c 32
}

bb_authorized_keys_count() {
	if [ ! -f "$AUTHORIZED_KEYS" ]; then
		printf '0'
		return
	fi
	grep -vc '^[[:space:]]*$' "$AUTHORIZED_KEYS" 2>/dev/null || printf '0'
}

bb_write_status() {
	# shellcheck disable=SC2034
	_now=$(date -u +%Y-%m-%dT%H:%M:%SZ 2>/dev/null || date +%Y-%m-%dT%H:%M:%SZ)
	_state="${BB_STATUS_STATE:-idle}"
	_last_job_id="${BB_LAST_JOB_ID:-}"
	_last_error="${BB_LAST_ERROR:-null}"
	_bc_installed="${BB_BC_INSTALLED:-false}"
	_bc_path="${BB_BC_PATH:-$BERRYCORE_PATH}"
	_bc_ver="${BB_BC_VERSION:-unknown}"
	_sshd="${BB_SSHD_RUNNING:-false}"
	_ssh_ready="${BB_SSH_READY:-false}"
	_auth_count="${BB_AUTH_COUNT:-0}"
	_key_fp="${BB_KEY_FP:-}"
	_job_type="${BB_JOB_TYPE:-}"
	_job_state="${BB_JOB_STATE:-}"
	_job_msg="${BB_JOB_MSG:-}"
	_job_exit="${BB_JOB_EXIT:-0}"

	_tmp="${STATUS_FILE}.tmp.$$"
	mkdir -p "$(dirname "$STATUS_FILE")" 2>/dev/null

	if [ "$_last_error" = "null" ] || [ -z "$_last_error" ]; then
		_err_json='null'
	else
		_err_json=$(printf '%s' "$_last_error" | sed 's/\\/\\\\/g; s/"/\\"/g')
		_err_json="\"${_err_json}\""
	fi

	if [ -n "$_key_fp" ]; then
		_fp_json="\"${_key_fp}\""
	else
		_fp_json='null'
	fi

	if [ -n "$_last_job_id" ]; then
		_ljid="\"${_last_job_id}\""
	else
		_ljid='null'
	fi

	_cat >"$_tmp" <<EOF
{
  "schema": "berrybridge.status.v1",
  "updated_at": "${_now}",
  "agent": {
    "version": "${AGENT_VERSION}",
    "state": "${_state}",
    "last_job_id": ${_ljid},
    "last_error": ${_err_json}
  },
  "berrycore": {
    "installed": ${_bc_installed},
    "path": "${_bc_path}",
    "version": "${_bc_ver}"
  },
  "ssh": {
    "sshd_running": ${_sshd},
    "port": ${SSH_PORT},
    "user": "${SSH_USER}",
    "ready_for_bridge": ${_ssh_ready},
    "authorized_keys_count": ${_auth_count},
    "last_key_fingerprint": ${_fp_json}
  },
  "last_job": {
    "id": ${_ljid},
    "type": "${_job_type}",
    "state": "${_job_state}",
    "message": "${_job_msg}",
    "exit_code": ${_job_exit}
  }
}
EOF
	mv "$_tmp" "$STATUS_FILE" 2>/dev/null || cp "$_tmp" "$STATUS_FILE"
	rm -f "$_tmp"
}

bb_refresh_status_defaults() {
	if [ -f "${BERRYCORE_PATH}/env.sh" ]; then
		BB_BC_INSTALLED=true
		BB_BC_PATH="$BERRYCORE_PATH"
		BB_BC_VERSION="$(bb_berrycore_version)"
	else
		BB_BC_INSTALLED=false
	fi
	if bb_port_listening "$SSH_PORT"; then
		BB_SSHD_RUNNING=true
	else
		BB_SSHD_RUNNING=false
	fi
	BB_AUTH_COUNT="$(bb_authorized_keys_count)"
	if [ "$BB_SSHD_RUNNING" = true ] && [ "$BB_BC_INSTALLED" = true ] && [ "$BB_AUTH_COUNT" -gt 0 ] 2>/dev/null; then
		BB_SSH_READY=true
	else
		BB_SSH_READY=false
	fi
}
