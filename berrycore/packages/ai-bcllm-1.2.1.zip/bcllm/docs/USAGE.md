# BerryCore AI — Passport / BB10

On-device LLM assistant. Type **`ai`** for the interactive menu.

## One-time setup

```sh
sh ~/setup-ai.sh
# or:
/accounts/1000/shared/misc/bcllm/bin/ai-install
```

Then open a new terminal and type `ai` or `AI`.

## Agent mode

The model can run shell commands for you (with confirmation):

```sh
ai agent "how much free disk space do I have?"
ai agent "list the files in my home directory"
```

Each step the model outputs `RUN: command`. You confirm with `y` before it runs.

Auto-run (use carefully):

```sh
ai agent -y "show current date and pwd"
```

Settings in `etc/agent.conf` (max turns, system prompt, auto_confirm).

Blocked for safety: `rm`, `slay`, `dd`, `mkfs`, writes to `/dev/`.

## Web chat (Browser UI)

Start a local web server with a **BB10-compatible chat page** (not the heavy llama.cpp UI):

```sh
ai web                          # foreground (Ctrl+C to stop)
ai web -b                       # background
ai web stop                     # stop background server
ai web -m smollm2_360m          # pick model
```

From the interactive menu: **7) Web chat (Browser UI)**

1. Run `ai web` and **wait until the terminal shows `model loaded`** (~15–30 s)
2. Open the **Browser** app
3. Go to **http://127.0.0.1:8080/**
4. You should see a chat box — type a message and tap **Send**

While the model is loading, the browser may show “The model is loading. Please wait.” — it auto-refreshes every few seconds until ready.

The server binds to loopback only (`127.0.0.1`). Port/host: `etc/ai.conf` (`web_host`, `web_port`).

If stuck: `slay -f llama-server` or check `var/web.log` when running in background.

## Quick usage

```sh
ai                              # interactive menu
ai "What is the capital of France?"
ai -n 32 "Write a haiku about rain"
ai -m smollm2_360m "Hello"
ai download                     # wget all missing models
ai download smollm2_135m        # one model
ai models                       # list installed / missing
```

## Models

| ID | Model | Size | Mode |
|----|-------|------|------|
| `smollm2_135m` | SmolLM2 135M Instruct | 101 MB | chat (default) |
| `smollm2_360m` | SmolLM2 360M Instruct | 259 MB | chat |
| `gemma3_270m` | Gemma 3 270M Instruct | 241 MB | chat |
| `functiongemma_270m` | FunctionGemma 270M | 241 MB | chat (function calling) |
| `qwen25_0_5b` | Qwen2.5 0.5B Instruct | 352 MB | completion |
| `qwen25_coder_0_5b` | Qwen2.5 Coder 0.5B Instruct | 379 MB | completion |
| `qwen3_0_6b` | Qwen3 0.6B | 379 MB | completion (manual) |

Download on-device from the menu (option 3) or `ai download`. Uses **wget** over Wi‑Fi.

Models install to: `/accounts/1000/shared/misc/bcllm/models/`

## Settings

Saved in `etc/ai.conf` — change from menu option 4 or edit directly:

- **Max tokens** (`-n`) — default 64
- **System prompt** — default `You are a helpful assistant.`
- **Temperature** — default 0.3
- **Context / threads** — default 512 / 3
- **Web server** — default `127.0.0.1:8080`

## Files

```
bcllm/
  bin/ai              Main program
  bin/AI              Symlink (after ai-install)
  bin/llama-completion Inference engine
  bin/llama-server    Web chat server + Browser UI
  bin/llama-bench     Benchmark
  etc/ai.conf         Your settings
  etc/models.conf     Model catalog + download URLs
  models/*.gguf       Downloaded weights
  web/index.html      Browser chat UI
```

## Notes

- First run loads the model (~10–15 s). 135M is fastest on Passport.
- SmolLM models use chat template; Qwen models use `-no-cnv`.
- Flash attention is off (`-fa off`) — required on BB10.
- If stuck: `slay -f llama-completion`
