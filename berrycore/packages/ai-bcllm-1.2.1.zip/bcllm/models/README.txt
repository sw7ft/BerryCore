Put downloaded .gguf model files here, or run on device:

  ai download smollm2_135m

Models are NOT included in this package (too large for easy transfer).
