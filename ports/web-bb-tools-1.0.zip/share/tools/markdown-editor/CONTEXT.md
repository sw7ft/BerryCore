# Markdown Editor – App Builder Context

Browser-only markdown viewer and editor for BB10. Single-file HTML, ES5-only, no build step.

## Overview

- **Path:** `tools/markdown-editor/index.html`
- **Target:** BB10 WebKit (touch + mouse)
- **Storage:** localStorage + `.md` file export/import

## View Modes

| Mode    | Layout                          |
|---------|----------------------------------|
| Edit    | Textarea only                    |
| Preview | Rendered HTML only               |
| Split   | Textarea left, preview right     |

## Toolbar Structure

```
[Edit] [Preview] [Split] [Save] [Open] [New] [Clear] ............ [☰]
```

- **Edit / Preview / Split:** Toggle view layout
- **Save:** localStorage + download `document.md`
- **Open:** Load from .md/.markdown/.txt file
- **New / Clear:** Start fresh
- **☰:** Hamburger menu – Insert markdown shortcuts (dropdown list)

## Markdown Shortcuts Menu (☰)

| Shortcut | Inserts | Behavior |
|----------|---------|----------|
| # H1 | `# ` | At line start |
| ## H2 | `## ` | At line start |
| ### H3 | `### ` | At line start |
| **Bold** | `**` `**` | Wraps selection or inserts with cursor between |
| *Italic* | `*` `*` | Wraps selection or inserts with cursor between |
| `Code` | `` ` `` `` ` `` | Wraps selection or inserts with cursor between |
| [Link](url) | `[text](url)` | Inserts and selects "text" |
| - List | `- ` | At line start |
| 1. List | `1. ` | At line start |
| > Quote | `> ` | At line start |
| ``` Block ``` | Fenced block | At line start, cursor inside |
| --- | `---` | Horizontal rule on own line |

Menu: `#md-shortcuts-wrap` > `#btn-md-menu` (☰) toggles `#md-shortcuts-dropdown`. Each button has `data-md` attribute. Click outside to close.

## Markdown Parser

Custom minimal parser (no deps). Handles:

- Code blocks: ` ``` `
- Headers: `#`–`######`
- Blockquotes: `>`
- Lists: `-`/`*` and `1.`
- Paragraphs
- Inline: `**bold**`, `*italic*`, `` `code` ``, `[link](url)`

Functions: `parseMarkdown(text)`, `parseInline(s)`, `parseBlock(s)`, `escapeHtml(s)`.

## Key Functions

| Function         | Purpose                                      |
|------------------|----------------------------------------------|
| `render()`       | Parse editor value → preview                 |
| `insertShortcut(key)` | Insert markdown at cursor; keys: h1, h2, h3, bold, italic, code, link, ul, ol, blockquote, fence, hr |
| `doSave()`       | localStorage + download .md                  |
| `doLoad()`       | Restore from localStorage on init            |
| `doOpen()`       | Trigger file input                           |
| `setView(mode)`  | Edit / Preview / Split                       |
| `showToast(msg)` | Brief "Saved!" feedback                      |

## Event Flow

- **input / keyup:** Re-render preview when editor changes (if preview visible)
- **☰ click:** Toggle shortcuts dropdown
- **Shortcut button click:** `insertShortcut(data-md)`, close dropdown
- **Document click:** Close dropdown when clicking outside
- **File input change:** Load .md file into editor

## Storage

- **localStorage** key: `markdown-editor-data`
- **Save:** Writes to localStorage + downloads `document.md`
- **Open:** File input accepts .md, .markdown, .txt
- **Load on init:** Restores from localStorage

## UI Elements

- `#editor`: Main textarea
- `#preview-content`: Rendered HTML output
- `#editor-pane` / `#preview-pane`: Flex panes; `.hidden` toggles visibility
- `#file-input`: Hidden file input for Open
- `#save-toast`: "Saved!" feedback (fixed bottom center)

## ES5 Constraints

- `var` only (no `let`/`const`)
- `function () {}` (no arrows)
- String concatenation (no template literals)
- No classes
