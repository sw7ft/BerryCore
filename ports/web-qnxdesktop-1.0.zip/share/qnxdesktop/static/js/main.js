// Windows 98 UI - ES5 Compatible Version
(function(window, document) {
    'use strict';

    // Global state
    var state = {
        isLoggedIn: false,
        startMenuOpen: false,
        activeWindows: [],
        zIndex: 1000,
        username: 'User'
    };

    // Utility functions
    function $(id) {
        return document.getElementById(id);
    }

    function createElement(tag, className, innerHTML) {
        var element = document.createElement(tag);
        if (className) element.className = className;
        if (innerHTML) element.innerHTML = innerHTML;
        return element;
    }

    function show(element) {
        if (typeof element === 'string') element = $(element);
        if (element) element.style.display = 'block';
    }

    function hide(element) {
        if (typeof element === 'string') element = $(element);
        if (element) element.style.display = 'none';
    }

    // Login functionality
    window.login = function() {
        var username = $('username').value;
        var password = $('password').value;
        
        if (username && password) {
            state.username = username;
            state.isLoggedIn = true;
            hide('login');
            show('desktop');
            updateClock();
            setInterval(updateClock, 1000);
        } else {
            alert('Please enter both username and password.');
        }
    };

    // Start menu functionality
    window.toggleStartMenu = function() {
        var startMenu = $('start-menu');
        state.startMenuOpen = !state.startMenuOpen;
        if (state.startMenuOpen) {
            show(startMenu);
        } else {
            hide(startMenu);
        }
    };

    // Window management
    function createWindow(title, content, width, height, hasMenuBar, hasStatusBar) {
        var win = createElement('div', 'app-window');
        win.style.width = (width || 400) + 'px';
        win.style.height = (height || 300) + 'px';
        win.style.left = (50 + state.activeWindows.length * 30) + 'px';
        win.style.top = (50 + state.activeWindows.length * 30) + 'px';
        win.style.zIndex = state.zIndex++;

        var titleBar = createElement('div', 'title-bar');
        titleBar.innerHTML = '<span class="title">' + title + '</span>' +
            '<div class="control-box">' +
            '<a class="button-3d minimize" onclick="minimizeWindow(this)"><span>_</span></a>' +
            '<a class="button-3d maximize" onclick="maximizeWindow(this)"><span>□</span></a>' +
            '<a class="button-3d close" onclick="closeWindow(this)"><span>×</span></a>' +
            '</div>';

        win.appendChild(titleBar);

        // Add menu bar if requested
        if (hasMenuBar) {
            var menuBar = createElement('div', 'menu-bar');
            menuBar.innerHTML = '<a><u>F</u>ile</a><a><u>E</u>dit</a><a><u>V</u>iew</a><a><u>H</u>elp</a>';
            win.appendChild(menuBar);
        }

        var contentDiv = createElement('div', 'content');
        contentDiv.innerHTML = content;
        win.appendChild(contentDiv);

        // Add status bar if requested
        if (hasStatusBar) {
            var statusBar = createElement('div', 'status-bar');
            statusBar.innerHTML = 'Ready';
            win.appendChild(statusBar);
            // Adjust content height for status bar
            contentDiv.style.height = 'calc(100% - 60px)';
        }

        // Make window draggable
        titleBar.onmousedown = function(e) {
            var offsetX = e.clientX - win.offsetLeft;
            var offsetY = e.clientY - win.offsetTop;
            
            function moveWindow(e) {
                win.style.left = (e.clientX - offsetX) + 'px';
                win.style.top = (e.clientY - offsetY) + 'px';
            }
            
            function stopMoving() {
                document.removeEventListener('mousemove', moveWindow);
                document.removeEventListener('mouseup', stopMoving);
            }
            
            document.addEventListener('mousemove', moveWindow);
            document.addEventListener('mouseup', stopMoving);
        };

        // Bring window to front when clicked
        win.onclick = function() {
            win.style.zIndex = state.zIndex++;
        };

        $('desktop').appendChild(win);
        state.activeWindows.push(win);
        return win;
    }

    // Window control functions
    window.minimizeWindow = function(button) {
        var win = button.closest('.app-window');
        if (win) win.style.display = 'none';
    };

    window.maximizeWindow = function(button) {
        var win = button.closest('.app-window');
        if (!win) return;
        
        if (!win.dataset.isMaximized) {
            win.dataset.oldStyle = win.getAttribute('style');
            win.style.width = 'calc(100% - 4px)';
            win.style.height = 'calc(100% - 32px)';
            win.style.top = '0';
            win.style.left = '0';
            win.dataset.isMaximized = 'true';
        } else {
            win.setAttribute('style', win.dataset.oldStyle);
            delete win.dataset.isMaximized;
        }
    };

    window.closeWindow = function(button) {
        var win = button.closest('.app-window');
        if (win) {
            win.parentNode.removeChild(win);
            state.activeWindows = state.activeWindows.filter(function(w) {
                return w !== win;
            });
        }
    };

    // Program launchers
    window.openProgram = function(programName) {
        var content = '';
        var title = programName;
        var width = 400;
        var height = 300;
        var hasMenuBar = false;
        var hasStatusBar = false;

        switch (programName) {
            case 'My Computer':
                title = 'My Computer';
                hasMenuBar = true;
                hasStatusBar = true;
                width = 500;
                height = 400;
                content = '<div class="explorer-content">' +
                    '<div class="file-item" ondblclick="alert(\'Opening Local Disk (C:)\')">' +
                    '<img src="images/win98_icons/hard_disk_drive.ico"> Local Disk (C:)' +
                    '</div>' +
                    '<div class="file-item" ondblclick="alert(\'Opening Program Files\')">' +
                    '<img src="images/win98_icons/directory_closed.ico"> Program Files' +
                    '</div>' +
                    '<div class="file-item" ondblclick="alert(\'Opening Windows\')">' +
                    '<img src="images/win98_icons/directory_closed.ico"> Windows' +
                    '</div>' +
                    '<div class="file-item" ondblclick="alert(\'Opening My Documents\')">' +
                    '<img src="images/win98_icons/directory_open_file_mydocs.ico"> My Documents' +
                    '</div>' +
                    '<div class="file-item" ondblclick="alert(\'Opening Control Panel\')">' +
                    '<img src="images/win98_icons/settings_gear.ico"> Control Panel' +
                    '</div>' +
                    '</div>';
                break;
                
            case 'Notepad':
                title = 'Untitled - Notepad';
                hasMenuBar = true;
                hasStatusBar = true;
                width = 500;
                height = 400;
                content = '<textarea class="notepad-textarea" placeholder="Start typing your text here..." onkeyup="updateNotepadStatus(this)">Welcome to Notepad!\n\nThis is a fully functional text editor running in Windows 98.\n\nYou can:\n- Type and edit text\n- Use keyboard shortcuts\n- Save your work (simulated)\n\nTry typing something!</textarea>';
                break;
                
            case 'Mail':
                title = 'New Message - Mail';
                hasMenuBar = true;
                hasStatusBar = true;
                width = 600;
                height = 450;
                content = '<div class="mail-form">' +
                    '<div style="margin-bottom: 10px;">' +
                    '<label>To:</label><input type="text" placeholder="recipient@example.com" style="width: calc(100% - 70px);">' +
                    '</div>' +
                    '<div style="margin-bottom: 10px;">' +
                    '<label>CC:</label><input type="text" placeholder="cc@example.com" style="width: calc(100% - 70px);">' +
                    '</div>' +
                    '<div style="margin-bottom: 10px;">' +
                    '<label>Subject:</label><input type="text" placeholder="Enter subject" style="width: calc(100% - 70px);">' +
                    '</div>' +
                    '<textarea style="height: 200px; margin-top: 10px;" placeholder="Type your message here..."></textarea>' +
                    '<div style="margin-top: 10px;">' +
                    '<button onclick="alert(\'Message sent! (simulated)\')">Send</button> ' +
                    '<button onclick="alert(\'Message saved to drafts! (simulated)\')">Save Draft</button> ' +
                    '<button onclick="closeWindow(this)">Cancel</button>' +
                    '</div>' +
                    '</div>';
                break;
                
            case 'Minesweeper':
                title = 'Minesweeper';
                width = 300;
                height = 350;
                content = '<div style="padding: 10px; text-align: center;">' +
                    '<div style="background: #c0c0c0; border: inset 2px; padding: 10px; margin-bottom: 10px;">' +
                    '<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">' +
                    '<span style="background: black; color: red; padding: 2px 5px; font-family: monospace;">010</span>' +
                    '<button onclick="initMinesweeper()" style="font-size: 16px;">😊</button>' +
                    '<span style="background: black; color: red; padding: 2px 5px; font-family: monospace;">000</span>' +
                    '</div>' +
                    '<div id="minesweeper-grid" style="display: grid; grid-template-columns: repeat(9, 20px); gap: 1px; justify-content: center;">';
                
                // Create a 9x9 grid
                for (var i = 0; i < 81; i++) {
                    content += '<button onclick="minesweeperClick(this)" style="width: 20px; height: 20px; font-size: 10px; padding: 0; margin: 0;" data-mine="false"></button>';
                }
                
                content += '</div></div>' +
                    '<p style="font-size: 10px;">Left click to reveal, right click to flag</p>' +
                    '</div>';
                break;
                
            case 'Recycle Bin':
                title = 'Recycle Bin';
                hasMenuBar = true;
                hasStatusBar = true;
                width = 400;
                height = 300;
                content = '<div style="padding: 20px; text-align: center;">' +
                    '<img src="images/win98_icons/recycle_bin_file.ico" style="width: 64px; height: 64px; margin-bottom: 20px;">' +
                    '<h3>Recycle Bin is empty</h3>' +
                    '<p>To delete files, drag them to the Recycle Bin.</p>' +
                    '<p>To restore files, drag them out of the Recycle Bin.</p>' +
                    '</div>';
                break;
                
            case 'Run':
                title = 'Run';
                width = 350;
                height = 180;
                content = '<div style="padding: 15px;">' +
                    '<div style="display: flex; align-items: flex-start; margin-bottom: 15px;">' +
                    '<img src="images/win98_icons/application_hourglass.ico" style="width: 32px; height: 32px; margin-right: 10px;">' +
                    '<p style="margin: 0;">Type the name of a program, folder, document, or Internet resource, and Windows will open it for you.</p>' +
                    '</div>' +
                    '<div style="margin-bottom: 15px;">' +
                    '<label style="display: inline-block; width: 50px;">Open:</label>' +
                    '<input type="text" id="run-input" style="width: 250px;" placeholder="notepad, calc, etc." onkeypress="if(event.key===\'Enter\') runCommand()">' +
                    '</div>' +
                    '<div style="text-align: right;">' +
                    '<button onclick="runCommand()">OK</button> ' +
                    '<button onclick="closeWindow(this)">Cancel</button> ' +
                    '<button onclick="alert(\'Browse functionality not implemented\')">Browse...</button>' +
                    '</div>' +
                    '</div>';
                break;
                
            default:
                content = '<div style="padding: 20px; text-align: center;">' +
                    '<h3>' + programName + '</h3>' +
                    '<p>This application is not yet implemented.</p>' +
                    '<button onclick="closeWindow(this)">Close</button>' +
                    '</div>';
        }

        createWindow(title, content, width, height, hasMenuBar, hasStatusBar);
        
        // Close start menu if it was open
        if (state.startMenuOpen) {
            toggleStartMenu();
        }
    };

    // System functions
    window.logout = function() {
        if (confirm('Are you sure you want to log off?')) {
            state.isLoggedIn = false;
            hide('desktop');
            show('login');
            // Clear any open windows
            var windows = document.querySelectorAll('.app-window');
            for (var i = 0; i < windows.length; i++) {
                windows[i].parentNode.removeChild(windows[i]);
            }
            state.activeWindows = [];
        }
        if (state.startMenuOpen) {
            toggleStartMenu();
        }
    };

    window.shutdown = function() {
        if (confirm('Are you sure you want to shut down the computer?')) {
            document.body.innerHTML = '<div style="background: black; color: white; position: fixed; top: 0; left: 0; right: 0; bottom: 0; display: flex; align-items: center; justify-content: center; font-size: 24px;">It\'s now safe to turn off your computer.</div>';
        }
        if (state.startMenuOpen) {
            toggleStartMenu();
        }
    };

    // Application helper functions
    window.updateNotepadStatus = function(textarea) {
        var statusBar = textarea.closest('.app-window').querySelector('.status-bar');
        if (statusBar) {
            var lines = textarea.value.split('\n').length;
            var chars = textarea.value.length;
            statusBar.innerHTML = 'Lines: ' + lines + ' | Characters: ' + chars;
        }
    };

    window.runCommand = function() {
        var input = document.getElementById('run-input');
        if (input && input.value) {
            var command = input.value.toLowerCase().trim();
            switch (command) {
                case 'notepad':
                    openProgram('Notepad');
                    break;
                case 'calc':
                case 'calculator':
                    openProgram('Calculator');
                    break;
                case 'minesweeper':
                    openProgram('Minesweeper');
                    break;
                case 'mail':
                    openProgram('Mail');
                    break;
                default:
                    alert('Cannot find \'' + input.value + '\'. Make sure you typed the name correctly, and then try again.');
            }
            // Close the run dialog
            var runWindow = input.closest('.app-window');
            if (runWindow) {
                runWindow.parentNode.removeChild(runWindow);
            }
        }
    };

    window.initMinesweeper = function() {
        // Simple minesweeper initialization
        var buttons = document.querySelectorAll('#minesweeper-grid button');
        var mines = [];
        
        // Reset all buttons
        for (var i = 0; i < buttons.length; i++) {
            buttons[i].textContent = '';
            buttons[i].style.backgroundColor = '#c0c0c0';
            buttons[i].dataset.mine = 'false';
            buttons[i].dataset.revealed = 'false';
        }
        
        // Place 10 random mines
        while (mines.length < 10) {
            var pos = Math.floor(Math.random() * 81);
            if (mines.indexOf(pos) === -1) {
                mines.push(pos);
                buttons[pos].dataset.mine = 'true';
            }
        }
    };

    window.minesweeperClick = function(button) {
        if (button.dataset.revealed === 'true') return;
        
        button.dataset.revealed = 'true';
        
        if (button.dataset.mine === 'true') {
            button.textContent = '💣';
            button.style.backgroundColor = 'red';
            alert('Game Over! You hit a mine!');
            return;
        }
        
        // Count adjacent mines
        var buttons = document.querySelectorAll('#minesweeper-grid button');
        var index = Array.prototype.indexOf.call(buttons, button);
        var row = Math.floor(index / 9);
        var col = index % 9;
        var count = 0;
        
        for (var r = Math.max(0, row - 1); r <= Math.min(8, row + 1); r++) {
            for (var c = Math.max(0, col - 1); c <= Math.min(8, col + 1); c++) {
                var adjIndex = r * 9 + c;
                if (buttons[adjIndex].dataset.mine === 'true') {
                    count++;
                }
            }
        }
        
        button.style.backgroundColor = '#e0e0e0';
        if (count > 0) {
            button.textContent = count;
            button.style.color = ['', 'blue', 'green', 'red', 'purple', 'maroon', 'gray', 'black', 'gray'][count];
        }
    };

    // Clock functionality
    function updateClock() {
        var now = new Date();
        var hours = now.getHours();
        var minutes = now.getMinutes();
        var ampm = hours >= 12 ? 'PM' : 'AM';
        hours = hours % 12;
        hours = hours ? hours : 12;
        minutes = minutes < 10 ? '0' + minutes : minutes;
        var timeString = hours + ':' + minutes + ' ' + ampm;
        
        var clockElement = $('clock-time');
        if (clockElement) {
            clockElement.textContent = timeString;
        }
    }

    // Event listeners
    document.addEventListener('click', function(e) {
        // Close start menu when clicking outside
        if (state.startMenuOpen && 
            !e.target.closest('#start-menu') && 
            !e.target.closest('#start-button')) {
            toggleStartMenu();
        }
    });

    // Handle Enter key in login form
    document.addEventListener('keypress', function(e) {
        if (e.key === 'Enter' && !state.isLoggedIn) {
            login();
        }
    });

    // Initialize
    function init() {
        // Set focus to username field
        var usernameField = $('username');
        if (usernameField) {
            usernameField.focus();
        }
    }

    // Start the application
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

})(window, document);