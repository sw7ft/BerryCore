Mutt 2.2.16 for BB10 — deploy package

Contents:
  bin/mutt       — wrapper script (sets SSL_CERT_FILE, runs mutt.bin)
  bin/mutt.bin   — mutt binary (OpenSSL 1.1.1w + LMDB hcache statically linked)
  bin/mutt-nossl — mutt without TLS (optional, for testing)
  certs/cacert.pem — Mozilla CA bundle for TLS verification
  muttrc.swiftmedia.example — sample config for matt@swiftmedia.ca / box.swiftmedia.ca

Install:
  Extract so that bin/ and certs/ sit under your install root (e.g. $NATIVE_TOOLS or next to curl/git).
  Run:  bin/mutt   (not mutt.bin directly — the wrapper sets the CA path)

Quick config (matt@swiftmedia.ca, box.swiftmedia.ca):
  cp muttrc.swiftmedia.example ~/.muttrc
  Edit ~/.muttrc: set certificate_file to your install root/certs/cacert.pem, add password if desired.
  Create header cache dir so mutt keeps headers (stops re-fetching every run):
  mkdir -p ~/.cache/mutt/headers

Requires on device: libncursesw, libz, libiconv, libsocket, libc (no libssl/libcrypto .so).

---
BerryCore + Term49 integration
---
BerryCore install root (e.g. berrycorematt) is where packages and libs live. Config and cache
should live in the user's session dir (Term49 PWD) so you can keep .muttrc in PWD and use
  ./bin/mutt -F .muttrc
with cache under the same place.

1. Install this zip under your BerryCore root (e.g. $NATIVE_TOOLS = /accounts/1000/shared/misc/berrycorematt):
   - Extract so you have:  $NATIVE_TOOLS/bin/mutt, bin/mutt.bin, and $NATIVE_TOOLS/certs/cacert.pem

2. In Term49 .profile, ensure HOME is set to the directory where you want .muttrc and .cache (often
   Term49 already sets this to the session/data dir). The wrapper only sets HOME to the install
   root when HOME is unset; with HOME set, ~/.muttrc and ~/.cache/mutt/headers stay in that dir.

3. In .muttrc (in PWD or ~) use:
   set header_cache = "~/.cache/mutt/headers"
   set certificate_file = "$NATIVE_TOOLS/certs/cacert.pem"
   (replace $NATIVE_TOOLS with the actual path if needed)

4. Create cache dir once:  mkdir -p ~/.cache/mutt/headers

Package for BerryCore (same zip):
  - Layout:  bin/mutt  bin/mutt.bin  bin/mutt-nossl  certs/cacert.pem  muttrc.swiftmedia.example  README.txt
  - Extract into $NATIVE_TOOLS so that $NATIVE_TOOLS/bin is in PATH (BerryCore env) and
    $NATIVE_TOOLS/certs/cacert.pem exists. Run with:  mutt  or  mutt -F .muttrc  from Term49.
