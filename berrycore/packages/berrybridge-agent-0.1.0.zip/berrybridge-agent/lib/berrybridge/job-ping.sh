# shellcheck shell=sh
# Job: ping

bb_job_ping() {
	bb_log "job ping: start"
	bb_ensure_dirs || return 1
	if bb_source_berrycore; then
		BB_BC_INSTALLED=true
		BB_BC_PATH="$BERRYCORE_PATH"
		BB_BC_VERSION="$(bb_berrycore_version)"
	else
		BB_BC_INSTALLED=false
	fi
	bb_refresh_status_defaults
	BB_STATUS_STATE=idle
	BB_JOB_STATE=completed
	BB_JOB_MSG="agent ok"
	BB_JOB_EXIT=0
	bb_write_status
	bb_log "job ping: ok berrycore=${BB_BC_INSTALLED}"
	return 0
}
