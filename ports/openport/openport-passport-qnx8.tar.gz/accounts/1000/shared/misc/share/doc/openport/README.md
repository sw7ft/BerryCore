# OpenPort for BlackBerry Passport

Native diagnostic tool for **Tactrix OpenPort 2.0** on QNX / BerryCore.

| | |
|---|---|
| **Binary** | `openport` (symlink: `openport-canlog`) |
| **Manual** | [`MANUAL.md`](MANUAL.md) — **read this** |
| **Package** | `dist/openport-passport-qnx8.tar.gz` |

## 30-second start

```bash
tar xzf openport-passport-qnx8.tar.gz -C /
export PATH="/accounts/1000/shared/misc/bin:$PATH"

openport identify          # cable only — no car needed
openport probe             # key ON, OBD connected
openport log -d 120 -o /accounts/1000/shared/misc/can.log --show-id
```

## Commands

| Command | Purpose |
|---------|---------|
| `identify` | Firmware version |
| `ports` | List `/dev/ser*` candidates |
| `voltage` | OBD pin voltage (VBATT) |
| `probe` | TesterPresent + VIN + SW version |
| `scan` | Ping FCA module table |
| `read-did F190` | UDS read register |
| `log` | Passive CAN capture |

```bash
openport help              # full command list
openport help log          # topic help
```

## Hardware

Passport **OTG** → USB-A → OpenPort mini-USB → OBD → vehicle (**key ON**).

Remove OpenPort microSD when using USB. Firmware stays on the cable — this is host-side software only.

## Build

```bash
sg docker -c 'docker cp ~/Desktop/OpenPort/qnx-port bb10-kitchen-sink:/root/ports/openport-log'
sg docker -c 'docker exec bb10-kitchen-sink bash -lc "bash /root/ports/build-openport-canlog.sh"'
```

## Documentation

- **[MANUAL.md](MANUAL.md)** — complete user manual (hardware, protocols, workflows, troubleshooting)
- **[../context.md](../context.md)** — project context + Linux tool cross-reference
- **[../README-QNX.md](../README-QNX.md)** — original porting notes
