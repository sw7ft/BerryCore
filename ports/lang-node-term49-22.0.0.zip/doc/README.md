# Node.js for Term49 - BerryCore Port

Node.js v22.0.0 for QNX/BB10 (Term49). **--jitless by default**, npm included.

## Install

```bash
qpkg install node-term49
```

## Usage

```bash
node -e "console.log('Hello!')"
npm --version
```

## What's included

- `node` - Wrapper (runs `node.bin --jitless` automatically)
- `node.bin` - Node.js v22.0.0 binary with OpenSSL
- `npm` - npm 10.5.1 wrapper
- Runtime libs: libuv.so.1, libstdc++.so.6, libgcc_s.so.1

No need to set `LD_LIBRARY_PATH` or type `--jitless` - it's built in.
