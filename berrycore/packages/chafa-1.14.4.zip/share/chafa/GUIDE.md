# chafa 1.14.4 — BB10 QNX port

Terminal image viewer — render JPEG/PNG/GIF in SSH or Term49.

## Quick build

```bash
cd /root/ports/chafa
bash build-chafa.sh
bash build-berrycore-port.sh   # → /root/ports/chafa-bb10-1.14.4.tgz
```

## Deploy

```bash
cd /root/ports/chafa/output/accounts/1000/shared/misc
tar cf - chafa | ssh passport 'mkdir -p /accounts/1000/shared/misc && cd /accounts/1000/shared/misc && tar xf -'
```

## On device

```sh
export PATH=/accounts/1000/shared/misc/chafa/bin:$PATH
export TERM=xterm-256color

chafa-run --version
chafa-run -s 40 photo.jpg          # fit width 40 cols
chafa-run -f symbols /accounts/1000/r/pic.png
```

Use `chafa-run` (sets `LD_LIBRARY_PATH` for bundled `libchafa.so`).

## Runtime libraries

Bundled: `libchafa.so.9`

System (already on Passport): `libjpeg.so.4`, `libfreetype.so.1`, `libpng16.so.0`, `libz.so.2`, `libintl.so.1`, `libiconv.so.1`, `libc.so.3`

Build-time deps cross-compiled into binary: **glib 2.56** (static), **libffi** (static).

## QNX notes

| Issue | Fix |
|-------|-----|
| Host pkg-config picks x86 glib | `PKG_CONFIG_LIBDIR` → `deps/lib/pkgconfig` |
| `ssize_t` in libnsgif | patch: `#include <sys/types.h>` |
| FreeType needs png16 | link with `-lpng16` |
| glib gio fails on QNX | build glib core only (`make -C glib`) |
