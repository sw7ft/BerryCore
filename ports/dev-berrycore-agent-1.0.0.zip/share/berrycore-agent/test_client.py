#!/usr/bin/env python3
"""
BerryCore ACP test client — pure stdlib, no pip.
Spawns agent.py as a subprocess and drives it via ACP JSON-RPC.

Usage:
  python3 test_client.py [prompt]
  python3 test_client.py "What is 2+2?"
  python3 test_client.py  # interactive REPL mode

Env: OPENAI_API_KEY / ANTHROPIC_API_KEY / OPENROUTER_API_KEY
"""
from __future__ import annotations

import asyncio
import json
import os
import sys
from pathlib import Path

AGENT_SCRIPT = Path(__file__).parent / "agent.py"
PYTHON = sys.executable


class SimpleClient:
    """Minimal ACP client that drives the agent and prints responses."""

    def __init__(self) -> None:
        self._proc: asyncio.subprocess.Process | None = None
        self._reader: asyncio.StreamReader | None = None
        self._writer: asyncio.StreamWriter | None = None
        self._session_id: str | None = None
        self._req_id = 0
        self._pending: dict[int, asyncio.Future] = {}
        self._listen_task: asyncio.Task | None = None

    async def start(self) -> None:
        env = dict(os.environ)
        self._proc = await asyncio.create_subprocess_exec(
            PYTHON, str(AGENT_SCRIPT),
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            env=env,
        )
        assert self._proc.stdout and self._proc.stdin
        self._reader = self._proc.stdout
        self._writer = self._proc.stdin
        self._listen_task = asyncio.create_task(self._listen())

    async def stop(self) -> None:
        if self._listen_task:
            self._listen_task.cancel()
        if self._proc:
            try:
                self._proc.stdin.close()
                await asyncio.wait_for(self._proc.wait(), timeout=3)
            except Exception:
                self._proc.kill()

    async def _send(self, msg: dict) -> None:
        line = json.dumps(msg, separators=(",", ":")) + "\n"
        self._writer.write(line.encode("utf-8"))
        await self._writer.drain()

    async def _request(self, method: str, params: dict) -> dict:
        self._req_id += 1
        rid = self._req_id
        fut: asyncio.Future = asyncio.get_running_loop().create_future()
        self._pending[rid] = fut
        await self._send({"jsonrpc": "2.0", "id": rid, "method": method, "params": params})
        return await asyncio.wait_for(fut, timeout=120)

    async def _listen(self) -> None:
        assert self._reader
        while True:
            try:
                line = await self._reader.readline()
                if not line:
                    break
                msg = json.loads(line.decode("utf-8").strip())
            except Exception:
                break

            # Response to our request
            if "id" in msg and ("result" in msg or "error" in msg):
                fut = self._pending.pop(msg["id"], None)
                if fut and not fut.done():
                    if "error" in msg:
                        fut.set_exception(RuntimeError(msg["error"].get("message", "error")))
                    else:
                        fut.set_result(msg.get("result", {}))
                continue

            # Notification from agent
            method = msg.get("method", "")
            params = msg.get("params", {})
            if method == "session/update":
                update = params.get("update", {})
                su = update.get("sessionUpdate")
                content = update.get("content", {})
                text = content.get("text", "") if isinstance(content, dict) else ""
                if su == "agent_message_chunk" and text:
                    print(text, end="", flush=True)
                elif su == "agent_thought_chunk" and text:
                    print(f"\033[2m[thinking: {text[:80]}...]\033[0m", end="", flush=True)

    async def initialize(self) -> None:
        await self._request("initialize", {
            "protocolVersion": 1,
            "clientInfo": {"name": "test-client", "version": "1.0"},
            "clientCapabilities": {"fs": {"readTextFile": False, "writeTextFile": False}},
        })

    async def new_session(self, cwd: str = "/") -> str:
        result = await self._request("session/new", {"cwd": cwd, "mcpServers": []})
        self._session_id = result["sessionId"]
        return self._session_id

    async def prompt(self, text: str) -> dict:
        assert self._session_id
        result = await self._request("session/prompt", {
            "sessionId": self._session_id,
            "prompt": [{"type": "text", "text": text}],
        })
        return result


async def main() -> None:
    client = SimpleClient()
    await client.start()

    try:
        await client.initialize()
        await client.new_session(cwd=str(Path.cwd()))

        # Single prompt mode
        if len(sys.argv) > 1:
            prompt = " ".join(sys.argv[1:])
            print(f"\033[1m> {prompt}\033[0m\n")
            result = await client.prompt(prompt)
            print(f"\n\n\033[2m[{result.get('stopReason','?')}]\033[0m\n")
            return

        # Interactive REPL
        print("\033[1mBerryCore ACP Agent\033[0m — type your prompt, empty line to quit\n")
        loop = asyncio.get_running_loop()
        while True:
            try:
                line = await loop.run_in_executor(None, lambda: input("\033[36m> \033[0m"))
            except (EOFError, KeyboardInterrupt):
                break
            line = line.strip()
            if not line:
                break
            print()
            result = await client.prompt(line)
            print(f"\n\033[2m[{result.get('stopReason','?')}]\033[0m\n")

    finally:
        await client.stop()


if __name__ == "__main__":
    asyncio.run(main())
