#!/bin/sh
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
PIDFILE="${ROOT}/cron/crond.pid"
if [ -f "$PIDFILE" ]; then
  pid=$(cat "$PIDFILE")
  if kill "$pid" 2>/dev/null; then
    echo "crond stopped (pid $pid)"
    rm -f "$PIDFILE"
    exit 0
  fi
  rm -f "$PIDFILE"
fi
echo "crond not running"
