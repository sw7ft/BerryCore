# BerryCore ACP Agent

A fully self-contained AI coding assistant for BlackBerry 10 / QNX.

**Zero pip dependencies. No Rust. No pydantic. Pure Python 3.11 stdlib.**

---

## What's included

| File | Description |
|------|-------------|
| `bin/agent` | Interactive CLI — REPL, slash commands, streaming |
| `bin/agent.py` | ACP agent server (JSON-RPC stdio) |
| `share/berrycore-agent/test_client.py` | Programmatic test client |
| `doc/README.md` | This file |

---

## Quick start

```bash
export OPENAI_API_KEY=sk-...
agent
```

Or single-shot:

```bash
agent "What is a QNX sysroot?"
agent -m claude-3-5-haiku "Explain POSIX signals"
agent -e "Check my disk space"   # with shell execution
```

---

## API Keys

Set one of:

```bash
export OPENAI_API_KEY=sk-...                  # OpenAI
export ANTHROPIC_API_KEY=sk-ant-...           # Anthropic
export OPENROUTER_API_KEY=sk-or-...           # OpenRouter (100+ models)
```

---

## REPL commands

| Command | Description |
|---------|-------------|
| `/help` | Show all commands |
| `/model [MODEL]` | Show or switch model |
| `/history` | Show conversation history |
| `/clear` | Clear conversation history |
| `/exec CMD` | Run a shell command directly |
| `/session` | Show session info (ID, CWD, model, tokens) |
| `/save [FILE]` | Save session to JSON file |
| `/load FILE` | Resume session from file |
| `/system [PROMPT]` | Show or override system prompt |
| `/tokens` | Show token usage |
| `/exit` | Exit |

### Multi-line input

End a line with `\` to continue on the next line, or type `.` alone to send:

```
> Write a QNX socket server in C that \
. listens on port 8765
```

---

## Shell execution tool

With `-e` / `--exec`, the agent can run commands on the device:

```bash
agent -e "Build my port and show me any errors"
```

The agent uses `<exec>command</exec>` syntax internally. Results are shown
as tool call cards in ACP clients, or inline in the CLI.

---

## Session persistence

```bash
# Save and resume
agent -s ~/my-session.json

# Resume later
agent -s ~/my-session.json
```

History is also auto-saved per-session to `~/.berrycore/<session-id>.json`.

---

## Options

```
agent [options] [prompt]

  -m, --model MODEL     model override (gpt-4o, claude-3-7-sonnet, ...)
  -s, --session FILE    session file to resume/save
  -e, --exec            enable shell execution tool
  -d, --debug           show JSON-RPC traffic
  -h, --help            show help
```

---

## Environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| `OPENAI_API_KEY` | — | OpenAI key |
| `ANTHROPIC_API_KEY` | — | Anthropic key |
| `OPENROUTER_API_KEY` | — | OpenRouter key |
| `OPENAI_MODEL` | `gpt-4o-mini` | OpenAI model |
| `ANTHROPIC_MODEL` | `claude-3-5-haiku-20241022` | Anthropic model |
| `OPENROUTER_MODEL` | `openai/gpt-4o-mini` | OpenRouter model |
| `ACP_SYSTEM_PROMPT` | *(coding assistant)* | System prompt |
| `ACP_MAX_HISTORY` | `40` | Max messages per session |
| `ACP_HISTORY_DIR` | `~/.berrycore` | History directory |
| `ACP_ALLOW_EXEC` | `0` | Enable shell execution (`1` = on) |
| `ACP_EXEC_TIMEOUT` | `30` | Max seconds per command |
| `ACP_DEBUG` | `0` | Log JSON-RPC traffic |

---

## TLS on QNX

The agent finds the CA bundle automatically. It checks these paths:

1. `/accounts/1000/shared/misc/berrycore/ssl/cert.pem` ← BerryCore canonical
2. `/etc/ssl/certs/ca-certificates.crt`
3. `/etc/ssl/cert.pem`
4. `ssl/cert.pem` next to `agent.py`

If none are found, TLS verification is disabled with a warning.

---

## Use as ACP server (Zed, Cursor, etc.)

```json
{
  "agent_servers": {
    "BerryCore": {
      "type": "custom",
      "command": "/accounts/1000/shared/misc/bin/python3",
      "args": ["/accounts/1000/shared/misc/bin/agent.py"],
      "env": { "OPENAI_API_KEY": "sk-..." }
    }
  }
}
```

---

*BerryCore ACP Agent v1.0.0 — March 2026*
