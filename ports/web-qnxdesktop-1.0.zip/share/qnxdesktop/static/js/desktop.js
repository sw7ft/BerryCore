// QNX Desktop - File Explorer JavaScript
(function(window, document) {
    'use strict';

    // ES5 Compatibility polyfills for BlackBerry Passport
    
    // Array.prototype.forEach polyfill
    if (!Array.prototype.forEach) {
        Array.prototype.forEach = function(callback, thisArg) {
            if (this == null) {
                throw new TypeError('Array.prototype.forEach called on null or undefined');
            }
            var T, k;
            var O = Object(this);
            var len = parseInt(O.length) || 0;
            if (typeof callback !== "function") {
                throw new TypeError(callback + ' is not a function');
            }
            if (arguments.length > 1) {
                T = thisArg;
            }
            k = 0;
            while (k < len) {
                var kValue;
                if (k in O) {
                    kValue = O[k];
                    callback.call(T, kValue, k, O);
                }
                k++;
            }
        };
    }
    
    // String.prototype.padStart polyfill
    if (!String.prototype.padStart) {
        String.prototype.padStart = function padStart(targetLength, padString) {
            targetLength = targetLength >> 0; // floor if number or convert non-number to 0;
            padString = String(typeof padString !== 'undefined' ? padString : ' ');
            if (this.length > targetLength) {
                return String(this);
            } else {
                targetLength = targetLength - this.length;
                if (targetLength > padString.length) {
                    padString += padString.repeat(targetLength / padString.length); // append to original to ensure we are longer than needed
                }
                return padString.slice(0, targetLength) + String(this);
            }
        };
    }

    // String.prototype.endsWith polyfill
    if (!String.prototype.endsWith) {
        String.prototype.endsWith = function(searchString, length) {
            if (length === undefined || length > this.length) {
                length = this.length;
            }
            return this.substring(length - searchString.length, length) === searchString;
        };
    }

    // String.prototype.includes polyfill
    if (!String.prototype.includes) {
        String.prototype.includes = function(search, start) {
            if (typeof start !== 'number') {
                start = 0;
            }
            if (start + search.length > this.length) {
                return false;
            } else {
                return this.indexOf(search, start) !== -1;
            }
        };
    }

    // String.prototype.repeat polyfill
    if (!String.prototype.repeat) {
        String.prototype.repeat = function(count) {
            if (this == null) throw new TypeError("can't convert " + this + " to object");
            var str = "" + this;
            count = +count;
            if (count != count) count = 0;
            if (count < 0) throw new RangeError("repeat count must be non-negative");
            if (count == Infinity) throw new RangeError("repeat count must be less than infinity");
            count = Math.floor(count);
            if (str.length == 0 || count == 0) return "";
            if (str.length * count >= 1 << 28) throw new RangeError("repeat count must not overflow maximum string size");
            var rpt = "";
            for (var i = 0; i < count; i++) {
                rpt += str;
            }
            return rpt;
        };
    }

    // Promise polyfill for older browsers
    if (!window.Promise) {
        window.Promise = function(executor) {
            var self = this;
            self.state = 'pending';
            self.value = undefined;
            self.handlers = [];
            
            function resolve(result) {
                if (self.state === 'pending') {
                    self.state = 'fulfilled';
                    self.value = result;
                    var handlersToProcess = self.handlers.slice(); // Copy the array
                    self.handlers = null;
                    setTimeout(function() {
                        handlersToProcess.forEach(handle);
                    }, 0);
                }
            }
            
            function reject(error) {
                if (self.state === 'pending') {
                    self.state = 'rejected';
                    self.value = error;
                    var handlersToProcess = self.handlers.slice(); // Copy the array
                    self.handlers = null;
                    setTimeout(function() {
                        handlersToProcess.forEach(handle);
                    }, 0);
                }
            }
            
            function handle(handler) {
                if (self.state === 'pending') {
                    self.handlers.push(handler);
                } else {
                    setTimeout(function() {
                        try {
                            if (self.state === 'fulfilled') {
                                if (typeof handler.onFulfilled === 'function') {
                                    var result = handler.onFulfilled(self.value);
                                    if (result && typeof result.then === 'function') {
                                        result.then(handler.resolve, handler.reject);
                                    } else {
                                        handler.resolve(result);
                                    }
                                } else {
                                    handler.resolve(self.value);
                                }
                            } else if (self.state === 'rejected') {
                                if (typeof handler.onRejected === 'function') {
                                    var result = handler.onRejected(self.value);
                                    if (result && typeof result.then === 'function') {
                                        result.then(handler.resolve, handler.reject);
                                    } else {
                                        handler.resolve(result);
                                    }
                                } else {
                                    handler.reject(self.value);
                                }
                            }
                        } catch (ex) {
                            handler.reject(ex);
                        }
                    }, 0);
                }
            }
            
            this.then = function(onFulfilled, onRejected) {
                return new Promise(function(resolve, reject) {
                    handle({
                        onFulfilled: onFulfilled,
                        onRejected: onRejected,
                        resolve: resolve,
                        reject: reject
                    });
                });
            };
            
            this.catch = function(onRejected) {
                return this.then(null, onRejected);
            };
            
            try {
                executor(resolve, reject);
            } catch (ex) {
                reject(ex);
            }
        };
        
        Promise.resolve = function(value) {
            return new Promise(function(resolve) {
                resolve(value);
            });
        };
        
        Promise.reject = function(error) {
            return new Promise(function(resolve, reject) {
                reject(error);
            });
        };
    }

    // Fetch polyfill using XMLHttpRequest
    if (!window.fetch) {
        window.fetch = function(url, options) {
            return new Promise(function(resolve, reject) {
                var xhr = new XMLHttpRequest();
                options = options || {};
                var method = options.method || 'GET';
                var headers = options.headers || {};
                
                xhr.open(method, url, true);
                
                // Set headers
                for (var key in headers) {
                    if (headers.hasOwnProperty(key)) {
                        xhr.setRequestHeader(key, headers[key]);
                    }
                }
                
                xhr.onload = function() {
                    console.log('XHR onload:', xhr.status, xhr.statusText, xhr.responseText ? xhr.responseText.substring(0, 100) + '...' : 'no response');
                    var response = {
                        status: xhr.status,
                        statusText: xhr.statusText,
                        ok: xhr.status >= 200 && xhr.status < 300,
                        headers: {
                            get: function(name) {
                                return xhr.getResponseHeader(name);
                            }
                        },
                        text: function() {
                            return Promise.resolve(xhr.responseText || '');
                        },
                        json: function() {
                            try {
                                return Promise.resolve(JSON.parse(xhr.responseText || '{}'));
                            } catch (e) {
                                return Promise.reject(new Error('Invalid JSON: ' + e.message));
                            }
                        },
                        blob: function() {
                            return Promise.resolve(new Blob([xhr.response || '']));
                        }
                    };
                    resolve(response);
                };
                
                xhr.onerror = function() {
                    reject(new Error('Network error'));
                };
                
                xhr.ontimeout = function() {
                    reject(new Error('Request timeout'));
                };
                
                // Handle different body types
                if (options.body) {
                    if (typeof options.body === 'string') {
                        xhr.send(options.body);
                    } else if (options.body instanceof FormData) {
                        xhr.send(options.body);
                    } else {
                        xhr.send(JSON.stringify(options.body));
                    }
                } else {
                    xhr.send();
                }
            });
        };
    }

    // Global state
    var state = {
        isLoggedIn: false,
        startMenuOpen: false,
        activeWindows: [],
        zIndex: 1000,
        username: 'qnx-user',
        currentExplorer: null,
        contextMenu: null,
        isPassport: false
    };

    // Detect BlackBerry Passport
    function detectPassport() {
        var width = window.screen.width;
        var height = window.screen.height;
        var isSquare = Math.abs(width - height) < 50; // Allow small variance
        var isPassportSize = (width >= 1400 && width <= 1500) || (height >= 1400 && height <= 1500);
        
        state.isPassport = isSquare && isPassportSize;
        
        if (state.isPassport) {
            document.body.classList.add('passport-device');
            console.log('BlackBerry Passport detected - applying optimizations');
        }
        
        return state.isPassport;
    }

    // Utility functions
    function $(id) {
        return document.getElementById(id);
    }

    function createElement(tag, className, innerHTML) {
        var element = document.createElement(tag);
        if (className) element.className = className;
        if (innerHTML) element.innerHTML = innerHTML;
        return element;
    }

    function show(element) {
        if (typeof element === 'string') element = $(element);
        if (element) element.style.display = 'block';
    }

    function hide(element) {
        if (typeof element === 'string') element = $(element);
        if (element) element.style.display = 'none';
    }

    function showMessage(message, type) {
        var statusText = $('status-text');
        if (statusText) {
            statusText.textContent = message;
            statusText.className = 'text ' + (type || '');
        }
        
        // Clear message after 3 seconds
        setTimeout(function() {
            if (statusText) {
                statusText.textContent = 'Ready';
                statusText.className = 'text';
            }
        }, 3000);
    }

    // API helper functions
    function apiRequest(url, options) {
        options = options || {};
        console.log('API Request:', url, options);
        
        return fetch(url, {
            method: options.method || 'GET',
            headers: options.headers || {},
            body: options.body
        }).then(function(response) {
            console.log('API Response:', response.status, response.statusText);
            if (!response.ok) {
                return response.text().then(function(errorText) {
                    console.log('API Error Response:', errorText);
                    try {
                        var errorData = JSON.parse(errorText);
                        throw new Error(errorData.error || 'Request failed');
                    } catch (e) {
                        throw new Error('Request failed: ' + response.status + ' ' + response.statusText);
                    }
                });
            }
            return response.text().then(function(text) {
                console.log('API Response Text:', text.substring(0, 200) + '...');
                try {
                    return JSON.parse(text);
                } catch (e) {
                    console.error('JSON Parse Error:', e, text);
                    throw new Error('Invalid JSON response');
                }
            });
        }).catch(function(error) {
            console.error('API Request Error:', error);
            throw error;
        });
    }

    // Login functionality
    window.login = function() {
        var username = $('username').value;
        var password = $('password').value;
        
        if (username && password) {
            state.username = username;
            state.isLoggedIn = true;
            hide('login');
            show('desktop');
            updateClock();
            setInterval(updateClock, 1000);
            loadSystemInfo();
        } else {
            alert('Please enter both username and password.');
        }
    };

    // Start menu functionality
    window.toggleStartMenu = function() {
        var startMenu = $('start-menu');
        state.startMenuOpen = !state.startMenuOpen;
        if (state.startMenuOpen) {
            show(startMenu);
        } else {
            hide(startMenu);
        }
    };

    // Window management
    function createWindow(title, content, width, height, hasMenuBar, hasStatusBar) {
        var win = createElement('div', 'app-window');
        win.style.width = (width || 500) + 'px';
        win.style.height = (height || 400) + 'px';
        win.style.left = (50 + state.activeWindows.length * 30) + 'px';
        win.style.top = (50 + state.activeWindows.length * 30) + 'px';
        win.style.zIndex = state.zIndex++;

        var titleBar = createElement('div', 'title-bar');
        titleBar.innerHTML = '<span class="title">' + title + '</span>' +
            '<div class="control-box">' +
            '<a class="button-3d minimize" onclick="minimizeWindow(this)"><span>_</span></a>' +
            '<a class="button-3d maximize" onclick="maximizeWindow(this)"><span>□</span></a>' +
            '<a class="button-3d close" onclick="closeWindow(this)"><span>×</span></a>' +
            '</div>';

        win.appendChild(titleBar);

        // Add menu bar if requested
        if (hasMenuBar) {
            var menuBar = createElement('div', 'menu-bar');
            menuBar.innerHTML = '<a onclick="showFileMenu()"><u>F</u>ile</a><a onclick="showEditMenu()"><u>E</u>dit</a><a onclick="showViewMenu()"><u>V</u>iew</a><a onclick="showHelpMenu()"><u>H</u>elp</a>';
            win.appendChild(menuBar);
        }

        var contentDiv = createElement('div', 'content');
        contentDiv.innerHTML = content;
        win.appendChild(contentDiv);

        // Add status bar if requested
        if (hasStatusBar) {
            var statusBar = createElement('div', 'status-bar');
            statusBar.innerHTML = '<div class="status-left">Ready</div><div class="status-right"><span>Items: 0</span></div>';
            win.appendChild(statusBar);
            // Adjust content height for status bar
            contentDiv.style.height = 'calc(100% - 60px)';
        }

        // Make window draggable - Mouse events
        titleBar.onmousedown = function(e) {
            var offsetX = e.clientX - win.offsetLeft;
            var offsetY = e.clientY - win.offsetTop;
            
            function moveWindow(e) {
                win.style.left = (e.clientX - offsetX) + 'px';
                win.style.top = (e.clientY - offsetY) + 'px';
            }
            
            function stopMoving() {
                document.removeEventListener('mousemove', moveWindow);
                document.removeEventListener('mouseup', stopMoving);
            }
            
            document.addEventListener('mousemove', moveWindow);
            document.addEventListener('mouseup', stopMoving);
        };

        // Make window draggable - Touch events for mobile
        titleBar.ontouchstart = function(e) {
            e.preventDefault(); // Prevent scrolling
            var touch = e.touches[0];
            var offsetX = touch.clientX - win.offsetLeft;
            var offsetY = touch.clientY - win.offsetTop;
            
            function moveWindowTouch(e) {
                if (e.touches.length === 1) {
                    var touch = e.touches[0];
                    win.style.left = (touch.clientX - offsetX) + 'px';
                    win.style.top = (touch.clientY - offsetY) + 'px';
                }
            }
            
            function stopMovingTouch() {
                document.removeEventListener('touchmove', moveWindowTouch);
                document.removeEventListener('touchend', stopMovingTouch);
            }
            
            document.addEventListener('touchmove', moveWindowTouch);
            document.addEventListener('touchend', stopMovingTouch);
        };

        // Add resize handle
        var resizeHandle = createElement('div', 'resize-handle');
        win.appendChild(resizeHandle);

        // Make window resizable - Mouse events
        resizeHandle.onmousedown = function(e) {
            e.stopPropagation();
            var startX = e.clientX;
            var startY = e.clientY;
            var startWidth = parseInt(document.defaultView.getComputedStyle(win).width, 10);
            var startHeight = parseInt(document.defaultView.getComputedStyle(win).height, 10);
            
            function doResize(e) {
                var newWidth = startWidth + e.clientX - startX;
                var newHeight = startHeight + e.clientY - startY;
                
                // Set minimum size constraints
                if (newWidth < 300) newWidth = 300;
                if (newHeight < 200) newHeight = 200;
                
                // Set maximum size constraints (90% of screen)
                var maxWidth = window.innerWidth * 0.9;
                var maxHeight = window.innerHeight * 0.9;
                if (newWidth > maxWidth) newWidth = maxWidth;
                if (newHeight > maxHeight) newHeight = maxHeight;
                
                win.style.width = newWidth + 'px';
                win.style.height = newHeight + 'px';
            }
            
            function stopResize() {
                document.removeEventListener('mousemove', doResize);
                document.removeEventListener('mouseup', stopResize);
            }
            
            document.addEventListener('mousemove', doResize);
            document.addEventListener('mouseup', stopResize);
        };

        // Make window resizable - Touch events for mobile
        resizeHandle.ontouchstart = function(e) {
            e.stopPropagation();
            e.preventDefault();
            var touch = e.touches[0];
            var startX = touch.clientX;
            var startY = touch.clientY;
            var startWidth = parseInt(document.defaultView.getComputedStyle(win).width, 10);
            var startHeight = parseInt(document.defaultView.getComputedStyle(win).height, 10);
            
            function doResizeTouch(e) {
                if (e.touches.length === 1) {
                    var touch = e.touches[0];
                    var newWidth = startWidth + touch.clientX - startX;
                    var newHeight = startHeight + touch.clientY - startY;
                    
                    // Set minimum size constraints
                    if (newWidth < 300) newWidth = 300;
                    if (newHeight < 200) newHeight = 200;
                    
                    // Set maximum size constraints (90% of screen)
                    var maxWidth = window.innerWidth * 0.9;
                    var maxHeight = window.innerHeight * 0.9;
                    if (newWidth > maxWidth) newWidth = maxWidth;
                    if (newHeight > maxHeight) newHeight = maxHeight;
                    
                    win.style.width = newWidth + 'px';
                    win.style.height = newHeight + 'px';
                }
            }
            
            function stopResizeTouch() {
                document.removeEventListener('touchmove', doResizeTouch);
                document.removeEventListener('touchend', stopResizeTouch);
            }
            
            document.addEventListener('touchmove', doResizeTouch);
            document.addEventListener('touchend', stopResizeTouch);
        };

        // Bring window to front when clicked or touched
        win.onclick = function() {
            win.style.zIndex = state.zIndex++;
        };
        
        win.ontouchstart = function() {
            win.style.zIndex = state.zIndex++;
        };

        $('desktop').appendChild(win);
        state.activeWindows.push(win);
        return win;
    }

    // Window control functions
    window.minimizeWindow = function(button) {
        var win = button.closest('.app-window');
        if (win) win.style.display = 'none';
    };

    window.maximizeWindow = function(button) {
        var win = button.closest('.app-window');
        if (!win) return;
        
        if (!win.dataset.isMaximized) {
            win.dataset.oldStyle = win.getAttribute('style');
            
            // Calculate available space accounting for taskbar and mobile viewport
            var taskbarHeight = 28; // Default taskbar height
            var bottomBarHeight = 20; // Bottom bar height
            var padding = 4; // Small padding
            
            // Check if we're on mobile (BlackBerry Passport)
            if (window.innerWidth <= 768) {
                taskbarHeight = 32; // Mobile taskbar height
                bottomBarHeight = 24; // Mobile bottom bar height
                padding = 2; // Less padding on mobile
            }
            
            var totalBottomSpace = taskbarHeight + bottomBarHeight;
            
            win.style.width = 'calc(100vw - ' + (padding * 2) + 'px)';
            win.style.height = 'calc(100vh - ' + (totalBottomSpace + padding) + 'px)';
            win.style.top = padding + 'px';
            win.style.left = padding + 'px';
            win.dataset.isMaximized = 'true';
            
            // Bring to front
            win.style.zIndex = state.zIndex++;
        } else {
            win.setAttribute('style', win.dataset.oldStyle);
            delete win.dataset.isMaximized;
        }
    };

    window.closeWindow = function(button) {
        var win = button.closest('.app-window');
        if (win) {
            win.parentNode.removeChild(win);
            state.activeWindows = state.activeWindows.filter(function(w) {
                return w !== win;
            });
        }
    };

    // File Explorer functionality
    window.openFileExplorer = function(pathType, subpath) {
        subpath = subpath || '';
        showMessage('Loading ' + pathType + '...', 'loading');
        
        var title = pathType === 'shared' ? 'QNX Shared Storage' : 'SD Card Storage';
        var content = '<div class="file-explorer">' +
            '<div class="explorer-menu-bar">' +
                '<a onclick="toggleExplorerMenu(\'explorer-file-menu-' + pathType + '\')" style="position: relative;">File' +
                    '<div id="explorer-file-menu-' + pathType + '" class="explorer-dropdown-menu" style="display: none;">' +
                        '<div class="menu-item" onclick="explorerNewFolder(\'' + pathType + '\'); hideExplorerMenus();">📁 New Folder</div>' +
                        '<div class="menu-item" onclick="explorerUpload(\'' + pathType + '\'); hideExplorerMenus();">📤 Upload Files</div>' +
                        '<hr>' +
                        '<div class="menu-item" onclick="explorerRefresh(\'' + pathType + '\'); hideExplorerMenus();">🔄 Refresh</div>' +
                        '<hr>' +
                        '<div class="menu-item" onclick="closeExplorerWindow(\'' + pathType + '\'); hideExplorerMenus();">❌ Exit</div>' +
                    '</div>' +
                '</a>' +
                '<a onclick="toggleExplorerMenu(\'explorer-edit-menu-' + pathType + '\')" style="position: relative;">Edit' +
                    '<div id="explorer-edit-menu-' + pathType + '" class="explorer-dropdown-menu" style="display: none;">' +
                        '<div class="menu-item" onclick="explorerSelectAll(\'' + pathType + '\'); hideExplorerMenus();">🔘 Select All</div>' +
                        '<div class="menu-item" onclick="explorerCopy(\'' + pathType + '\'); hideExplorerMenus();">📋 Copy</div>' +
                        '<div class="menu-item" onclick="explorerPaste(\'' + pathType + '\'); hideExplorerMenus();">📄 Paste</div>' +
                        '<hr>' +
                        '<div class="menu-item" onclick="explorerDelete(\'' + pathType + '\'); hideExplorerMenus();">🗑️ Delete</div>' +
                    '</div>' +
                '</a>' +
                '<a onclick="toggleExplorerMenu(\'explorer-view-menu-' + pathType + '\')" style="position: relative;">View' +
                    '<div id="explorer-view-menu-' + pathType + '" class="explorer-dropdown-menu" style="display: none;">' +
                        '<div class="menu-item" onclick="explorerViewDetails(\'' + pathType + '\'); hideExplorerMenus();">📋 Details</div>' +
                        '<div class="menu-item" onclick="explorerViewIcons(\'' + pathType + '\'); hideExplorerMenus();">🖼️ Icons</div>' +
                        '<hr>' +
                        '<div class="menu-item" onclick="explorerShowHidden(\'' + pathType + '\'); hideExplorerMenus();">👁️ Show Hidden Files</div>' +
                    '</div>' +
                '</a>' +
            '</div>' +
            '<div class="explorer-toolbar">' +
            '<button class="toolbar-button" onclick="navigateUp()">↑ Up</button>' +
            '<button class="toolbar-button" onclick="refreshExplorer()">🔄 Refresh</button>' +
            '<button class="toolbar-button" onclick="createNewFolder()">📁 New Folder</button>' +
            '<button class="toolbar-button" onclick="openUploadDialog(\'' + pathType + '\')">📤 Upload</button>' +
            '</div>' +
            '<div class="breadcrumb" id="breadcrumb-' + pathType + '"></div>' +
            '<div class="file-list-container">' +
            '<div class="file-list" id="file-list-' + pathType + '"></div>' +
            '</div>' +
            '</div>';

        var win = createWindow(title, content, 600, 500, true, false);
        win.dataset.pathType = pathType;
        win.dataset.currentPath = subpath;
        
        state.currentExplorer = {
            window: win,
            pathType: pathType,
            currentPath: subpath
        };

        loadDirectoryContents(pathType, subpath);
        
        // Close start menu if it was open
        if (state.startMenuOpen) {
            toggleStartMenu();
        }
    };

    // Explorer menu functions
    window.toggleExplorerMenu = function(menuId) {
        hideExplorerMenus();
        var menu = $(menuId);
        if (menu) {
            if (menu.style.display === 'none' || menu.style.display === '') {
                menu.style.display = 'block';
                // Add menu-open class to parent link
                var parentLink = menu.parentElement;
                if (parentLink) {
                    parentLink.classList.add('menu-open');
                }
            }
        }
    };

    window.hideExplorerMenus = function() {
        var menus = document.querySelectorAll('.explorer-dropdown-menu');
        for (var i = 0; i < menus.length; i++) {
            menus[i].style.display = 'none';
            var parentLink = menus[i].parentElement;
            if (parentLink) {
                parentLink.classList.remove('menu-open');
            }
        }
    };

    // Explorer menu actions
    window.explorerNewFolder = function(pathType) {
        var folderName = prompt('Enter folder name:', 'New Folder');
        if (folderName) {
            createNewFolder(pathType, folderName);
        }
    };

    window.explorerUpload = function(pathType) {
        openUploadDialog(pathType);
    };

    window.explorerRefresh = function(pathType) {
        refreshExplorer();
        showMessage('Explorer refreshed');
    };

    window.closeExplorerWindow = function(pathType) {
        // Find and close the explorer window
        var windows = document.querySelectorAll('.window[data-path-type="' + pathType + '"]');
        for (var i = 0; i < windows.length; i++) {
            var closeButton = windows[i].querySelector('.close');
            if (closeButton) {
                closeButton.click();
            }
        }
    };

    window.explorerSelectAll = function(pathType) {
        var fileList = $('file-list-' + pathType);
        if (fileList) {
            var items = fileList.querySelectorAll('.file-item');
            for (var i = 0; i < items.length; i++) {
                items[i].classList.add('selected');
            }
            showMessage('All files selected');
        }
    };

    window.explorerCopy = function(pathType) {
        var selected = document.querySelectorAll('#file-list-' + pathType + ' .file-item.selected');
        if (selected.length > 0) {
            // Store selected files for copying (simplified implementation)
            window.clipboardFiles = [];
            for (var i = 0; i < selected.length; i++) {
                var fileName = selected[i].querySelector('.file-name').textContent;
                window.clipboardFiles.push(fileName);
            }
            showMessage(selected.length + ' file(s) copied to clipboard');
        } else {
            showMessage('No files selected');
        }
    };

    window.explorerPaste = function(pathType) {
        if (window.clipboardFiles && window.clipboardFiles.length > 0) {
            showMessage('Paste functionality not implemented yet');
        } else {
            showMessage('Clipboard is empty');
        }
    };

    window.explorerDelete = function(pathType) {
        var selected = document.querySelectorAll('#file-list-' + pathType + ' .file-item.selected');
        if (selected.length > 0) {
            var fileNames = [];
            for (var i = 0; i < selected.length; i++) {
                var fileName = selected[i].querySelector('.file-name').textContent;
                fileNames.push(fileName);
            }
            
            if (confirm('Are you sure you want to delete ' + fileNames.length + ' file(s)?\\n\\n' + fileNames.join('\\n'))) {
                // Implement delete functionality
                for (var j = 0; j < fileNames.length; j++) {
                    deleteFile(pathType, fileNames[j]);
                }
            }
        } else {
            showMessage('No files selected');
        }
    };

    window.explorerViewDetails = function(pathType) {
        showMessage('Details view - Not implemented yet');
    };

    window.explorerViewIcons = function(pathType) {
        showMessage('Icons view - Not implemented yet');
    };

    window.explorerShowHidden = function(pathType) {
        showMessage('Show hidden files - Not implemented yet');
    };

    function loadDirectoryContents(pathType, subpath) {
        var url = '/api/browse/' + pathType;
        if (subpath) {
            url += '/' + subpath;
        }
        
        console.log('Loading directory:', pathType, subpath, 'URL:', url);

        apiRequest(url)
            .then(function(data) {
                updateFileList(pathType, data);
                updateBreadcrumb(pathType, data.breadcrumbs || []);
                updateStatusBar(data.items ? data.items.length : 0);
                showMessage('Loaded ' + (data.items ? data.items.length : 0) + ' items');
            })
            .catch(function(error) {
                showError('Error loading directory: ' + error.message);
            });
    }

    function updateFileList(pathType, data) {
        var fileList = $('file-list-' + pathType);
        if (!fileList) return;

        fileList.innerHTML = '';

        if (data.items && data.items.length > 0) {
            data.items.forEach(function(item) {
                var fileItem = createElement('div', 'file-item');
                fileItem.dataset.path = item.path;
                fileItem.dataset.isDir = item.is_dir;
                
                var iconSrc = '/static/images/win98_icons/' + item.icon;
                fileItem.innerHTML = 
                    '<img src="' + iconSrc + '" alt="' + (item.is_dir ? 'Folder' : 'File') + '">' +
                    '<div class="file-info">' +
                    '<div class="file-name">' + item.name + '</div>' +
                    '<div class="file-size">' + (item.formatted_size || '') + '</div>' +
                    '<div class="file-date">' + (item.modified || '') + '</div>' +
                    '</div>';

                // Double-click handler
                fileItem.ondblclick = function() {
                    if (item.is_dir) {
                        var newPath = data.current_path ? data.current_path + '/' + item.name : item.name;
                        navigateToPath(pathType, newPath);
                    } else {
                        downloadFile(pathType, item.path.replace(data.full_path.split('/').slice(0, -item.name.split('/').length).join('/') + '/', ''));
                    }
                };

                // Right-click context menu
                fileItem.oncontextmenu = function(e) {
                    e.preventDefault();
                    showContextMenu(e, item, pathType);
                };

                // Click handler for selection
                fileItem.onclick = function() {
                    // Remove selection from other items
                    var selected = fileList.querySelectorAll('.file-item.selected');
                    for (var i = 0; i < selected.length; i++) {
                        selected[i].classList.remove('selected');
                    }
                    // Select this item
                    fileItem.classList.add('selected');
                };
                
                // Touch handlers for mobile devices (BlackBerry Passport)
                var touchStartTime = 0;
                var doubleTapTimeout = null;
                var tapCount = 0;
                
                function handleFileAction() {
                    if (item.is_dir) {
                        var newPath = data.current_path ? data.current_path + '/' + item.name : item.name;
                        navigateToPath(pathType, newPath);
                    } else {
                        downloadFile(pathType, item.path.replace(data.full_path.split('/').slice(0, -item.name.split('/').length).join('/') + '/', ''));
                    }
                }
                
                function selectFile() {
                    // Remove selection from other items
                    var selected = fileList.querySelectorAll('.file-item.selected');
                    for (var i = 0; i < selected.length; i++) {
                        selected[i].classList.remove('selected');
                    }
                    // Select this item
                    fileItem.classList.add('selected');
                }
                
                // Touch handlers
                fileItem.ontouchstart = function(e) {
                    touchStartTime = Date.now();
                    e.preventDefault();
                };
                
                fileItem.ontouchend = function(e) {
                    var touchEndTime = Date.now();
                    var touchDuration = touchEndTime - touchStartTime;
                    
                    console.log('Touch event on file:', item.name, 'duration:', touchDuration);
                    
                    // Check if it's a tap (short touch)
                    if (touchDuration < 500) {
                        tapCount++;
                        console.log('Tap count:', tapCount);
                        
                        if (tapCount === 1) {
                            // First tap - select the item
                            selectFile();
                            
                            // Set timeout for double tap detection
                            doubleTapTimeout = setTimeout(function() {
                                console.log('Single tap timeout - resetting tap count');
                                tapCount = 0;
                            }, 400);
                        } else if (tapCount === 2) {
                            // Double tap - open/navigate
                            console.log('Double tap detected - opening file/folder');
                            clearTimeout(doubleTapTimeout);
                            tapCount = 0;
                            handleFileAction();
                        }
                    }
                    
                    e.preventDefault();
                };

                fileList.appendChild(fileItem);
            });
        } else {
            fileList.innerHTML = '<div class="text-center p-10">This folder is empty</div>';
        }
    }

    function updateBreadcrumb(pathType, breadcrumbs) {
        var breadcrumb = $('breadcrumb-' + pathType);
        if (!breadcrumb) return;

        breadcrumb.innerHTML = '';
        
        breadcrumbs.forEach(function(crumb, index) {
            if (index > 0) {
                var separator = createElement('span', 'breadcrumb-separator');
                separator.textContent = ' > ';
                breadcrumb.appendChild(separator);
            }
            
            var crumbElement = createElement('span', 'breadcrumb-item');
            crumbElement.textContent = crumb.name;
            crumbElement.onclick = function() {
                navigateToPath(pathType, crumb.path);
            };
            breadcrumb.appendChild(crumbElement);
        });
    }

    function updateStatusBar(itemCount) {
        var statusBars = document.querySelectorAll('.status-bar .status-right span');
        statusBars.forEach(function(statusBar) {
            statusBar.textContent = 'Items: ' + itemCount;
        });
    }

    function navigateToPath(pathType, path) {
        if (state.currentExplorer && state.currentExplorer.pathType === pathType) {
            state.currentExplorer.currentPath = path;
            state.currentExplorer.window.dataset.currentPath = path;
            loadDirectoryContents(pathType, path);
        }
    }

    window.navigateUp = function() {
        if (!state.currentExplorer) return;
        
        var currentPath = state.currentExplorer.currentPath;
        if (currentPath) {
            var pathParts = currentPath.split('/');
            pathParts.pop();
            var parentPath = pathParts.join('/');
            navigateToPath(state.currentExplorer.pathType, parentPath);
        }
    };

    window.refreshExplorer = function() {
        if (!state.currentExplorer) return;
        loadDirectoryContents(state.currentExplorer.pathType, state.currentExplorer.currentPath);
    };

    // Context menu functionality
    function showContextMenu(event, item, pathType) {
        hideContextMenu();
        
        var menu = createElement('div', 'context-menu');
        menu.id = 'context-menu';
        
        var menuItems = [];
        
        if (item.is_dir) {
            menuItems.push({ text: 'Open', action: function() { 
                var newPath = state.currentExplorer.currentPath ? state.currentExplorer.currentPath + '/' + item.name : item.name;
                navigateToPath(pathType, newPath);
            }});
        } else {
            menuItems.push({ text: 'Download', action: function() { 
                downloadFile(pathType, item.path.replace(/.*\//, ''));
            }});
        }
        
        menuItems.push({ separator: true });
        menuItems.push({ text: 'Delete', action: function() { 
            deleteItem(pathType, item);
        }});
        menuItems.push({ text: 'Properties', action: function() { 
            showProperties(item);
        }});

        menuItems.forEach(function(menuItem) {
            if (menuItem.separator) {
                var separator = createElement('div', 'context-menu-separator');
                menu.appendChild(separator);
            } else {
                var itemElement = createElement('div', 'context-menu-item');
                itemElement.textContent = menuItem.text;
                itemElement.onclick = function() {
                    hideContextMenu();
                    menuItem.action();
                };
                menu.appendChild(itemElement);
            }
        });

        menu.style.left = event.pageX + 'px';
        menu.style.top = event.pageY + 'px';
        
        document.body.appendChild(menu);
        state.contextMenu = menu;
    }

    function hideContextMenu() {
        if (state.contextMenu) {
            state.contextMenu.parentNode.removeChild(state.contextMenu);
            state.contextMenu = null;
        }
    }

    // File operations
    function downloadFile(pathType, filepath) {
        showMessage('Downloading file...', 'loading');
        window.open('/api/download/' + pathType + '/' + filepath, '_blank');
        showMessage('Download started');
    }

    function deleteItem(pathType, item) {
        if (confirm('Are you sure you want to delete "' + item.name + '"?')) {
            showMessage('Deleting item...', 'loading');
            
            var relativePath = item.path.replace(/.*\/accounts\/1000\/(shared|removable\/sdcard)\//, '');
            
            apiRequest('/api/delete/' + pathType + '/' + relativePath, {
                method: 'DELETE'
            })
            .then(function(data) {
                showMessage('Item deleted successfully');
                refreshExplorer();
            })
            .catch(function(error) {
                showError('Error deleting item: ' + error.message);
            });
        }
    }

    window.createNewFolder = function() {
        var folderName = prompt('Enter folder name:');
        if (folderName) {
            showMessage('Creating folder...', 'loading');
            
            var currentPath = state.currentExplorer.currentPath;
            var url = '/api/mkdir/' + state.currentExplorer.pathType;
            if (currentPath) {
                url += '/' + currentPath;
            }
            
            apiRequest(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ name: folderName })
            })
            .then(function(data) {
                showMessage('Folder created successfully');
                refreshExplorer();
            })
            .catch(function(error) {
                showError('Error creating folder: ' + error.message);
            });
        }
    };

    // Upload functionality
    window.openUploadDialog = function(pathType) {
        pathType = pathType || (state.currentExplorer ? state.currentExplorer.pathType : 'shared');
        
        var content = $('upload-dialog-template').innerHTML;
        var win = createWindow('Upload Files', content, 400, 300, false, false);
        
        var pathSelect = win.querySelector('#upload-path-select');
        var subdirInput = win.querySelector('#upload-subdir');
        
        if (pathSelect) {
            pathSelect.value = pathType;
        }
        
        // Pre-fill current directory if we're in a file explorer
        if (subdirInput && state.currentExplorer && state.currentExplorer.pathType === pathType) {
            subdirInput.value = state.currentExplorer.currentPath || '';
            subdirInput.placeholder = 'Current: ' + (state.currentExplorer.currentPath || 'root directory');
        }
    };

    window.startUpload = function() {
        var fileInput = $('file-input');
        var pathSelect = $('upload-path-select');
        var subdirInput = $('upload-subdir');
        
        if (!fileInput || !fileInput.files.length) {
            alert('Please select files to upload');
            return;
        }
        
        var pathType = pathSelect.value;
        var subdir = subdirInput ? subdirInput.value.trim() : '';
        
        // Use current explorer path if available, otherwise use specified subdir
        var uploadPath = '';
        if (state.currentExplorer && state.currentExplorer.pathType === pathType) {
            uploadPath = state.currentExplorer.currentPath;
        } else if (subdir) {
            uploadPath = subdir;
        }
        
        var progressDiv = $('upload-progress');
        var progressFill = $('progress-fill');
        var progressText = $('progress-text');
        var uploadBtn = $('upload-btn');
        
        if (progressDiv) show(progressDiv);
        if (uploadBtn) uploadBtn.disabled = true;
        
        var files = Array.from(fileInput.files);
        var uploadedCount = 0;
        var failedCount = 0;
        
        function uploadNextFile() {
            if (uploadedCount >= files.length) {
                var successCount = uploadedCount - failedCount;
                if (progressText) {
                    progressText.textContent = 'Upload complete! ' + successCount + ' of ' + files.length + ' files uploaded.';
                }
                showMessage(successCount + ' files uploaded successfully' + (failedCount > 0 ? ', ' + failedCount + ' failed' : ''));
                
                if (state.currentExplorer && state.currentExplorer.pathType === pathType) {
                    refreshExplorer();
                }
                
                setTimeout(function() {
                    var uploadWindow = progressDiv ? progressDiv.closest('.app-window') : null;
                    if (uploadWindow) {
                        var closeBtn = uploadWindow.querySelector('.close');
                        if (closeBtn) closeWindow(closeBtn);
                    }
                }, 3000);
                return;
            }
            
            var file = files[uploadedCount];
            var formData = new FormData();
            formData.append('file', file);
            
            var url = '/api/upload/' + pathType;
            if (uploadPath) {
                url += '/' + uploadPath;
            }
            
            if (progressText) {
                progressText.textContent = 'Uploading ' + file.name + ' (' + (uploadedCount + 1) + '/' + files.length + ')...';
            }
            
            fetch(url, {
                method: 'POST',
                body: formData
            })
            .then(function(response) {
                if (!response.ok) {
                    return response.json().then(function(error) {
                        throw new Error(error.error || 'Upload failed');
                    });
                }
                return response.json();
            })
            .then(function(data) {
                uploadedCount++;
                var progress = (uploadedCount / files.length) * 100;
                if (progressFill) progressFill.style.width = progress + '%';
                uploadNextFile();
            })
            .catch(function(error) {
                console.error('Upload error:', error);
                showError('Error uploading ' + file.name + ': ' + error.message);
                uploadedCount++;
                failedCount++;
                uploadNextFile();
            });
        }
        
        uploadNextFile();
    };

    // System info functionality
    window.openSystemInfo = function() {
        showMessage('Loading system information...', 'loading');
        
        apiRequest('/api/system/info')
            .then(function(data) {
                var content = '<div class="system-info">' +
                    '<div class="info-section">' +
                    '<h3>System Information</h3>' +
                    '<div class="info-row"><span class="info-label">Hostname:</span><span class="info-value">' + data.hostname + '</span></div>' +
                    '<div class="info-row"><span class="info-label">Platform:</span><span class="info-value">' + data.platform + '</span></div>' +
                    '</div>' +
                    '<div class="info-section">' +
                    '<h3>Storage Paths</h3>';
                
                Object.keys(data.paths).forEach(function(key) {
                    var accessible = data[key + '_accessible'];
                    var statusClass = accessible ? 'status-ok' : 'status-error';
                    content += '<div class="info-row">' +
                        '<span class="info-label">' +
                        '<span class="status-indicator ' + statusClass + '"></span>' +
                        key.charAt(0).toUpperCase() + key.slice(1) + ':</span>' +
                        '<span class="info-value">' + data.paths[key] + '</span>' +
                        '</div>';
                    
                    if (accessible && data[key + '_total_space']) {
                        content += '<div class="info-row">' +
                            '<span class="info-label">Total Space:</span>' +
                            '<span class="info-value">' + data[key + '_total_space'] + '</span>' +
                            '</div>';
                        content += '<div class="info-row">' +
                            '<span class="info-label">Free Space:</span>' +
                            '<span class="info-value">' + data[key + '_free_space'] + '</span>' +
                            '</div>';
                    }
                });
                
                content += '</div></div>';
                
                createWindow('System Information', content, 500, 400, false, false);
                showMessage('System information loaded');
            })
            .catch(function(error) {
                showError('Error loading system info: ' + error.message);
            });
        
        // Close start menu if it was open
        if (state.startMenuOpen) {
            toggleStartMenu();
        }
    };

    function loadSystemInfo() {
        apiRequest('/api/system/info')
            .then(function(data) {
                // Update desktop icon accessibility indicators
                var sharedIcon = $('desktop-icon-shared');
                var sdcardIcon = $('desktop-icon-sdcard');
                
                if (sharedIcon) {
                    sharedIcon.style.opacity = data.shared_accessible ? '1.0' : '0.5';
                }
                if (sdcardIcon) {
                    sdcardIcon.style.opacity = data.sdcard_accessible ? '1.0' : '0.5';
                }
            })
            .catch(function(error) {
                console.log('Could not load system info:', error.message);
            });
    }

    // Utility functions
    function showError(message) {
        showMessage('Error: ' + message, 'error');
        console.error(message);
    }

    function showProperties(item) {
        var content = '<div class="system-info">' +
            '<div class="info-section">' +
            '<h3>Properties: ' + item.name + '</h3>' +
            '<div class="info-row"><span class="info-label">Name:</span><span class="info-value">' + item.name + '</span></div>' +
            '<div class="info-row"><span class="info-label">Type:</span><span class="info-value">' + (item.is_dir ? 'Folder' : 'File') + '</span></div>' +
            '<div class="info-row"><span class="info-label">Size:</span><span class="info-value">' + (item.formatted_size || 'N/A') + '</span></div>' +
            '<div class="info-row"><span class="info-label">Modified:</span><span class="info-value">' + (item.modified || 'N/A') + '</span></div>' +
            '<div class="info-row"><span class="info-label">Path:</span><span class="info-value">' + item.path + '</span></div>';
        
        if (item.permissions) {
            content += '<div class="info-row"><span class="info-label">Permissions:</span><span class="info-value">' + item.permissions + '</span></div>';
        }
        
        content += '</div></div>';
        
        createWindow('Properties', content, 400, 300, false, false);
    }

    // Menu functions (placeholders)
    window.showFileMenu = function() { alert('File menu - Not implemented'); };
    window.showEditMenu = function() { alert('Edit menu - Not implemented'); };
    window.showViewMenu = function() { alert('View menu - Not implemented'); };
    window.showHelpMenu = function() { alert('Help menu - Not implemented'); };

    // System functions
    window.refreshDesktop = function() {
        loadSystemInfo();
        showMessage('Desktop refreshed');
        if (state.startMenuOpen) {
            toggleStartMenu();
        }
    };

    window.logout = function() {
        if (confirm('Are you sure you want to log off?')) {
            state.isLoggedIn = false;
            hide('desktop');
            show('login');
            // Clear any open windows
            var windows = document.querySelectorAll('.app-window');
            for (var i = 0; i < windows.length; i++) {
                windows[i].parentNode.removeChild(windows[i]);
            }
            state.activeWindows = [];
        }
        if (state.startMenuOpen) {
            toggleStartMenu();
        }
    };

    window.shutdown = function() {
        if (confirm('Are you sure you want to shut down the computer?')) {
            document.body.innerHTML = '<div style="background: black; color: white; position: fixed; top: 0; left: 0; right: 0; bottom: 0; display: flex; align-items: center; justify-content: center; font-size: 24px;">It\'s now safe to turn off your computer.</div>';
        }
        if (state.startMenuOpen) {
            toggleStartMenu();
        }
    };

    // Generic program launcher for compatibility
    window.openProgram = function(programName) {
        switch (programName) {
            case 'Recycle Bin':
                var content = '<div style="padding: 20px; text-align: center;">' +
                    '<img src="/static/images/win98_icons/recycle_bin_file.ico" style="width: 64px; height: 64px; margin-bottom: 20px;">' +
                    '<h3>Recycle Bin is empty</h3>' +
                    '<p>Deleted files would appear here.</p>' +
                    '<p>This is a simulated recycle bin for the QNX Desktop.</p>' +
                    '</div>';
                createWindow('Recycle Bin', content, 400, 300, true, true);
                break;
            default:
                var content = '<div style="padding: 20px; text-align: center;">' +
                    '<h3>' + programName + '</h3>' +
                    '<p>This application is not yet implemented.</p>' +
                    '<button onclick="closeWindow(this)">Close</button>' +
                    '</div>';
                createWindow(programName, content, 300, 200, false, false);
        }
        
        // Close start menu if it was open
        if (state.startMenuOpen) {
            toggleStartMenu();
        }
    };

    // Clock functionality
    function updateClock() {
        var now = new Date();
        var hours = now.getHours();
        var minutes = now.getMinutes();
        var ampm = hours >= 12 ? 'PM' : 'AM';
        hours = hours % 12;
        hours = hours ? hours : 12;
        minutes = minutes < 10 ? '0' + minutes : minutes;
        var timeString = hours + ':' + minutes + ' ' + ampm;
        
        var clockElement = $('clock-time');
        if (clockElement) {
            clockElement.textContent = timeString;
        }
    }

    // Event listeners
    document.addEventListener('click', function(e) {
        // Close start menu when clicking outside
        if (state.startMenuOpen && 
            !e.target.closest('#start-menu') && 
            !e.target.closest('#start-button')) {
            toggleStartMenu();
        }
        
        // Close context menu when clicking outside
        if (state.contextMenu && !e.target.closest('.context-menu')) {
            hideContextMenu();
        }
    });

    // Handle Enter key in login form - ES5 compatible
    document.addEventListener('keypress', function(e) {
        var keyCode = e.keyCode || e.which;
        if (keyCode === 13 && !state.isLoggedIn) { // 13 = Enter key
            login();
        }
    });

    // Prevent default context menu
    document.addEventListener('contextmenu', function(e) {
        if (!e.target.closest('.file-item')) {
            e.preventDefault();
        }
    });

    // Initialize
    function init() {
        // Detect BlackBerry Passport and apply optimizations
        detectPassport();
        
        // Set focus to username field
        var usernameField = $('username');
        if (usernameField) {
            usernameField.focus();
        }
    }

    // Web Browser functionality
    window.openWebBrowser = function() {
        var content = $('browser-template').innerHTML;
        var win = createWindow('Web Browser', content, 800, 500, false, true);
        
        // Set default homepage
        var urlInput = win.querySelector('#browser-url');
        var iframe = win.querySelector('#browser-frame');
        if (urlInput && iframe) {
            urlInput.value = 'https://example.com';
            iframe.src = 'https://example.com';
        }
        
        // Load shortcuts in bookmarks menu
        loadShortcuts();
    };

    window.openTaskManager = function() {
        var content = $('browser-template').innerHTML;
        var win = createWindow('Task Manager', content, 800, 500, false, true);
        
        // Set Task Manager URL using current host IP/domain
        var urlInput = win.querySelector('#browser-url');
        var iframe = win.querySelector('#browser-frame');
        if (urlInput && iframe) {
            // Use current host but change to a common task manager port
            var currentHost = window.location.hostname;
            var taskManagerUrl = 'http://' + currentHost + ':8001';
            
            urlInput.value = taskManagerUrl;
            iframe.src = taskManagerUrl;
        }
        
        // Load shortcuts in bookmarks menu
        loadShortcuts();
    };

    window.browserNavigate = function() {
        var urlInput = $('browser-url');
        var iframe = $('browser-frame');
        
        if (!urlInput || !iframe) return;
        
        var url = urlInput.value.trim();
        if (!url) return;
        
        // Add protocol if missing
        if (!url.startsWith('http://') && !url.startsWith('https://')) {
            url = 'https://' + url;
            urlInput.value = url;
        }
        
        try {
            iframe.src = url;
        } catch (e) {
            showError('Cannot load URL: ' + e.message);
        }
    };

    window.browserBack = function() {
        var iframe = $('browser-frame');
        if (iframe && iframe.contentWindow) {
            try {
                iframe.contentWindow.history.back();
            } catch (e) {
                showError('Cannot go back: Cross-origin restriction');
            }
        }
    };

    window.browserForward = function() {
        var iframe = $('browser-frame');
        if (iframe && iframe.contentWindow) {
            try {
                iframe.contentWindow.history.forward();
            } catch (e) {
                showError('Cannot go forward: Cross-origin restriction');
            }
        }
    };

    window.browserRefresh = function() {
        var iframe = $('browser-frame');
        if (iframe) {
            iframe.src = iframe.src;
        }
    };

    // Notes App functionality
    window.openNotesApp = function() {
        var content = $('notes-template').innerHTML;
        var win = createWindow('Notes', content, 650, 500, false, true);
        
        // Set default filename with timestamp
        var filenameInput = win.querySelector('#note-filename');
        if (filenameInput) {
            var now = new Date();
            var timestamp = now.getFullYear() + '-' + 
                          String(now.getMonth() + 1).padStart(2, '0') + '-' + 
                          String(now.getDate()).padStart(2, '0') + '_' +
                          String(now.getHours()).padStart(2, '0') + '-' +
                          String(now.getMinutes()).padStart(2, '0');
            filenameInput.value = 'note_' + timestamp + '.txt';
        }
        
        // Set up cursor position tracking
        var editor = win.querySelector('#notes-editor');
        var cursorInfo = win.querySelector('#notes-cursor-info');
        if (editor && cursorInfo) {
            editor.addEventListener('keyup', updateCursorPosition);
            editor.addEventListener('click', updateCursorPosition);
        }
        
        // Hide menus when clicking outside
        document.addEventListener('click', function(e) {
            if (!e.target.closest('.notes-menu-bar')) {
                hideNotesMenus();
            }
        });
    };

    function updateCursorPosition() {
        var editor = $('notes-editor');
        var cursorInfo = $('notes-cursor-info');
        if (!editor || !cursorInfo) return;
        
        var text = editor.value.substring(0, editor.selectionStart);
        var lines = text.split('\n');
        var line = lines.length;
        var col = lines[lines.length - 1].length + 1;
        
        cursorInfo.textContent = 'Line ' + line + ', Col ' + col;
    }

    window.newNotesWindow = function() {
        openNotesApp();
    };

    window.toggleNotesMenu = function(menuId) {
        hideNotesMenus();
        var menu = $(menuId);
        if (menu) {
            if (menu.style.display === 'none' || menu.style.display === '') {
                menu.style.display = 'block';
                // Add menu-open class to parent link
                var parentLink = menu.parentElement;
                if (parentLink && parentLink.tagName === 'A') {
                    parentLink.classList.add('menu-open');
                }
            } else {
                menu.style.display = 'none';
                // Remove menu-open class from parent link
                var parentLink = menu.parentElement;
                if (parentLink && parentLink.tagName === 'A') {
                    parentLink.classList.remove('menu-open');
                }
            }
        }
    };

    window.hideNotesMenus = function() {
        var menus = ['file-menu', 'edit-menu', 'view-menu', 'help-menu'];
        menus.forEach(function(menuId) {
            var menu = $(menuId);
            if (menu) {
                menu.style.display = 'none';
                // Remove menu-open class from parent link
                var parentLink = menu.parentElement;
                if (parentLink && parentLink.tagName === 'A') {
                    parentLink.classList.remove('menu-open');
                }
            }
        });
    };

    window.closeNotesWindow = function() {
        var editor = $('notes-editor');
        if (editor && editor.value.trim()) {
            if (confirm('You have unsaved changes. Close anyway?')) {
                var win = editor.closest('.app-window');
                if (win) {
                    var closeBtn = win.querySelector('.close');
                    if (closeBtn) closeWindow(closeBtn);
                }
            }
        } else {
            var win = editor.closest('.app-window');
            if (win) {
                var closeBtn = win.querySelector('.close');
                if (closeBtn) closeWindow(closeBtn);
            }
        }
    };

    window.newNote = function() {
        var editor = $('notes-editor');
        var statusText = $('notes-status-text');
        
        if (editor) {
            editor.value = '';
            if (statusText) statusText.textContent = 'New note created';
        }
    };

    window.saveNote = function() {
        var editor = $('notes-editor');
        var locationSelect = $('notes-location');
        var filenameInput = $('note-filename');
        var directoryInput = $('notes-directory');
        var statusText = $('notes-status-text');
        
        if (!editor || !locationSelect || !filenameInput || !directoryInput) return;
        
        var content = editor.value;
        var location = locationSelect.value;
        var filename = filenameInput.value.trim();
        var directory = directoryInput.value.trim() || 'documents/notes';
        
        if (!filename) {
            showError('Please enter a filename');
            return;
        }
        
        if (!filename.endsWith('.txt')) {
            filename += '.txt';
            filenameInput.value = filename;
        }
        
        if (statusText) statusText.textContent = 'Saving...';
        
        // Create a blob and save as file
        var blob = new Blob([content], { type: 'text/plain' });
        var formData = new FormData();
        formData.append('file', blob, filename);
        
        var url = '/api/upload/' + location;
        if (directory) {
            url += '/' + directory;
        }
        
        fetch(url, {
            method: 'POST',
            body: formData
        })
        .then(function(response) {
            if (response.status === 409) {
                // File already exists, ask user if they want to overwrite
                if (confirm('File "' + filename + '" already exists. Do you want to overwrite it?')) {
                    // Retry with force=true
                    var formDataForce = new FormData();
                    formDataForce.append('file', blob, filename);
                    formDataForce.append('force', 'true');
                    
                    return fetch(url, {
                        method: 'POST',
                        body: formDataForce
                    }).then(function(retryResponse) {
                        return retryResponse.json();
                    });
                } else {
                    throw new Error('Save cancelled by user');
                }
            }
            return response.json();
        })
        .then(function(data) {
            if (data.error) {
                throw new Error(data.error);
            }
            if (statusText) statusText.textContent = 'Saved: ' + directory + '/' + filename;
            showMessage('Note saved successfully: ' + filename);
        })
        .catch(function(error) {
            if (statusText) statusText.textContent = 'Save failed';
            if (error.message !== 'Save cancelled by user') {
                showError('Error saving note: ' + error.message);
            }
        });
    };

    window.saveAsNote = function() {
        var filenameInput = $('note-filename');
        if (filenameInput) {
            var newName = prompt('Save as:', filenameInput.value);
            if (newName) {
                filenameInput.value = newName;
                saveNote();
            }
        }
    };

    window.loadNote = function() {
        openFileBrowser('notes');
    };

    // Edit menu functions
    window.notesUndo = function() {
        document.execCommand('undo');
    };

    window.notesRedo = function() {
        document.execCommand('redo');
    };

    window.notesCut = function() {
        var editor = $('notes-editor');
        if (editor) {
            editor.focus();
            document.execCommand('cut');
        }
    };

    window.notesCopy = function() {
        var editor = $('notes-editor');
        if (editor) {
            editor.focus();
            document.execCommand('copy');
        }
    };

    window.notesPaste = function() {
        var editor = $('notes-editor');
        if (editor) {
            editor.focus();
            document.execCommand('paste');
        }
    };

    window.notesSelectAll = function() {
        var editor = $('notes-editor');
        if (editor) {
            editor.focus();
            editor.select();
        }
    };

    window.notesFindReplace = function() {
        var editor = $('notes-editor');
        if (editor) {
            var searchText = prompt('Find:');
            if (searchText) {
                var replaceText = prompt('Replace with:');
                if (replaceText !== null) {
                    var content = editor.value;
                    var newContent = content.replace(new RegExp(searchText, 'g'), replaceText);
                    editor.value = newContent;
                    showMessage('Replaced all instances of "' + searchText + '"');
                }
            }
        }
    };

    // View menu functions
    window.notesToggleWordWrap = function() {
        var editor = $('notes-editor');
        if (editor) {
            editor.style.whiteSpace = editor.style.whiteSpace === 'pre-wrap' ? 'pre' : 'pre-wrap';
        }
    };

    window.notesZoomIn = function() {
        var editor = $('notes-editor');
        if (editor) {
            var currentSize = parseInt(window.getComputedStyle(editor).fontSize) || 12;
            editor.style.fontSize = (currentSize + 1) + 'px';
        }
    };

    window.notesZoomOut = function() {
        var editor = $('notes-editor');
        if (editor) {
            var currentSize = parseInt(window.getComputedStyle(editor).fontSize) || 12;
            if (currentSize > 8) {
                editor.style.fontSize = (currentSize - 1) + 'px';
            }
        }
    };

    window.notesResetZoom = function() {
        var editor = $('notes-editor');
        if (editor) {
            editor.style.fontSize = '12px';
        }
    };

    window.notesToggleStatusBar = function() {
        var statusBar = $('notes-status-text').parentElement;
        if (statusBar) {
            statusBar.style.display = statusBar.style.display === 'none' ? 'flex' : 'none';
        }
    };

    // Help menu functions
    window.notesShowHelp = function() {
        var helpText = 'QNX Notes Help\n\n' +
                      'File Operations:\n' +
                      '• New: Create a new note\n' +
                      '• Open: Load an existing note\n' +
                      '• Save: Save current note\n' +
                      '• Save As: Save with new name\n\n' +
                      'Edit Operations:\n' +
                      '• Cut/Copy/Paste: Standard clipboard\n' +
                      '• Find & Replace: Search and replace text\n' +
                      '• Select All: Select entire document\n\n' +
                      'View Options:\n' +
                      '• Word Wrap: Toggle line wrapping\n' +
                      '• Zoom: Adjust text size\n' +
                      '• Status Bar: Show/hide status information';
        
        alert(helpText);
    };

    window.notesShowShortcuts = function() {
        var shortcuts = 'Keyboard Shortcuts\n\n' +
                       'Ctrl+N: New note\n' +
                       'Ctrl+O: Open note\n' +
                       'Ctrl+S: Save note\n' +
                       'Ctrl+Z: Undo\n' +
                       'Ctrl+Y: Redo\n' +
                       'Ctrl+X: Cut\n' +
                       'Ctrl+C: Copy\n' +
                       'Ctrl+V: Paste\n' +
                       'Ctrl+A: Select All\n' +
                       'Ctrl+F: Find & Replace';
        
        alert(shortcuts);
    };

    window.notesShowAbout = function() {
        var about = 'QNX Notes v1.0\n\n' +
                   'A simple text editor for the QNX Desktop environment.\n\n' +
                   'Features:\n' +
                   '• Multiple windows\n' +
                   '• File management\n' +
                   '• Text editing tools\n' +
                   '• Auto-save to documents/notes\n\n' +
                   'Built for BlackBerry QNX Desktop';
        
        alert(about);
    };

    // Code App functionality
    window.openCodeApp = function() {
        var content = $('code-template').innerHTML;
        var win = createWindow('Code Editor', content, 700, 550, false, true);
        
        // Set default filename with timestamp
        var filenameInput = win.querySelector('#code-filename');
        if (filenameInput) {
            var now = new Date();
            var timestamp = now.getFullYear() + '-' + 
                          String(now.getMonth() + 1).padStart(2, '0') + '-' + 
                          String(now.getDate()).padStart(2, '0') + '_' +
                          String(now.getHours()).padStart(2, '0') + '-' +
                          String(now.getMinutes()).padStart(2, '0');
            filenameInput.value = 'code_' + timestamp + '.txt';
        }
        
        // Set up line numbers and cursor tracking
        var editor = win.querySelector('#code-editor');
        var lineNumbers = win.querySelector('#code-line-numbers');
        var cursorInfo = win.querySelector('#code-cursor-info');
        
        if (editor && lineNumbers && cursorInfo) {
            editor.addEventListener('input', function() {
                updateCodeLineNumbers();
                updateCodeCursorPosition();
            });
            editor.addEventListener('keyup', updateCodeCursorPosition);
            editor.addEventListener('click', updateCodeCursorPosition);
            editor.addEventListener('scroll', syncCodeScroll);
            
            // Initialize line numbers
            updateCodeLineNumbers();
        }
        
        // Hide menus when clicking outside
        document.addEventListener('click', function(e) {
            if (!e.target.closest('.code-menu-bar')) {
                hideCodeMenus();
            }
        });
    };

    function updateCodeLineNumbers() {
        var editor = $('code-editor');
        var lineNumbers = $('code-line-numbers');
        if (!editor || !lineNumbers) return;
        
        var lines = editor.value.split('\n');
        var lineNumbersArray = [];
        for (var i = 1; i <= lines.length; i++) {
            lineNumbersArray.push(i);
        }
        lineNumbers.textContent = lineNumbersArray.join('\n');
    }

    function updateCodeCursorPosition() {
        var editor = $('code-editor');
        var cursorInfo = $('code-cursor-info');
        if (!editor || !cursorInfo) return;
        
        var text = editor.value.substring(0, editor.selectionStart);
        var lines = text.split('\n');
        var line = lines.length;
        var col = lines[lines.length - 1].length + 1;
        
        cursorInfo.textContent = 'Line ' + line + ', Col ' + col;
    }

    function syncCodeScroll() {
        var editor = $('code-editor');
        var lineNumbers = $('code-line-numbers');
        if (!editor || !lineNumbers) return;
        
        lineNumbers.scrollTop = editor.scrollTop;
    }

    window.newCodeWindow = function() {
        openCodeApp();
    };

    window.toggleCodeMenu = function(menuId) {
        hideCodeMenus();
        var menu = $(menuId);
        if (menu) {
            if (menu.style.display === 'none' || menu.style.display === '') {
                menu.style.display = 'block';
                // Add menu-open class to parent link
                var parentLink = menu.parentElement;
                if (parentLink && parentLink.tagName === 'A') {
                    parentLink.classList.add('menu-open');
                }
            } else {
                menu.style.display = 'none';
                // Remove menu-open class from parent link
                var parentLink = menu.parentElement;
                if (parentLink && parentLink.tagName === 'A') {
                    parentLink.classList.remove('menu-open');
                }
            }
        }
    };

    window.hideCodeMenus = function() {
        var menus = ['code-file-menu', 'code-edit-menu', 'code-view-menu', 'code-help-menu'];
        menus.forEach(function(menuId) {
            var menu = $(menuId);
            if (menu) {
                menu.style.display = 'none';
                // Remove menu-open class from parent link
                var parentLink = menu.parentElement;
                if (parentLink && parentLink.tagName === 'A') {
                    parentLink.classList.remove('menu-open');
                }
            }
        });
    };

    window.newCodeFile = function() {
        var editor = $('code-editor');
        var statusText = $('code-status-text');
        
        if (editor && editor.value.trim()) {
            if (confirm('You have unsaved changes. Create new file anyway?')) {
                editor.value = '';
                updateCodeLineNumbers();
                if (statusText) statusText.textContent = 'New file created';
            }
        } else if (editor) {
            editor.value = '';
            updateCodeLineNumbers();
            if (statusText) statusText.textContent = 'New file created';
        }
    };

    window.saveCodeFile = function() {
        var editor = $('code-editor');
        var locationSelect = $('code-location');
        var filenameInput = $('code-filename');
        var directoryInput = $('code-directory');
        var statusText = $('code-status-text');
        
        if (!editor || !locationSelect || !filenameInput || !directoryInput) return;
        
        var content = editor.value;
        var location = locationSelect.value;
        var filename = filenameInput.value.trim();
        var directory = directoryInput.value.trim() || 'documents/code';
        
        if (!filename) {
            showError('Please enter a filename');
            return;
        }
        
        // Auto-detect file extension based on content or keep existing
        if (!filename.includes('.')) {
            filename += '.txt';
            filenameInput.value = filename;
        }
        
        if (statusText) statusText.textContent = 'Saving...';
        
        // Create a blob and save as file
        var blob = new Blob([content], { type: 'text/plain' });
        var formData = new FormData();
        formData.append('file', blob, filename);
        
        var url = '/api/upload/' + location;
        if (directory) {
            url += '/' + directory;
        }
        
        fetch(url, {
            method: 'POST',
            body: formData
        })
        .then(function(response) {
            if (response.status === 409) {
                // File already exists, ask user if they want to overwrite
                if (confirm('File "' + filename + '" already exists. Do you want to overwrite it?')) {
                    // Retry with force=true
                    var formDataForce = new FormData();
                    formDataForce.append('file', blob, filename);
                    formDataForce.append('force', 'true');
                    
                    return fetch(url, {
                        method: 'POST',
                        body: formDataForce
                    }).then(function(retryResponse) {
                        return retryResponse.json();
                    });
                } else {
                    throw new Error('Save cancelled by user');
                }
            }
            return response.json();
        })
        .then(function(data) {
            if (data.error) {
                throw new Error(data.error);
            }
            if (statusText) statusText.textContent = 'Saved: ' + directory + '/' + filename;
            showMessage('Code file saved successfully: ' + filename);
        })
        .catch(function(error) {
            if (statusText) statusText.textContent = 'Save failed';
            if (error.message !== 'Save cancelled by user') {
                showError('Error saving code file: ' + error.message);
            }
        });
    };

    window.saveAsCodeFile = function() {
        var filenameInput = $('code-filename');
        if (filenameInput) {
            var newName = prompt('Save as:', filenameInput.value);
            if (newName) {
                filenameInput.value = newName;
                saveCodeFile();
            }
        }
    };

    window.openCodeFile = function() {
        openFileBrowser('code');
    };

    window.closeCodeWindow = function() {
        var editor = $('code-editor');
        if (editor && editor.value.trim()) {
            if (confirm('You have unsaved changes. Close anyway?')) {
                var win = editor.closest('.app-window');
                if (win) {
                    var closeBtn = win.querySelector('.close');
                    if (closeBtn) closeWindow(closeBtn);
                }
            }
        } else {
            var win = editor.closest('.app-window');
            if (win) {
                var closeBtn = win.querySelector('.close');
                if (closeBtn) closeWindow(closeBtn);
            }
        }
    };

    // Code Edit menu functions
    window.codeUndo = function() {
        document.execCommand('undo');
    };

    window.codeRedo = function() {
        document.execCommand('redo');
    };

    window.codeCut = function() {
        var editor = $('code-editor');
        if (editor) {
            editor.focus();
            document.execCommand('cut');
        }
    };

    window.codeCopy = function() {
        var editor = $('code-editor');
        if (editor) {
            editor.focus();
            document.execCommand('copy');
        }
    };

    window.codePaste = function() {
        var editor = $('code-editor');
        if (editor) {
            editor.focus();
            document.execCommand('paste');
            setTimeout(function() {
                updateCodeLineNumbers();
            }, 10);
        }
    };

    window.codeSelectAll = function() {
        var editor = $('code-editor');
        if (editor) {
            editor.focus();
            editor.select();
        }
    };

    window.codeFindReplace = function() {
        var editor = $('code-editor');
        if (editor) {
            var searchText = prompt('Find:');
            if (searchText) {
                var replaceText = prompt('Replace with:');
                if (replaceText !== null) {
                    var content = editor.value;
                    var newContent = content.replace(new RegExp(searchText, 'g'), replaceText);
                    editor.value = newContent;
                    updateCodeLineNumbers();
                    showMessage('Replaced all instances of "' + searchText + '"');
                }
            }
        }
    };

    window.codeGoToLine = function() {
        var editor = $('code-editor');
        if (editor) {
            var lineNumber = prompt('Go to line:');
            if (lineNumber && !isNaN(lineNumber)) {
                var lines = editor.value.split('\n');
                var targetLine = parseInt(lineNumber) - 1;
                if (targetLine >= 0 && targetLine < lines.length) {
                    var position = 0;
                    for (var i = 0; i < targetLine; i++) {
                        position += lines[i].length + 1; // +1 for newline
                    }
                    editor.focus();
                    editor.setSelectionRange(position, position);
                    updateCodeCursorPosition();
                }
            }
        }
    };

    // Code View menu functions
    window.codeToggleWordWrap = function() {
        var editor = $('code-editor');
        if (editor) {
            editor.style.whiteSpace = editor.style.whiteSpace === 'pre-wrap' ? 'pre' : 'pre-wrap';
        }
    };

    window.codeToggleLineNumbers = function() {
        var lineNumbers = $('code-line-numbers');
        var editor = $('code-editor');
        if (lineNumbers && editor) {
            var isHidden = lineNumbers.style.display === 'none';
            lineNumbers.style.display = isHidden ? 'block' : 'none';
            editor.style.marginLeft = isHidden ? '50px' : '0';
            editor.style.width = isHidden ? 'calc(100% - 50px)' : '100%';
        }
    };

    window.codeZoomIn = function() {
        var editor = $('code-editor');
        var lineNumbers = $('code-line-numbers');
        if (editor) {
            var currentSize = parseInt(window.getComputedStyle(editor).fontSize) || 12;
            var newSize = currentSize + 1;
            editor.style.fontSize = newSize + 'px';
            if (lineNumbers) lineNumbers.style.fontSize = newSize + 'px';
        }
    };

    window.codeZoomOut = function() {
        var editor = $('code-editor');
        var lineNumbers = $('code-line-numbers');
        if (editor) {
            var currentSize = parseInt(window.getComputedStyle(editor).fontSize) || 12;
            if (currentSize > 8) {
                var newSize = currentSize - 1;
                editor.style.fontSize = newSize + 'px';
                if (lineNumbers) lineNumbers.style.fontSize = newSize + 'px';
            }
        }
    };

    window.codeResetZoom = function() {
        var editor = $('code-editor');
        var lineNumbers = $('code-line-numbers');
        if (editor) {
            editor.style.fontSize = '12px';
            if (lineNumbers) lineNumbers.style.fontSize = '12px';
        }
    };

    window.codeToggleStatusBar = function() {
        var statusBar = $('code-status-text').parentElement;
        if (statusBar) {
            statusBar.style.display = statusBar.style.display === 'none' ? 'flex' : 'none';
        }
    };

    // Code Help menu functions
    window.codeShowHelp = function() {
        var helpText = 'QNX Code Editor Help\n\n' +
                      'File Operations:\n' +
                      '• New: Create a new code file\n' +
                      '• Open: Load an existing file\n' +
                      '• Save: Save current file\n' +
                      '• Save As: Save with new name\n\n' +
                      'Edit Operations:\n' +
                      '• Cut/Copy/Paste: Standard clipboard\n' +
                      '• Find & Replace: Search and replace text\n' +
                      '• Go to Line: Jump to specific line number\n' +
                      '• Select All: Select entire document\n\n' +
                      'View Options:\n' +
                      '• Line Numbers: Show/hide line numbers\n' +
                      '• Word Wrap: Toggle line wrapping\n' +
                      '• Zoom: Adjust text size\n' +
                      '• Status Bar: Show/hide status information\n\n' +
                      'Features:\n' +
                      '• Monospace font for code editing\n' +
                      '• Real-time line numbering\n' +
                      '• Cursor position tracking\n' +
                      '• Multiple file support';
        
        alert(helpText);
    };

    window.codeShowShortcuts = function() {
        var shortcuts = 'Code Editor Keyboard Shortcuts\n\n' +
                       'File Operations:\n' +
                       'Ctrl+N: New file\n' +
                       'Ctrl+O: Open file\n' +
                       'Ctrl+S: Save file\n\n' +
                       'Edit Operations:\n' +
                       'Ctrl+Z: Undo\n' +
                       'Ctrl+Y: Redo\n' +
                       'Ctrl+X: Cut\n' +
                       'Ctrl+C: Copy\n' +
                       'Ctrl+V: Paste\n' +
                       'Ctrl+A: Select All\n' +
                       'Ctrl+F: Find & Replace\n' +
                       'Ctrl+G: Go to Line\n\n' +
                       'Navigation:\n' +
                       'Home: Beginning of line\n' +
                       'End: End of line\n' +
                       'Ctrl+Home: Beginning of document\n' +
                       'Ctrl+End: End of document';
        
        alert(shortcuts);
    };

    window.codeShowAbout = function() {
        var about = 'QNX Code Editor v1.0\n\n' +
                   'A professional code editor for the QNX Desktop environment.\n\n' +
                   'Features:\n' +
                   '• Line numbers with sync scrolling\n' +
                   '• Multiple windows support\n' +
                   '• File management and browsing\n' +
                   '• Advanced text editing tools\n' +
                   '• Monospace font for coding\n' +
                   '• Real-time cursor tracking\n' +
                   '• Auto-save to documents/code\n' +
                   '• Syntax-aware file handling\n\n' +
                   'Built for BlackBerry QNX Desktop\n' +
                   'Perfect for coding, scripting, and development work.';
        
        alert(about);
    };

    // File Browser functionality
    var fileBrowserState = {
        appType: null, // 'notes' or 'code'
        currentLocation: 'shared',
        currentPath: '',
        selectedFile: null,
        window: null
    };

    window.openFileBrowser = function(appType) {
        fileBrowserState.appType = appType;
        fileBrowserState.currentLocation = 'shared';
        fileBrowserState.currentPath = '';
        fileBrowserState.selectedFile = null;
        
        var content = $('file-browser-template').innerHTML;
        fileBrowserState.window = createWindow('Open File', content, 600, 500, false, true);
        
        // Set default location based on app type
        var locationSelect = fileBrowserState.window.querySelector('#file-browser-location');
        if (locationSelect) {
            locationSelect.value = 'shared';
        }
        
        // Load initial directory
        fileBrowserNavigate();
    };

    window.fileBrowserNavigate = function(path) {
        var locationSelect = $('file-browser-location');
        var pathDisplay = $('file-browser-path');
        var fileList = $('file-browser-list');
        
        if (!locationSelect || !pathDisplay || !fileList) return;
        
        if (path !== undefined) {
            fileBrowserState.currentPath = path;
        }
        
        fileBrowserState.currentLocation = locationSelect.value;
        
        // Update path display
        var displayPath = '/' + (fileBrowserState.currentPath || '');
        pathDisplay.textContent = displayPath;
        
        // Show loading
        fileList.innerHTML = '<div class="loading">Loading files...</div>';
        
        // Build API URL
        var url = '/api/browse/' + fileBrowserState.currentLocation;
        if (fileBrowserState.currentPath) {
            url += '/' + fileBrowserState.currentPath;
        }
        
        fetch(url)
        .then(function(response) {
            return response.json();
        })
        .then(function(data) {
            if (data.error) {
                throw new Error(data.error);
            }
            renderFileBrowserList(data.items, data.current_path);
        })
        .catch(function(error) {
            fileList.innerHTML = '<div style="color: red; padding: 10px;">Error loading files: ' + error.message + '</div>';
        });
    };

    function renderFileBrowserList(items, currentPath) {
        var fileList = $('file-browser-list');
        if (!fileList) return;
        
        var html = '';
        
        // Add "Up" button if not at root
        if (currentPath) {
            var parentPath = currentPath.split('/').slice(0, -1).join('/');
            html += '<div class="file-browser-item" onclick="fileBrowserNavigate(\'' + parentPath + '\')">';
            html += '<img src="/static/images/win98_icons/up.bmp" alt="Up">';
            html += '<span class="file-name">..</span>';
            html += '</div>';
        }
        
        // Add directories first
        items.forEach(function(item) {
            if (item.is_dir) {
                var itemPath = currentPath ? currentPath + '/' + item.name : item.name;
                html += '<div class="file-browser-item" onclick="fileBrowserNavigate(\'' + itemPath + '\')">';
                html += '<img src="' + item.icon + '" alt="Directory">';
                html += '<span class="file-name">' + item.name + '</span>';
                html += '</div>';
            }
        });
        
        // Add files
        items.forEach(function(item) {
            if (!item.is_dir) {
                // Filter files based on app type
                var isValidFile = false;
                if (fileBrowserState.appType === 'notes' && item.name.endsWith('.txt')) {
                    isValidFile = true;
                } else if (fileBrowserState.appType === 'code' && (item.name.endsWith('.txt') || item.name.endsWith('.js') || item.name.endsWith('.py') || item.name.endsWith('.html') || item.name.endsWith('.css') || item.name.endsWith('.json') || item.name.endsWith('.xml') || item.name.endsWith('.sh'))) {
                    isValidFile = true;
                }
                
                if (isValidFile) {
                    html += '<div class="file-browser-item" onclick="fileBrowserSelectFile(\'' + item.name + '\')">';
                    html += '<img src="' + item.icon + '" alt="File">';
                    html += '<span class="file-name">' + item.name + '</span>';
                    html += '<span class="file-size">' + (item.formatted_size || '') + '</span>';
                    html += '</div>';
                }
            }
        });
        
        if (html === '') {
            html = '<div style="padding: 20px; text-align: center; color: #666;">No files found</div>';
        }
        
        fileList.innerHTML = html;
    }

    window.fileBrowserSelectFile = function(filename) {
        // Remove previous selection
        var items = document.querySelectorAll('.file-browser-item');
        items.forEach(function(item) {
            item.classList.remove('selected');
        });
        
        // Select clicked item
        event.target.closest('.file-browser-item').classList.add('selected');
        
        // Update selected file
        fileBrowserState.selectedFile = filename;
        var selectedInput = $('file-browser-selected');
        var openBtn = $('file-browser-open-btn');
        
        if (selectedInput) {
            selectedInput.value = filename;
        }
        if (openBtn) {
            openBtn.disabled = false;
        }
    };

    window.fileBrowserOpen = function() {
        if (!fileBrowserState.selectedFile) {
            showError('Please select a file to open');
            return;
        }
        
        var fullPath = fileBrowserState.currentPath ? 
            fileBrowserState.currentPath + '/' + fileBrowserState.selectedFile : 
            fileBrowserState.selectedFile;
        
        // Build download URL
        var url = '/api/download/' + fileBrowserState.currentLocation + '/' + fullPath;
        
        // Load the file content
        fetch(url)
        .then(function(response) {
            if (!response.ok) {
                throw new Error('File not found or cannot be loaded');
            }
            return response.text();
        })
        .then(function(content) {
            // Load content into appropriate editor
            if (fileBrowserState.appType === 'notes') {
                var editor = $('notes-editor');
                var statusText = $('notes-status-text');
                var filenameInput = $('note-filename');
                var directoryInput = $('notes-directory');
                var locationSelect = $('notes-location');
                
                if (editor) editor.value = content;
                if (filenameInput) filenameInput.value = fileBrowserState.selectedFile;
                if (directoryInput) directoryInput.value = fileBrowserState.currentPath || 'documents/notes';
                if (locationSelect) locationSelect.value = fileBrowserState.currentLocation;
                if (statusText) statusText.textContent = 'Loaded: ' + fullPath;
                
                showMessage('Note loaded successfully: ' + fileBrowserState.selectedFile);
            } else if (fileBrowserState.appType === 'code') {
                var editor = $('code-editor');
                var statusText = $('code-status-text');
                var filenameInput = $('code-filename');
                var directoryInput = $('code-directory');
                var locationSelect = $('code-location');
                
                if (editor) {
                    editor.value = content;
                    updateCodeLineNumbers();
                }
                if (filenameInput) filenameInput.value = fileBrowserState.selectedFile;
                if (directoryInput) directoryInput.value = fileBrowserState.currentPath || 'documents/code';
                if (locationSelect) locationSelect.value = fileBrowserState.currentLocation;
                if (statusText) statusText.textContent = 'Loaded: ' + fullPath;
                
                showMessage('Code file loaded successfully: ' + fileBrowserState.selectedFile);
            }
            
            // Close the file browser
            fileBrowserCancel();
        })
        .catch(function(error) {
            showError('Error loading file: ' + error.message);
        });
    };

    window.fileBrowserCancel = function() {
        if (fileBrowserState.window) {
            var closeBtn = fileBrowserState.window.querySelector('.close');
            if (closeBtn) {
                closeWindow(closeBtn);
            }
        }
        fileBrowserState = {
            appType: null,
            currentLocation: 'shared',
            currentPath: '',
            selectedFile: null,
            window: null
        };
    };

    // Browser menu and shortcuts functionality
    window.toggleBrowserMenu = function(menuId) {
        hideBrowserMenus();
        var menu = $(menuId);
        if (menu) {
            if (menu.style.display === 'none' || menu.style.display === '') {
                menu.style.display = 'block';
                // Add menu-open class to parent link
                var parentLink = menu.parentElement;
                if (parentLink && parentLink.tagName === 'A') {
                    parentLink.classList.add('menu-open');
                }
            } else {
                menu.style.display = 'none';
                // Remove menu-open class from parent link
                var parentLink = menu.parentElement;
                if (parentLink && parentLink.tagName === 'A') {
                    parentLink.classList.remove('menu-open');
                }
            }
        }
    };

    window.hideBrowserMenus = function() {
        var menus = ['browser-file-menu', 'browser-edit-menu', 'browser-bookmarks-menu'];
        menus.forEach(function(menuId) {
            var menu = $(menuId);
            if (menu) {
                menu.style.display = 'none';
                // Remove menu-open class from parent link
                var parentLink = menu.parentElement;
                if (parentLink && parentLink.tagName === 'A') {
                    parentLink.classList.remove('menu-open');
                }
            }
        });
    };

    window.newBrowserWindow = function() {
        openWebBrowser();
    };

    window.saveCurrentShortcut = function() {
        var urlInput = $('browser-url');
        if (!urlInput || !urlInput.value.trim()) {
            showError('Please enter a URL first');
            return;
        }
        
        var url = urlInput.value.trim();
        var name = prompt('Enter shortcut name:', getDomainFromUrl(url));
        
        if (name) {
            saveShortcut(name, url);
        }
    };

    window.closeBrowserWindow = function() {
        // Find the current browser window and close it
        var browserWindow = document.querySelector('.window:has(#browser-url)');
        if (browserWindow) {
            var closeBtn = browserWindow.querySelector('.close');
            if (closeBtn) {
                closeWindow(closeBtn);
            }
        }
    };

    window.browserCopy = function() {
        var urlInput = $('browser-url');
        if (urlInput) {
            urlInput.select();
            document.execCommand('copy');
            showMessage('URL copied to clipboard');
        }
    };

    window.browserPaste = function() {
        navigator.clipboard.readText().then(function(text) {
            var urlInput = $('browser-url');
            if (urlInput) {
                urlInput.value = text;
                browserNavigate();
            }
        }).catch(function() {
            showError('Could not paste from clipboard');
        });
    };

    function getDomainFromUrl(url) {
        try {
            var domain = new URL(url).hostname;
            return domain.replace('www.', '');
        } catch (e) {
            return url.substring(0, 20) + '...';
        }
    }

    function saveShortcut(name, url) {
        var shortcut = {
            name: name,
            url: url,
            created: new Date().toISOString()
        };
        
        var blob = new Blob([JSON.stringify(shortcut, null, 2)], { type: 'application/json' });
        var formData = new FormData();
        var filename = name.replace(/[^a-zA-Z0-9]/g, '_') + '.json';
        formData.append('file', blob, filename);
        
        fetch('/api/upload/shared/documents/shortcuts', {
            method: 'POST',
            body: formData
        })
        .then(function(response) {
            if (response.status === 409) {
                // File exists, ask to overwrite
                if (confirm('Shortcut "' + name + '" already exists. Overwrite?')) {
                    var formDataForce = new FormData();
                    formDataForce.append('file', blob, filename);
                    formDataForce.append('force', 'true');
                    
                    return fetch('/api/upload/shared/documents/shortcuts', {
                        method: 'POST',
                        body: formDataForce
                    });
                } else {
                    throw new Error('Save cancelled by user');
                }
            }
            return response;
        })
        .then(function(response) {
            return response.json();
        })
        .then(function(data) {
            if (data.error) {
                throw new Error(data.error);
            }
            showMessage('Shortcut saved: ' + name);
            loadShortcuts(); // Refresh the shortcuts list
        })
        .catch(function(error) {
            if (error.message !== 'Save cancelled by user') {
                showError('Error saving shortcut: ' + error.message);
            }
        });
    }

    window.loadShortcuts = function() {
        fetch('/api/browse/shared/documents/shortcuts')
        .then(function(response) {
            return response.json();
        })
        .then(function(data) {
            if (data.error) {
                // Directory doesn't exist yet, that's ok
                return;
            }
            
            var shortcutsList = $('browser-shortcuts-list');
            if (!shortcutsList) return;
            
            var html = '';
            data.items.forEach(function(item) {
                if (!item.is_dir && item.name.endsWith('.json')) {
                    var shortcutName = item.name.replace('.json', '').replace(/_/g, ' ');
                    html += '<div class="menu-item" onclick="loadShortcut(\'' + item.name + '\')">' + shortcutName + '</div>';
                }
            });
            
            if (html === '') {
                html = '<div class="menu-item" style="color: #666;">No shortcuts saved</div>';
            }
            
            shortcutsList.innerHTML = html;
        })
        .catch(function(error) {
            // Ignore errors, shortcuts directory might not exist yet
        });
    };

    window.loadShortcut = function(filename) {
        fetch('/api/download/shared/documents/shortcuts/' + filename)
        .then(function(response) {
            return response.json();
        })
        .then(function(shortcut) {
            var urlInput = $('browser-url');
            var iframe = $('browser-frame');
            
            if (urlInput && iframe) {
                urlInput.value = shortcut.url;
                iframe.src = shortcut.url;
            }
            
            hideBrowserMenus();
        })
        .catch(function(error) {
            showError('Error loading shortcut: ' + error.message);
        });
    };

    // Add click outside handler for browser menus
    document.addEventListener('click', function(e) {
        if (!e.target.closest('.browser-menu-bar')) {
            hideBrowserMenus();
        }
    });

    // Add click outside handler for explorer menus
    document.addEventListener('click', function(e) {
        if (!e.target.closest('.explorer-menu-bar')) {
            hideExplorerMenus();
        }
    });

    // Markdown Editor functionality
    var markdownState = {
        currentWindow: null,
        currentFilename: '',
        isModified: false,
        previewMode: 'hidden', // 'hidden', 'preview', 'split'
        zoomLevel: 1.0
    };

    window.openMarkdownEditor = function() {
        var content = $('markdown-template').innerHTML;
        markdownState.currentWindow = createWindow('Markdown Editor', content, 800, 600, false, true);
        
        // Set default filename with timestamp
        var now = new Date();
        var timestamp = now.getFullYear() + '-' + 
                      String(now.getMonth() + 1).padStart(2, '0') + '-' + 
                      String(now.getDate()).padStart(2, '0') + '_' +
                      String(now.getHours()).padStart(2, '0') + '-' +
                      String(now.getMinutes()).padStart(2, '0');
        markdownState.currentFilename = 'document_' + timestamp + '.md';
        
        // Initialize the editor
        initializeMarkdownEditor();
        
        // Close start menu if it was open
        if (state.startMenuOpen) {
            toggleStartMenu();
        }
    };

    function initializeMarkdownEditor() {
        var editor = markdownState.currentWindow.querySelector('#markdown-editor');
        var preview = markdownState.currentWindow.querySelector('#markdown-preview');
        
        if (!editor || !preview) return;
        
        // Set up event listeners
        editor.addEventListener('input', function() {
            markdownState.isModified = true;
            updateMarkdownPreview();
            updateMarkdownStats();
            updateWindowTitle();
        });
        
        editor.addEventListener('keydown', function(e) {
            handleMarkdownKeyboard(e);
        });
        
        editor.addEventListener('scroll', function() {
            syncMarkdownScroll();
        });
        
        // Initialize stats and preview
        updateMarkdownStats();
        updateMarkdownPreview();
        updateWindowTitle();
        
        // Focus the editor
        setTimeout(function() {
            editor.focus();
        }, 100);
    }

    function updateMarkdownPreview() {
        var editor = markdownState.currentWindow.querySelector('#markdown-editor');
        var preview = markdownState.currentWindow.querySelector('#markdown-preview');
        
        if (!editor || !preview) return;
        
        var markdown = editor.value;
        var html = parseMarkdown(markdown);
        preview.innerHTML = html;
    }

    function parseMarkdown(markdown) {
        // Simple markdown parser - ES5 compatible
        var html = markdown;
        
        // Headers
        html = html.replace(/^### (.*$)/gim, '<h3>$1</h3>');
        html = html.replace(/^## (.*$)/gim, '<h2>$1</h2>');
        html = html.replace(/^# (.*$)/gim, '<h1>$1</h1>');
        
        // Bold and Italic
        html = html.replace(/\*\*\*(.*?)\*\*\*/g, '<strong><em>$1</em></strong>');
        html = html.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
        html = html.replace(/\*(.*?)\*/g, '<em>$1</em>');
        
        // Code
        html = html.replace(/`([^`]+)`/g, '<code>$1</code>');
        html = html.replace(/```([\s\S]*?)```/g, '<pre><code>$1</code></pre>');
        
        // Links
        html = html.replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2">$1</a>');
        
        // Images
        html = html.replace(/!\[([^\]]*)\]\(([^)]+)\)/g, '<img src="$2" alt="$1">');
        
        // Lists
        html = html.replace(/^\* (.+)$/gm, '<li>$1</li>');
        html = html.replace(/^\d+\. (.+)$/gm, '<li>$1</li>');
        html = html.replace(/((<li>.*<\/li>\s*)+)/g, '<ul>$1</ul>');
        
        // Blockquotes
        html = html.replace(/^> (.+)$/gm, '<blockquote>$1</blockquote>');
        
        // Line breaks
        html = html.replace(/\n\n/g, '</p><p>');
        html = html.replace(/\n/g, '<br>');
        
        // Wrap in paragraphs
        if (html.trim()) {
            html = '<p>' + html + '</p>';
        }
        
        // Clean up empty paragraphs
        html = html.replace(/<p><\/p>/g, '');
        html = html.replace(/<p>\s*<\/p>/g, '');
        
        return html;
    }

    function updateMarkdownStats() {
        var editor = markdownState.currentWindow.querySelector('#markdown-editor');
        if (!editor) return;
        
        var text = editor.value;
        var words = text.trim() ? text.trim().split(/\s+/).length : 0;
        var chars = text.length;
        var lines = text.split('\n').length;
        
        // Get cursor position
        var cursorPos = editor.selectionStart;
        var textBeforeCursor = text.substring(0, cursorPos);
        var line = textBeforeCursor.split('\n').length;
        var col = textBeforeCursor.split('\n').pop().length + 1;
        
        // Update status bar
        var wordCount = markdownState.currentWindow.querySelector('#markdown-word-count');
        var charCount = markdownState.currentWindow.querySelector('#markdown-char-count');
        var lineCount = markdownState.currentWindow.querySelector('#markdown-line-count');
        var cursorPosSpan = markdownState.currentWindow.querySelector('#markdown-cursor-pos');
        
        if (wordCount) wordCount.textContent = 'Words: ' + words;
        if (charCount) charCount.textContent = 'Characters: ' + chars;
        if (lineCount) lineCount.textContent = 'Lines: ' + lines;
        if (cursorPosSpan) cursorPosSpan.textContent = 'Ln ' + line + ', Col ' + col;
    }

    function updateWindowTitle() {
        if (!markdownState.currentWindow) return;
        
        var titleBar = markdownState.currentWindow.querySelector('.title-bar-text');
        if (titleBar) {
            var title = 'Markdown Editor - ' + markdownState.currentFilename;
            if (markdownState.isModified) {
                title += ' *';
            }
            titleBar.textContent = title;
        }
    }

    function handleMarkdownKeyboard(e) {
        var key = e.key || String.fromCharCode(e.keyCode || e.which);
        
        // Ctrl+B for bold
        if (e.ctrlKey && (key === 'b' || key === 'B')) {
            e.preventDefault();
            insertMarkdownBold();
        }
        // Ctrl+I for italic
        else if (e.ctrlKey && (key === 'i' || key === 'I')) {
            e.preventDefault();
            insertMarkdownItalic();
        }
        // Ctrl+S for save
        else if (e.ctrlKey && (key === 's' || key === 'S')) {
            e.preventDefault();
            saveMarkdownDoc();
        }
        // Tab for indentation
        else if (key === 'Tab') {
            e.preventDefault();
            insertAtCursor('    '); // 4 spaces
        }
    }

    function insertAtCursor(text) {
        var editor = markdownState.currentWindow.querySelector('#markdown-editor');
        if (!editor) return;
        
        var start = editor.selectionStart;
        var end = editor.selectionEnd;
        var value = editor.value;
        
        editor.value = value.substring(0, start) + text + value.substring(end);
        editor.selectionStart = editor.selectionEnd = start + text.length;
        
        editor.focus();
        updateMarkdownPreview();
        updateMarkdownStats();
        markdownState.isModified = true;
        updateWindowTitle();
    }

    function wrapSelection(before, after) {
        var editor = markdownState.currentWindow.querySelector('#markdown-editor');
        if (!editor) return;
        
        var start = editor.selectionStart;
        var end = editor.selectionEnd;
        var value = editor.value;
        var selectedText = value.substring(start, end);
        
        var replacement = before + selectedText + (after || before);
        editor.value = value.substring(0, start) + replacement + value.substring(end);
        
        // Select the wrapped text
        editor.selectionStart = start + before.length;
        editor.selectionEnd = start + before.length + selectedText.length;
        
        editor.focus();
        updateMarkdownPreview();
        updateMarkdownStats();
        markdownState.isModified = true;
        updateWindowTitle();
    }

    // Markdown formatting functions
    window.insertMarkdownBold = function() {
        wrapSelection('**');
    };

    window.insertMarkdownItalic = function() {
        wrapSelection('*');
    };

    window.insertMarkdownCode = function() {
        wrapSelection('`');
    };

    window.insertMarkdownH1 = function() {
        insertAtCursor('# ');
    };

    window.insertMarkdownH2 = function() {
        insertAtCursor('## ');
    };

    window.insertMarkdownH3 = function() {
        insertAtCursor('### ');
    };

    window.insertMarkdownList = function() {
        insertAtCursor('- ');
    };

    window.insertMarkdownNumberedList = function() {
        insertAtCursor('1. ');
    };

    window.insertMarkdownQuote = function() {
        insertAtCursor('> ');
    };

    window.insertMarkdownLink = function() {
        var url = prompt('Enter URL:', 'https://');
        var text = prompt('Enter link text:', 'Link');
        if (url && text) {
            insertAtCursor('[' + text + '](' + url + ')');
        }
    };

    window.insertMarkdownImage = function() {
        var url = prompt('Enter image URL:', 'https://');
        var alt = prompt('Enter alt text:', 'Image');
        if (url && alt) {
            insertAtCursor('![' + alt + '](' + url + ')');
        }
    };

    window.insertMarkdownTable = function() {
        var table = '| Header 1 | Header 2 | Header 3 |\n' +
                   '|----------|----------|----------|\n' +
                   '| Cell 1   | Cell 2   | Cell 3   |\n' +
                   '| Cell 4   | Cell 5   | Cell 6   |\n';
        insertAtCursor(table);
    };

    // Markdown menu functions
    window.toggleMarkdownMenu = function(menuId) {
        hideMarkdownMenus();
        var menu = $(menuId);
        if (menu) {
            if (menu.style.display === 'none' || menu.style.display === '') {
                menu.style.display = 'block';
                var parentLink = menu.parentElement;
                if (parentLink) {
                    parentLink.classList.add('menu-open');
                }
            }
        }
    };

    window.hideMarkdownMenus = function() {
        var menus = document.querySelectorAll('.markdown-dropdown-menu');
        for (var i = 0; i < menus.length; i++) {
            menus[i].style.display = 'none';
            var parentLink = menus[i].parentElement;
            if (parentLink) {
                parentLink.classList.remove('menu-open');
            }
        }
    };

    // File menu functions
    window.newMarkdownDoc = function() {
        var editor = markdownState.currentWindow.querySelector('#markdown-editor');
        if (editor) {
            if (markdownState.isModified) {
                if (!confirm('You have unsaved changes. Are you sure you want to create a new document?')) {
                    return;
                }
            }
            editor.value = '';
            markdownState.isModified = false;
            markdownState.currentFilename = 'untitled.md';
            updateMarkdownPreview();
            updateMarkdownStats();
            updateWindowTitle();
            editor.focus();
        }
    };

    window.newMarkdownWindow = function() {
        openMarkdownEditor();
    };

    window.loadMarkdownDoc = function() {
        showMessage('Load functionality not implemented yet');
    };

    window.saveMarkdownDoc = function() {
        var editor = markdownState.currentWindow.querySelector('#markdown-editor');
        if (!editor) return;
        
        var content = editor.value;
        var filename = markdownState.currentFilename;
        
        // Create and download file
        var blob = new Blob([content], { type: 'text/markdown' });
        var url = URL.createObjectURL(blob);
        var a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        
        markdownState.isModified = false;
        updateWindowTitle();
        showMessage('Document saved as ' + filename);
    };

    window.saveAsMarkdownDoc = function() {
        var newFilename = prompt('Enter filename:', markdownState.currentFilename);
        if (newFilename) {
            markdownState.currentFilename = newFilename;
            if (!newFilename.endsWith('.md')) {
                markdownState.currentFilename += '.md';
            }
            saveMarkdownDoc();
        }
    };

    window.exportMarkdownHTML = function() {
        var editor = markdownState.currentWindow.querySelector('#markdown-editor');
        if (!editor) return;
        
        var markdown = editor.value;
        var html = parseMarkdown(markdown);
        var fullHtml = '<!DOCTYPE html>\\n<html>\\n<head>\\n<meta charset="utf-8">\\n<title>' + 
                      markdownState.currentFilename.replace('.md', '') + 
                      '</title>\\n<style>body{font-family:Arial,sans-serif;max-width:800px;margin:0 auto;padding:20px;line-height:1.6;}h1{border-bottom:2px solid #333;}h2{border-bottom:1px solid #ccc;}code{background:#f4f4f4;padding:2px 4px;border-radius:3px;}pre{background:#f4f4f4;padding:10px;border-radius:5px;overflow-x:auto;}blockquote{border-left:4px solid #ddd;margin:0;padding:0 15px;color:#666;}</style>\\n</head>\\n<body>\\n' + 
                      html + '\\n</body>\\n</html>';
        
        var filename = markdownState.currentFilename.replace('.md', '.html');
        var blob = new Blob([fullHtml], { type: 'text/html' });
        var url = URL.createObjectURL(blob);
        var a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        
        showMessage('Exported as ' + filename);
    };

    window.exportMarkdownPDF = function() {
        showMessage('PDF export not available - use browser Print to PDF instead');
    };

    window.closeMarkdownWindow = function() {
        if (markdownState.isModified) {
            if (!confirm('You have unsaved changes. Are you sure you want to close?')) {
                return;
            }
        }
        var closeButton = markdownState.currentWindow.querySelector('.close');
        if (closeButton) {
            closeButton.click();
        }
    };

    // Edit menu functions
    window.markdownUndo = function() {
        document.execCommand('undo');
    };

    window.markdownRedo = function() {
        document.execCommand('redo');
    };

    window.markdownCut = function() {
        document.execCommand('cut');
    };

    window.markdownCopy = function() {
        document.execCommand('copy');
    };

    window.markdownPaste = function() {
        document.execCommand('paste');
    };

    window.markdownSelectAll = function() {
        var editor = markdownState.currentWindow.querySelector('#markdown-editor');
        if (editor) {
            editor.select();
        }
    };

    window.markdownFind = function() {
        var searchTerm = prompt('Find:', '');
        if (searchTerm) {
            var editor = markdownState.currentWindow.querySelector('#markdown-editor');
            if (editor) {
                var content = editor.value;
                var index = content.toLowerCase().indexOf(searchTerm.toLowerCase());
                if (index !== -1) {
                    editor.focus();
                    editor.setSelectionRange(index, index + searchTerm.length);
                } else {
                    alert('Text not found');
                }
            }
        }
    };

    // View menu functions
    window.toggleMarkdownPreview = function() {
        var editorContainer = markdownState.currentWindow.querySelector('#markdown-editor-container');
        var previewContainer = markdownState.currentWindow.querySelector('#markdown-preview-container');
        var content = markdownState.currentWindow.querySelector('.markdown-content');
        
        if (!editorContainer || !previewContainer || !content) return;
        
        if (markdownState.previewMode === 'hidden') {
            // Show preview only
            markdownState.previewMode = 'preview';
            editorContainer.style.display = 'none';
            previewContainer.style.display = 'block';
            content.classList.remove('split-view');
        } else if (markdownState.previewMode === 'preview') {
            // Show editor only
            markdownState.previewMode = 'hidden';
            editorContainer.style.display = 'flex';
            previewContainer.style.display = 'none';
            content.classList.remove('split-view');
        } else {
            // From split view to editor only
            markdownState.previewMode = 'hidden';
            editorContainer.style.display = 'flex';
            previewContainer.style.display = 'none';
            content.classList.remove('split-view');
        }
    };

    window.toggleMarkdownSplitView = function() {
        var editorContainer = markdownState.currentWindow.querySelector('#markdown-editor-container');
        var previewContainer = markdownState.currentWindow.querySelector('#markdown-preview-container');
        var content = markdownState.currentWindow.querySelector('.markdown-content');
        
        if (!editorContainer || !previewContainer || !content) return;
        
        if (markdownState.previewMode === 'split') {
            // Exit split view
            markdownState.previewMode = 'hidden';
            editorContainer.style.display = 'flex';
            previewContainer.style.display = 'none';
            content.classList.remove('split-view');
        } else {
            // Enter split view
            markdownState.previewMode = 'split';
            editorContainer.style.display = 'flex';
            previewContainer.style.display = 'block';
            content.classList.add('split-view');
        }
    };

    window.toggleMarkdownFullscreen = function() {
        showMessage('Fullscreen mode not implemented yet');
    };

    window.markdownZoomIn = function() {
        markdownState.zoomLevel = Math.min(markdownState.zoomLevel + 0.1, 2.0);
        applyMarkdownZoom();
    };

    window.markdownZoomOut = function() {
        markdownState.zoomLevel = Math.max(markdownState.zoomLevel - 0.1, 0.5);
        applyMarkdownZoom();
    };

    window.markdownZoomReset = function() {
        markdownState.zoomLevel = 1.0;
        applyMarkdownZoom();
    };

    function applyMarkdownZoom() {
        var editor = markdownState.currentWindow.querySelector('#markdown-editor');
        var preview = markdownState.currentWindow.querySelector('#markdown-preview');
        
        if (editor) {
            editor.style.fontSize = (14 * markdownState.zoomLevel) + 'px';
        }
        if (preview) {
            preview.style.fontSize = (14 * markdownState.zoomLevel) + 'px';
        }
    }

    function syncMarkdownScroll() {
        // Sync scroll between editor and preview (simplified)
        var editor = markdownState.currentWindow.querySelector('#markdown-editor');
        var preview = markdownState.currentWindow.querySelector('#markdown-preview-container');
        
        if (editor && preview && markdownState.previewMode === 'split') {
            var scrollPercent = editor.scrollTop / (editor.scrollHeight - editor.clientHeight);
            preview.scrollTop = scrollPercent * (preview.scrollHeight - preview.clientHeight);
        }
    }

    // Add click outside handler for markdown menus
    document.addEventListener('click', function(e) {
        if (!e.target.closest('.markdown-menu-bar')) {
            hideMarkdownMenus();
        }
    });

    // Mail Client functionality
    var mailState = {
        currentFolder: 'INBOX',
        currentPage: 1,
        totalPages: 1,
        emailsPerPage: 25,
        emails: [],
        selectedEmails: [],
        isConnected: false,
        settings: {
            imapServer: '',
            imapPort: 993,
            smtpServer: '',
            smtpPort: 587,
            username: '',
            password: '',
            useSSL: true
        }
    };

    window.openMailClient = function() {
        var template = $('mail-template');
        if (!template) return;
        
        var win = createWindow('Mail Client', template.innerHTML, 800, 600, false, false);
        win.classList.add('mail-window');
        
        // Initialize mail client
        loadMailSettings();
        updateMailConnectionStatus();
        updateMailStatus('Ready');
        
        // Load inbox by default
        setTimeout(function() {
            selectMailFolder('INBOX');
        }, 500);
    };

    function loadMailSettings() {
        // Load settings from localStorage or server
        var saved = localStorage.getItem('qnx-mail-settings');
        if (saved) {
            try {
                mailState.settings = JSON.parse(saved);
            } catch (e) {
                console.error('Failed to load mail settings:', e);
            }
        }
    }

    function saveMailSettings() {
        localStorage.setItem('qnx-mail-settings', JSON.stringify(mailState.settings));
    }

    window.toggleMailMenu = function(menuId) {
        hideMailMenus();
        var menu = $(menuId);
        if (menu) {
            menu.style.display = menu.style.display === 'none' ? 'block' : 'none';
            if (menu.style.display === 'block') {
                menu.parentElement.classList.add('menu-open');
            }
        }
    };

    window.hideMailMenus = function() {
        var menus = document.querySelectorAll('.mail-dropdown-menu');
        for (var i = 0; i < menus.length; i++) {
            menus[i].style.display = 'none';
            if (menus[i].parentElement) {
                menus[i].parentElement.classList.remove('menu-open');
            }
        }
    };

    window.selectMailFolder = function(folder) {
        mailState.currentFolder = folder;
        mailState.currentPage = 1;
        
        // Update folder selection UI
        var folders = document.querySelectorAll('.folder-item');
        for (var i = 0; i < folders.length; i++) {
            folders[i].classList.remove('active');
        }
        event.target.closest('.folder-item').classList.add('active');
        
        // Load emails for selected folder
        loadMailFolder(folder);
    };

    function loadMailFolder(folder) {
        updateMailStatus('Loading ' + folder.toLowerCase() + '...');
        
        // Make API call to load emails
        fetch('/api/mail/folder/' + folder + '?page=' + mailState.currentPage + '&limit=' + mailState.emailsPerPage)
            .then(function(response) { return response.json(); })
            .then(function(data) {
                if (data.error) {
                    updateMailStatus('Error: ' + data.error);
                    updateMailList([]);
                    return;
                }
                
                mailState.emails = data.emails || [];
                mailState.totalPages = data.totalPages || 1;
                updateMailList(mailState.emails);
                updateMailPagination();
                updateMailStatus('Loaded ' + mailState.emails.length + ' emails from ' + folder);
                
                // Update connection status
                updateMailConnectionStatus();
            })
            .catch(function(error) {
                console.error('Failed to load emails:', error);
                updateMailStatus('Failed to load emails - Check connection settings');
                updateMailList([]);
            });
    }

    function updateMailList(emails) {
        var mailList = $('mail-list');
        if (!mailList) return;
        
        if (emails.length === 0) {
            mailList.innerHTML = '<div class="mail-loading">No emails in this folder</div>';
            return;
        }
        
        var html = '';
        for (var i = 0; i < emails.length; i++) {
            var email = emails[i];
            var unreadClass = email.unread ? ' unread' : '';
            html += '<div class="mail-item' + unreadClass + '" onclick="selectMailItem(this, ' + i + ')" ondblclick="openMailItem(' + i + ')">';
            html += '<div class="mail-col-from">' + escapeHtml(email.from || '') + '</div>';
            html += '<div class="mail-col-subject">' + escapeHtml(email.subject || '(No Subject)') + '</div>';
            html += '<div class="mail-col-date">' + formatMailDate(email.date) + '</div>';
            html += '<div class="mail-col-size">' + formatMailSize(email.size) + '</div>';
            html += '</div>';
        }
        mailList.innerHTML = html;
    }

    function formatMailDate(dateStr) {
        if (!dateStr) return '';
        var date = new Date(dateStr);
        var now = new Date();
        var today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
        var emailDate = new Date(date.getFullYear(), date.getMonth(), date.getDate());
        
        if (emailDate.getTime() === today.getTime()) {
            return date.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
        } else {
            return date.toLocaleDateString();
        }
    }

    function formatMailSize(bytes) {
        if (!bytes) return '';
        if (bytes < 1024) return bytes + 'B';
        if (bytes < 1024 * 1024) return Math.round(bytes / 1024) + 'KB';
        return Math.round(bytes / (1024 * 1024)) + 'MB';
    }

    function updateMailPagination() {
        var pageInfo = $('mail-page-info');
        var prevBtn = $('mail-prev-btn');
        var nextBtn = $('mail-next-btn');
        
        if (pageInfo) {
            pageInfo.textContent = 'Page ' + mailState.currentPage + ' of ' + mailState.totalPages;
        }
        
        if (prevBtn) {
            prevBtn.disabled = mailState.currentPage <= 1;
        }
        
        if (nextBtn) {
            nextBtn.disabled = mailState.currentPage >= mailState.totalPages;
        }
    }

    function updateMailStatus(message) {
        var statusText = $('mail-status-text');
        if (statusText) {
            statusText.textContent = message;
        }
    }

    function updateMailConnectionStatus() {
        fetch('/api/mail/status')
            .then(function(response) { return response.json(); })
            .then(function(data) {
                var connectionStatus = $('mail-connection-status');
                if (connectionStatus) {
                    if (data.connected && data.configured) {
                        connectionStatus.textContent = 'Connected: ' + data.username;
                        connectionStatus.style.color = '#008000';
                        mailState.isConnected = true;
                    } else if (data.configured) {
                        connectionStatus.textContent = 'Configured - Click Refresh to connect';
                        connectionStatus.style.color = '#ff8800';
                        mailState.isConnected = false;
                    } else {
                        connectionStatus.textContent = 'Not configured';
                        connectionStatus.style.color = '#ff0000';
                        mailState.isConnected = false;
                    }
                }
            })
            .catch(function(error) {
                console.error('Failed to get mail status:', error);
                var connectionStatus = $('mail-connection-status');
                if (connectionStatus) {
                    connectionStatus.textContent = 'Connection error';
                    connectionStatus.style.color = '#ff0000';
                }
            });
    }

    window.selectMailItem = function(element, index) {
        // Clear previous selections
        var items = document.querySelectorAll('.mail-item');
        for (var i = 0; i < items.length; i++) {
            items[i].classList.remove('selected');
        }
        
        // Select current item
        element.classList.add('selected');
        mailState.selectedEmails = [index];
    };

    window.openMailItem = function(index) {
        var email = mailState.emails[index];
        if (!email) return;
        
        // Create email viewer window
        var content = '<div class="email-viewer">' +
            '<div class="email-header">' +
            '<div><strong>From:</strong> ' + escapeHtml(email.from || '') + '</div>' +
            '<div><strong>To:</strong> ' + escapeHtml(email.to || '') + '</div>' +
            '<div><strong>Subject:</strong> ' + escapeHtml(email.subject || '(No Subject)') + '</div>' +
            '<div><strong>Date:</strong> ' + (email.date ? new Date(email.date).toLocaleString() : '') + '</div>' +
            '</div>' +
            '<div class="email-body">' + (email.body || 'Loading...') + '</div>' +
            '</div>';
        
        var win = createWindow('Email: ' + (email.subject || '(No Subject)'), content, 600, 500, false, false);
        
        // Load full email content if not already loaded
        if (!email.body) {
            loadFullEmail(email.id, win);
        }
    };

    function loadFullEmail(emailId, window) {
        fetch('/api/mail/email/' + emailId)
            .then(function(response) { return response.json(); })
            .then(function(data) {
                var bodyDiv = window.querySelector('.email-body');
                if (bodyDiv) {
                    bodyDiv.innerHTML = data.body || 'No content';
                }
            })
            .catch(function(error) {
                console.error('Failed to load email:', error);
                var bodyDiv = window.querySelector('.email-body');
                if (bodyDiv) {
                    bodyDiv.innerHTML = 'Failed to load email content';
                }
            });
    }

    // Mail menu functions
    window.newMailMessage = function() {
        var template = $('compose-template');
        if (!template) return;
        
        var win = createWindow('Compose Email', template.innerHTML, 600, 500, false, false);
        win.classList.add('compose-window');
        
        // Initialize character counter
        var messageArea = win.querySelector('#compose-message');
        var charCount = win.querySelector('#compose-char-count');
        
        if (messageArea && charCount) {
            messageArea.oninput = function() {
                charCount.textContent = messageArea.value.length + ' characters';
            };
        }
        
        // Focus on To field
        var toField = win.querySelector('#compose-to');
        if (toField) {
            setTimeout(function() { toField.focus(); }, 100);
        }
    };

    window.refreshMailbox = function() {
        loadMailFolder(mailState.currentFolder);
    };

    window.mailSettings = function() {
        // Create settings dialog
        var settingsHtml = '<div class="mail-settings">' +
            '<h3>Mail Account Settings</h3>' +
            '<form id="mail-settings-form">' +
            '<div class="form-group">' +
            '<label>IMAP Server:</label>' +
            '<input type="text" id="imap-server" placeholder="imap.gmail.com" required>' +
            '</div>' +
            '<div class="form-group">' +
            '<label>IMAP Port:</label>' +
            '<input type="number" id="imap-port" value="993" required>' +
            '</div>' +
            '<div class="form-group">' +
            '<label>SMTP Server:</label>' +
            '<input type="text" id="smtp-server" placeholder="smtp.gmail.com" required>' +
            '</div>' +
            '<div class="form-group">' +
            '<label>SMTP Port:</label>' +
            '<input type="number" id="smtp-port" value="587" required>' +
            '</div>' +
            '<div class="form-group">' +
            '<label>Username/Email:</label>' +
            '<input type="email" id="mail-username" placeholder="your@email.com" required>' +
            '</div>' +
            '<div class="form-group">' +
            '<label>Password:</label>' +
            '<input type="password" id="mail-password" placeholder="Password or App Password" required>' +
            '</div>' +
            '<div class="form-group">' +
            '<label><input type="checkbox" id="use-ssl" checked> Use SSL/TLS</label>' +
            '</div>' +
            '<div class="form-buttons">' +
            '<button type="button" onclick="testMailConnection()">Test Connection</button>' +
            '<button type="submit">Save Settings</button>' +
            '<button type="button" onclick="closeMailSettings()">Cancel</button>' +
            '</div>' +
            '</form>' +
            '<div id="mail-test-result" style="margin-top: 10px; padding: 5px; display: none;"></div>' +
            '</div>';
        
        var win = createWindow('Mail Settings', settingsHtml, 500, 450, false, false);
        win.classList.add('mail-settings-window');
        
        // Load current settings
        fetch('/api/mail/config')
            .then(function(response) { return response.json(); })
            .then(function(config) {
                $('imap-server').value = config.imap_server || '';
                $('imap-port').value = config.imap_port || 993;
                $('smtp-server').value = config.smtp_server || '';
                $('smtp-port').value = config.smtp_port || 587;
                $('mail-username').value = config.username || '';
                $('mail-password').value = config.password === '***' ? '' : config.password || '';
                $('use-ssl').checked = config.use_ssl !== false;
            })
            .catch(function(error) {
                console.error('Failed to load mail config:', error);
            });
        
        // Handle form submission
        var form = $('mail-settings-form');
        if (form) {
            form.onsubmit = function(e) {
                e.preventDefault();
                saveMailSettings();
            };
        }
    };

    window.closeMailWindow = function() {
        // Close the current mail window
        var mailWindow = document.querySelector('.mail-window');
        if (mailWindow) {
            closeWindow(mailWindow.querySelector('.close'));
        }
    };

    window.mailReply = function() {
        if (mailState.selectedEmails.length === 0) {
            alert('Please select an email to reply to');
            return;
        }
        alert('Reply - Coming soon!');
    };

    window.mailForward = function() {
        if (mailState.selectedEmails.length === 0) {
            alert('Please select an email to forward');
            return;
        }
        alert('Forward - Coming soon!');
    };

    window.mailDelete = function() {
        if (mailState.selectedEmails.length === 0) {
            alert('Please select emails to delete');
            return;
        }
        
        var emailCount = mailState.selectedEmails.length;
        var message = emailCount === 1 ? 'Delete this email?' : 'Delete ' + emailCount + ' emails?';
        
        if (confirm(message)) {
            updateMailStatus('Deleting emails...');
            
            // Get the email IDs from selected emails
            var emailIds = [];
            for (var i = 0; i < mailState.selectedEmails.length; i++) {
                var index = mailState.selectedEmails[i];
                if (mailState.emails[index]) {
                    emailIds.push(mailState.emails[index].id);
                }
            }
            
            fetch('/api/mail/delete', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    email_ids: emailIds,
                    folder: mailState.currentFolder
                })
            })
            .then(function(response) { return response.json(); })
            .then(function(data) {
                if (data.success) {
                    updateMailStatus(data.message);
                    // Clear selection and refresh the folder
                    mailState.selectedEmails = [];
                    loadMailFolder(mailState.currentFolder);
                } else {
                    updateMailStatus('Delete failed: ' + data.message);
                    alert('Failed to delete emails: ' + data.message);
                }
            })
            .catch(function(error) {
                console.error('Delete failed:', error);
                updateMailStatus('Delete failed: ' + error.message);
                alert('Failed to delete emails: ' + error.message);
            });
        }
    };

    window.mailPrevPage = function() {
        if (mailState.currentPage > 1) {
            mailState.currentPage--;
            loadMailFolder(mailState.currentFolder);
        }
    };

    window.mailNextPage = function() {
        if (mailState.currentPage < mailState.totalPages) {
            mailState.currentPage++;
            loadMailFolder(mailState.currentFolder);
        }
    };

    function saveMailSettings() {
        var config = {
            imap_server: $('imap-server').value,
            imap_port: parseInt($('imap-port').value),
            smtp_server: $('smtp-server').value,
            smtp_port: parseInt($('smtp-port').value),
            username: $('mail-username').value,
            password: $('mail-password').value,
            use_ssl: $('use-ssl').checked,
            use_tls: $('use-ssl').checked
        };
        
        fetch('/api/mail/config', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(config)
        })
        .then(function(response) { return response.json(); })
        .then(function(data) {
            if (data.success) {
                alert('Settings saved successfully!');
                closeMailSettings();
                updateMailConnectionStatus();
            } else {
                alert('Failed to save settings: ' + (data.error || 'Unknown error'));
            }
        })
        .catch(function(error) {
            console.error('Failed to save settings:', error);
            alert('Failed to save settings: ' + error.message);
        });
    }

    window.testMailConnection = function() {
        var resultDiv = $('mail-test-result');
        if (resultDiv) {
            resultDiv.style.display = 'block';
            resultDiv.textContent = 'Testing connection...';
            resultDiv.style.backgroundColor = '#ffffcc';
            resultDiv.style.color = '#000';
        }
        
        // First save current settings
        var config = {
            imap_server: $('imap-server').value,
            imap_port: parseInt($('imap-port').value),
            smtp_server: $('smtp-server').value,
            smtp_port: parseInt($('smtp-port').value),
            username: $('mail-username').value,
            password: $('mail-password').value,
            use_ssl: $('use-ssl').checked,
            use_tls: $('use-ssl').checked
        };
        
        fetch('/api/mail/config', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(config)
        })
        .then(function(response) { return response.json(); })
        .then(function(data) {
            if (data.success) {
                // Now test the connection
                return fetch('/api/mail/test-connection', { method: 'POST' });
            } else {
                throw new Error(data.error || 'Failed to save settings');
            }
        })
        .then(function(response) { return response.json(); })
        .then(function(data) {
            if (resultDiv) {
                if (data.success) {
                    resultDiv.textContent = '✓ Connection successful: ' + data.message;
                    resultDiv.style.backgroundColor = '#ccffcc';
                    resultDiv.style.color = '#008000';
                } else {
                    resultDiv.textContent = '✗ Connection failed: ' + data.message;
                    resultDiv.style.backgroundColor = '#ffcccc';
                    resultDiv.style.color = '#cc0000';
                }
            }
        })
        .catch(function(error) {
            console.error('Connection test failed:', error);
            if (resultDiv) {
                resultDiv.textContent = '✗ Test failed: ' + error.message;
                resultDiv.style.backgroundColor = '#ffcccc';
                resultDiv.style.color = '#cc0000';
            }
        });
    };

    window.closeMailSettings = function() {
        var settingsWindow = document.querySelector('.mail-settings-window');
        if (settingsWindow) {
            closeWindow(settingsWindow.querySelector('.close'));
        }
    };

    // Compose email functions
    window.sendComposedEmail = function() {
        var toField = $('compose-to');
        var ccField = $('compose-cc');
        var bccField = $('compose-bcc');
        var subjectField = $('compose-subject');
        var messageField = $('compose-message');
        var statusField = $('compose-status-text');
        
        if (!toField || !subjectField || !messageField) {
            alert('Compose window not found');
            return;
        }
        
        // Validate required fields
        if (!toField.value.trim()) {
            alert('Please enter a recipient email address');
            toField.focus();
            return;
        }
        
        if (!subjectField.value.trim()) {
            alert('Please enter a subject');
            subjectField.focus();
            return;
        }
        
        if (!messageField.value.trim()) {
            alert('Please enter a message');
            messageField.focus();
            return;
        }
        
        // Update status
        if (statusField) {
            statusField.textContent = 'Sending email...';
        }
        
        // Send the email
        fetch('/api/mail/send', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                to: toField.value.trim(),
                cc: ccField ? ccField.value.trim() : '',
                bcc: bccField ? bccField.value.trim() : '',
                subject: subjectField.value.trim(),
                body: messageField.value
            })
        })
        .then(function(response) { return response.json(); })
        .then(function(data) {
            if (data.success) {
                if (statusField) {
                    statusField.textContent = 'Email sent successfully!';
                }
                alert('Email sent successfully!');
                closeComposeWindow();
            } else {
                if (statusField) {
                    statusField.textContent = 'Send failed: ' + data.message;
                }
                alert('Failed to send email: ' + data.message);
            }
        })
        .catch(function(error) {
            console.error('Send failed:', error);
            if (statusField) {
                statusField.textContent = 'Send failed: ' + error.message;
            }
            alert('Failed to send email: ' + error.message);
        });
    };

    window.closeComposeWindow = function() {
        var composeWindow = document.querySelector('.compose-window');
        if (composeWindow) {
            closeWindow(composeWindow.querySelector('.close'));
        }
    };

    window.toggleComposeMenu = function(menuId) {
        hideComposeMenus();
        var menu = $(menuId);
        if (menu) {
            menu.style.display = menu.style.display === 'none' ? 'block' : 'none';
            if (menu.style.display === 'block') {
                menu.parentElement.classList.add('menu-open');
            }
        }
    };

    window.hideComposeMenus = function() {
        var menus = document.querySelectorAll('.compose-dropdown-menu');
        for (var i = 0; i < menus.length; i++) {
            menus[i].style.display = 'none';
            if (menus[i].parentElement) {
                menus[i].parentElement.classList.remove('menu-open');
            }
        }
    };

    // Placeholder compose functions
    window.saveComposeDraft = function() { alert('Save Draft - Coming soon!'); };
    window.attachFile = function() { alert('Attach File - Coming soon!'); };
    window.composeUndo = function() { alert('Undo - Coming soon!'); };
    window.composeRedo = function() { alert('Redo - Coming soon!'); };
    window.composeCut = function() { alert('Cut - Coming soon!'); };
    window.composeCopy = function() { alert('Copy - Coming soon!'); };
    window.composePaste = function() { alert('Paste - Coming soon!'); };
    window.composeSelectAll = function() { alert('Select All - Coming soon!'); };
    window.showComposeHelp = function() { alert('Compose Help - Coming soon!'); };
    window.showComposeAbout = function() { alert('QNX Mail Composer v1.0'); };

    // Mail management functions
    window.mailSelectAll = function() { 
        // Select all visible emails
        var items = document.querySelectorAll('.mail-item');
        mailState.selectedEmails = [];
        for (var i = 0; i < items.length; i++) {
            items[i].classList.add('selected');
            mailState.selectedEmails.push(i);
        }
    };
    
    window.mailMarkRead = function() {
        if (mailState.selectedEmails.length === 0) {
            alert('Please select emails to mark as read');
            return;
        }
        
        updateMailStatus('Marking emails as read...');
        
        var emailIds = [];
        for (var i = 0; i < mailState.selectedEmails.length; i++) {
            var index = mailState.selectedEmails[i];
            if (mailState.emails[index]) {
                emailIds.push(mailState.emails[index].id);
            }
        }
        
        fetch('/api/mail/mark-read', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                email_ids: emailIds,
                folder: mailState.currentFolder
            })
        })
        .then(function(response) { return response.json(); })
        .then(function(data) {
            if (data.success) {
                updateMailStatus(data.message);
                loadMailFolder(mailState.currentFolder);
            } else {
                updateMailStatus('Mark as read failed: ' + data.message);
            }
        })
        .catch(function(error) {
            console.error('Mark as read failed:', error);
            updateMailStatus('Mark as read failed: ' + error.message);
        });
    };
    
    window.mailMarkUnread = function() {
        if (mailState.selectedEmails.length === 0) {
            alert('Please select emails to mark as unread');
            return;
        }
        
        updateMailStatus('Marking emails as unread...');
        
        var emailIds = [];
        for (var i = 0; i < mailState.selectedEmails.length; i++) {
            var index = mailState.selectedEmails[i];
            if (mailState.emails[index]) {
                emailIds.push(mailState.emails[index].id);
            }
        }
        
        fetch('/api/mail/mark-unread', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                email_ids: emailIds,
                folder: mailState.currentFolder
            })
        })
        .then(function(response) { return response.json(); })
        .then(function(data) {
            if (data.success) {
                updateMailStatus(data.message);
                loadMailFolder(mailState.currentFolder);
            } else {
                updateMailStatus('Mark as unread failed: ' + data.message);
            }
        })
        .catch(function(error) {
            console.error('Mark as unread failed:', error);
            updateMailStatus('Mark as unread failed: ' + error.message);
        });
    };
    window.mailMove = function() { alert('Move to Folder - Coming soon!'); };
    window.mailRefresh = function() { refreshMailbox(); };
    window.mailTogglePreview = function() { alert('Preview Pane - Coming soon!'); };
    window.mailSortBy = function(field) { alert('Sort by ' + field + ' - Coming soon!'); };
    window.showMailHelp = function() { alert('Mail Help - Coming soon!'); };
    window.showMailAbout = function() { alert('QNX Mail Client v1.0 - Full IMAP/SMTP Support'); };

    // AI Chat functionality
    var aiChatState = {
        apiKey: null,
        systemPrompt: "You are a helpful AI assistant running on a QNX BlackBerry device. Be concise but informative.",
        model: "claude-3-haiku-20240307",
        conversation: [],
        currentWindow: null
    };

    // Close AI Chat menus when clicking outside
    document.addEventListener('click', function(e) {
        if (!e.target.closest('.aichat-menu-bar')) {
            hideAIChatMenus();
        }
    });

    window.openAIChat = function() {
        var content = $('aichat-template').innerHTML;
        aiChatState.currentWindow = createWindow('AI Chat Assistant', content, 700, 600, false, true);
        
        // Initialize the chat
        loadAIChatSettings();
        updateAIChatStatus();
        updateAIChatMessageCount();
    };

    window.toggleAIChatMenu = function(menuId) {
        hideAIChatMenus();
        var menu = $(menuId);
        if (menu) {
            if (menu.style.display === 'none' || menu.style.display === '') {
                menu.style.display = 'block';
                var parentLink = menu.parentElement;
                if (parentLink && parentLink.tagName === 'A') {
                    parentLink.classList.add('menu-open');
                }
            } else {
                menu.style.display = 'none';
                var parentLink = menu.parentElement;
                if (parentLink && parentLink.tagName === 'A') {
                    parentLink.classList.remove('menu-open');
                }
            }
        }
    };

    window.hideAIChatMenus = function() {
        var menus = ['aichat-file-menu', 'aichat-settings-menu', 'aichat-help-menu'];
        menus.forEach(function(menuId) {
            var menu = $(menuId);
            if (menu) {
                menu.style.display = 'none';
                var parentLink = menu.parentElement;
                if (parentLink && parentLink.tagName === 'A') {
                    parentLink.classList.remove('menu-open');
                }
            }
        });
    };

    window.handleAIChatKeydown = function(event) {
        if (event.key === 'Enter' && !event.shiftKey) {
            event.preventDefault();
            sendAIChatMessage();
        }
    };

    window.sendAIChatMessage = function() {
        var input = $('aichat-input');
        var sendBtn = $('aichat-send-btn');
        
        if (!input || !sendBtn) return;
        
        var message = input.value.trim();
        if (!message) return;
        
        if (!aiChatState.apiKey) {
            showError('Please configure your Claude API key in Settings → API Configuration');
            return;
        }
        
        // Add user message to conversation
        addAIChatMessage('user', message);
        input.value = '';
        
        // Disable send button and show loading
        sendBtn.disabled = true;
        sendBtn.textContent = 'Sending...';
        updateAIChatStatus('Sending message...');
        
        // Add loading message
        var loadingId = addAIChatMessage('assistant', '', true);
        
        // Send to Claude API
        var requestData = {
            message: message,
            conversation: aiChatState.conversation,
            system_prompt: aiChatState.systemPrompt,
            model: aiChatState.model
        };
        
        fetch('/api/aichat/send', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(requestData)
        })
        .then(function(response) {
            return response.json();
        })
        .then(function(data) {
            // Remove loading message
            removeAIChatMessage(loadingId);
            
            if (data.error) {
                addAIChatMessage('system', 'Error: ' + data.error);
                showError('AI Chat Error: ' + data.error);
            } else {
                addAIChatMessage('assistant', data.response);
                aiChatState.conversation = data.conversation;
            }
        })
        .catch(function(error) {
            removeAIChatMessage(loadingId);
            addAIChatMessage('system', 'Connection error: ' + error.message);
            showError('Connection error: ' + error.message);
        })
        .finally(function() {
            sendBtn.disabled = false;
            sendBtn.textContent = 'Send';
            updateAIChatStatus('Ready');
            updateAIChatMessageCount();
        });
    };

    window.addAIChatMessage = function(sender, content, isLoading) {
        var conversation = $('aichat-conversation');
        if (!conversation) return null;
        
        var messageId = 'msg-' + Date.now() + '-' + Math.random().toString(36).substr(2, 9);
        var messageDiv = document.createElement('div');
        messageDiv.className = 'aichat-message ' + sender;
        messageDiv.id = messageId;
        
        var now = new Date();
        var timeStr = now.getHours().toString().padStart(2, '0') + ':' + 
                     now.getMinutes().toString().padStart(2, '0');
        
        var senderName = sender === 'user' ? 'You' : 
                        sender === 'assistant' ? 'AI Assistant' : 'System';
        
        if (isLoading) {
            messageDiv.innerHTML = 
                '<div class="message-header">' +
                    '<span class="message-sender">' + senderName + '</span>' +
                    '<span class="message-time">' + timeStr + '</span>' +
                '</div>' +
                '<div class="message-content aichat-loading">Thinking</div>';
        } else {
            messageDiv.innerHTML = 
                '<div class="message-header">' +
                    '<span class="message-sender">' + senderName + '</span>' +
                    '<span class="message-time">' + timeStr + '</span>' +
                '</div>' +
                '<div class="message-content">' + escapeHtml(content) + '</div>';
        }
        
        conversation.appendChild(messageDiv);
        conversation.scrollTop = conversation.scrollHeight;
        
        return messageId;
    };

    window.removeAIChatMessage = function(messageId) {
        var message = $(messageId);
        if (message && message.parentNode) {
            message.parentNode.removeChild(message);
        }
    };

    window.updateAIChatStatus = function(status) {
        var statusEl = $('aichat-connection-status');
        if (statusEl) {
            statusEl.textContent = status || (aiChatState.apiKey ? 'Connected' : 'Not Connected');
        }
    };

    window.updateAIChatMessageCount = function() {
        var countEl = $('aichat-message-count');
        if (countEl) {
            countEl.textContent = 'Messages: ' + aiChatState.conversation.length;
        }
    };

    window.newAIChatConversation = function() {
        if (aiChatState.conversation.length > 0) {
            if (!confirm('Start a new conversation? Current conversation will be lost unless saved.')) {
                return;
            }
        }
        
        aiChatState.conversation = [];
        var conversation = $('aichat-conversation');
        if (conversation) {
            conversation.innerHTML = 
                '<div class="aichat-welcome">' +
                    '<div class="aichat-message system">' +
                        '<div class="message-header">' +
                            '<span class="message-sender">AI Assistant</span>' +
                            '<span class="message-time"></span>' +
                        '</div>' +
                        '<div class="message-content">' +
                            'New conversation started. How can I help you?' +
                        '</div>' +
                    '</div>' +
                '</div>';
        }
        updateAIChatMessageCount();
        updateAIChatStatus('Ready');
    };

    window.saveAIChatConversation = function() {
        if (aiChatState.conversation.length === 0) {
            showError('No conversation to save');
            return;
        }
        
        var filename = prompt('Enter filename for conversation:', 'conversation_' + new Date().toISOString().slice(0, 10));
        if (!filename) return;
        
        if (!filename.endsWith('.json')) {
            filename += '.json';
        }
        
        var conversationData = {
            timestamp: new Date().toISOString(),
            system_prompt: aiChatState.systemPrompt,
            model: aiChatState.model,
            messages: aiChatState.conversation
        };
        
        var blob = new Blob([JSON.stringify(conversationData, null, 2)], { type: 'application/json' });
        var formData = new FormData();
        formData.append('file', blob, filename);
        
        fetch('/api/upload/shared/documents/AI', {
            method: 'POST',
            body: formData
        })
        .then(function(response) {
            return response.json();
        })
        .then(function(data) {
            if (data.error) {
                showError('Save failed: ' + data.error);
            } else {
                showMessage('Conversation saved: ' + filename);
            }
        })
        .catch(function(error) {
            showError('Save failed: ' + error.message);
        });
    };

    window.loadAIChatConversation = function() {
        // Open file browser for AI directory
        openFileBrowser('aichat-load');
    };

    window.exportAIChatConversation = function() {
        if (aiChatState.conversation.length === 0) {
            showError('No conversation to export');
            return;
        }
        
        var text = 'AI Chat Conversation Export\\n';
        text += 'Date: ' + new Date().toLocaleString() + '\\n';
        text += 'Model: ' + aiChatState.model + '\\n';
        text += 'System Prompt: ' + aiChatState.systemPrompt + '\\n';
        text += '\\n' + '='.repeat(50) + '\\n\\n';
        
        aiChatState.conversation.forEach(function(msg, index) {
            var sender = msg.role === 'user' ? 'You' : 'AI Assistant';
            text += sender + ':\\n' + msg.content + '\\n\\n';
        });
        
        var filename = 'conversation_export_' + new Date().toISOString().slice(0, 10) + '.txt';
        var blob = new Blob([text], { type: 'text/plain' });
        var formData = new FormData();
        formData.append('file', blob, filename);
        
        fetch('/api/upload/shared/documents/AI', {
            method: 'POST',
            body: formData
        })
        .then(function(response) {
            return response.json();
        })
        .then(function(data) {
            if (data.error) {
                showError('Export failed: ' + data.error);
            } else {
                showMessage('Conversation exported: ' + filename);
            }
        })
        .catch(function(error) {
            showError('Export failed: ' + error.message);
        });
    };

    window.openAIChatAPISettings = function() {
        var currentKey = aiChatState.apiKey || '';
        var newKey = prompt('Enter your Claude API key:', currentKey);
        
        if (newKey !== null) {
            aiChatState.apiKey = newKey.trim();
            saveAIChatSettings();
            updateAIChatStatus();
            
            if (aiChatState.apiKey) {
                showMessage('API key configured successfully');
            } else {
                showMessage('API key cleared');
            }
        }
    };

    window.openAIChatSystemPrompt = function() {
        var newPrompt = prompt('Enter system prompt:', aiChatState.systemPrompt);
        
        if (newPrompt !== null) {
            aiChatState.systemPrompt = newPrompt.trim() || "You are a helpful AI assistant.";
            saveAIChatSettings();
            showMessage('System prompt updated');
        }
    };

    window.openAIChatModelSettings = function() {
        var models = [
            'claude-3-haiku-20240307',
            'claude-3-sonnet-20240229',
            'claude-3-opus-20240229'
        ];
        
        var modelDescriptions = {
            'claude-3-haiku-20240307': 'Haiku - Fast and efficient (Recommended)',
            'claude-3-sonnet-20240229': 'Sonnet - Balanced performance',
            'claude-3-opus-20240229': 'Opus - Most capable but slower'
        };
        
        var currentIndex = models.indexOf(aiChatState.model);
        if (currentIndex === -1) currentIndex = 0;
        
        var modelList = models.map(function(model, index) {
            var marker = index === currentIndex ? '→ ' : '  ';
            return marker + (index + 1) + '. ' + modelDescriptions[model];
        }).join('\\n');
        
        var choice = prompt(
            'Select Claude model:\\n\\n' + modelList + '\\n\\nEnter number (1-3):', 
            (currentIndex + 1).toString()
        );
        
        if (choice !== null) {
            var choiceNum = parseInt(choice.trim());
            if (choiceNum >= 1 && choiceNum <= 3) {
                aiChatState.model = models[choiceNum - 1];
                saveAIChatSettings();
                showMessage('Model updated to: ' + modelDescriptions[aiChatState.model]);
            } else {
                showError('Invalid selection. Please enter 1, 2, or 3.');
            }
        }
    };

    window.clearAIChatHistory = function() {
        if (confirm('Clear all conversation history? This cannot be undone.')) {
            newAIChatConversation();
            showMessage('Conversation history cleared');
        }
    };

    window.closeAIChatWindow = function() {
        if (aiChatState.currentWindow) {
            aiChatState.currentWindow.style.display = 'none';
        }
    };

    window.showAIChatHelp = function() {
        var help = 'AI Chat Assistant Help:\\n\\n' +
                  '1. Configure your Claude API key in Settings → API Configuration\\n' +
                  '2. Optionally customize the system prompt\\n' +
                  '3. Type messages and press Enter or click Send\\n' +
                  '4. Use Shift+Enter for new lines\\n' +
                  '5. Save conversations as JSON files\\n' +
                  '6. Export conversations as readable text\\n\\n' +
                  'Files are saved to documents/AI directory.';
        alert(help);
    };

    window.showAIChatAbout = function() {
        var about = 'AI Chat Assistant v1.0\\n\\n' +
                   'A Claude AI integration for QNX Desktop\\n' +
                   'Provides conversational AI capabilities\\n' +
                   'with conversation management features.\\n\\n' +
                   'Requires Claude API key from Anthropic.';
        alert(about);
    };

    window.loadAIChatSettings = function() {
        fetch('/api/aichat/settings')
        .then(function(response) {
            return response.json();
        })
        .then(function(data) {
            if (data.api_key) {
                aiChatState.apiKey = data.api_key;
            }
            if (data.system_prompt) {
                aiChatState.systemPrompt = data.system_prompt;
            }
            if (data.model) {
                aiChatState.model = data.model;
            }
            updateAIChatStatus();
        })
        .catch(function(error) {
            console.log('Could not load AI Chat settings:', error);
        });
    };

    window.saveAIChatSettings = function() {
        var settings = {
            api_key: aiChatState.apiKey,
            system_prompt: aiChatState.systemPrompt,
            model: aiChatState.model
        };
        
        fetch('/api/aichat/settings', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(settings)
        })
        .catch(function(error) {
            console.log('Could not save AI Chat settings:', error);
        });
    };

    function escapeHtml(text) {
        var div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    // Desktop Assistant functionality
    var assistantState = {
        isMinimized: false,
        apiKey: null,
        conversationHistory: []
    };

    // Load API key from AI Chat settings file
    function loadAssistantApiKey() {
        return new Promise(function(resolve) {
            fetch('/api/aichat/settings?full_key=true')
                .then(function(response) { return response.json(); })
                .then(function(data) {
                    console.log('Desktop Assistant - Loaded settings:', data);
                    // Simplified validation - just check if api_key exists and has content
                    var apiKey = data && data.api_key ? String(data.api_key).trim() : '';
                    if (apiKey && apiKey.length > 10 && !apiKey.includes('...')) {
                        assistantState.apiKey = apiKey;
                        assistantState.model = data.model || 'claude-3-haiku-20240307';
                        console.log('Desktop Assistant - API key loaded successfully, length:', apiKey.length);
                        resolve(true);
                    } else {
                        console.log('Desktop Assistant - No valid API key found. Key:', apiKey, 'Length:', apiKey.length);
                        assistantState.apiKey = null;
                        resolve(false);
                    }
                })
                .catch(function(error) {
                    console.log('Could not load AI Chat settings:', error);
                    assistantState.apiKey = null;
                    resolve(false);
                });
        });
    }





    // Start the application - ES5 compatible
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        // Use setTimeout to ensure DOM is ready
        setTimeout(init, 0);
    }

})(window, document);
