#!/usr/bin/env python3
"""
BerryCore ACP Agent - zero dependencies, pure Python 3.11 stdlib.
Implements ACP over JSON-RPC stdio. Streams from OpenAI/Anthropic/OpenRouter.
Runs on BB10/QNX. No pip required.

Env:
  OPENAI_API_KEY / ANTHROPIC_API_KEY / OPENROUTER_API_KEY
  OPENAI_MODEL / ANTHROPIC_MODEL / OPENROUTER_MODEL
  ACP_SYSTEM_PROMPT   override system prompt
  ACP_MAX_HISTORY     max messages per session (default 40)
  ACP_HISTORY_DIR     persist history to disk (default ~/.berrycore)
  ACP_ALLOW_EXEC      set 1 to enable shell command execution tool
  ACP_EXEC_TIMEOUT    max seconds per command (default 30)
  ACP_DEBUG           set 1 to log JSON-RPC traffic to stderr
"""
from __future__ import annotations
import asyncio
import json
import os
import re
import ssl
import subprocess
import sys
import threading
import time
import traceback
import urllib.error
import urllib.request
import uuid
from pathlib import Path
from typing import Any

VERSION = "1.0.0"
AGENT_NAME = "berrycore-agent"
AGENT_TITLE = "BerryCore ACP Agent"
PROTOCOL_VERSION = 1
DEBUG = os.environ.get("ACP_DEBUG", "0") == "1"
MAX_HISTORY = int(os.environ.get("ACP_MAX_HISTORY", "40"))
ALLOW_EXEC = os.environ.get("ACP_ALLOW_EXEC", "0") == "1"
EXEC_TIMEOUT = int(os.environ.get("ACP_EXEC_TIMEOUT", "30"))
HISTORY_DIR = Path(os.environ.get("ACP_HISTORY_DIR", os.path.expanduser("~/.berrycore")))

_EXEC_NOTE = (
    "\n\nYou can run shell commands using <exec>command</exec> syntax. "
    "Use it to check files, run builds, inspect the system."
) if ALLOW_EXEC else ""

DEFAULT_SYSTEM_PROMPT = os.environ.get(
    "ACP_SYSTEM_PROMPT",
    "You are BerryCore Agent, a helpful coding and systems assistant running on a "
    "BlackBerry 10 / QNX device. Be concise and precise. "
    "When writing code, use markdown code blocks with the language name. "
    "You have deep knowledge of QNX, POSIX, C, Python, and embedded systems."
    + _EXEC_NOTE,
)


def _log(*a: Any) -> None:
    print("[agent]", *a, file=sys.stderr, flush=True)


def _debug(*a: Any) -> None:
    if DEBUG:
        print("[debug]", *a, file=sys.stderr, flush=True)


# ---------------------------------------------------------------------------
# Transport
# ---------------------------------------------------------------------------

class Transport:
    def __init__(self) -> None:
        self._q: asyncio.Queue[bytes | None] = asyncio.Queue()
        self._lock = asyncio.Lock()
        self._loop: asyncio.AbstractEventLoop | None = None

    async def connect(self) -> None:
        self._loop = asyncio.get_running_loop()
        loop = self._loop

        def _reader() -> None:
            try:
                while True:
                    line = sys.stdin.buffer.readline()
                    if not line:
                        loop.call_soon_threadsafe(self._q.put_nowait, None)
                        break
                    loop.call_soon_threadsafe(self._q.put_nowait, line)
            except Exception:
                loop.call_soon_threadsafe(self._q.put_nowait, None)

        threading.Thread(target=_reader, daemon=True, name="stdin-reader").start()

    async def read_message(self) -> dict | None:
        line = await self._q.get()
        if line is None:
            return None
        try:
            text = line.decode("utf-8").strip()
            if not text:
                return None
            _debug("<<", text[:300])
            return json.loads(text)
        except (json.JSONDecodeError, UnicodeDecodeError) as e:
            _log("read error:", e)
            return None

    async def send(self, msg: dict) -> None:
        text = json.dumps(msg, ensure_ascii=False, separators=(",", ":"))
        _debug(">>", text[:300])
        async with self._lock:
            sys.stdout.buffer.write((text + "\n").encode("utf-8"))
            sys.stdout.buffer.flush()

    async def send_response(self, rid: Any, result: Any) -> None:
        await self.send({"jsonrpc": "2.0", "id": rid, "result": result})

    async def send_error(self, rid: Any, code: int, msg: str) -> None:
        await self.send({"jsonrpc": "2.0", "id": rid, "error": {"code": code, "message": msg}})

    async def send_notification(self, method: str, params: dict) -> None:
        await self.send({"jsonrpc": "2.0", "method": method, "params": params})


# ---------------------------------------------------------------------------
# ACP notification helpers
# ---------------------------------------------------------------------------

def _su(sid: str, update: dict) -> dict:
    return {"sessionId": sid, "update": update}


def _chunk(text: str) -> dict:
    return {"sessionUpdate": "agent_message_chunk", "content": {"type": "text", "text": text}}


def _thought(text: str) -> dict:
    return {"sessionUpdate": "agent_thought_chunk", "content": {"type": "text", "text": text}}


def _tool_start(tid: str, title: str, kind: str = "terminal") -> dict:
    return {
        "sessionUpdate": "tool_call",
        "toolCallId": tid,
        "title": title,
        "kind": kind,
        "status": "pending",
    }


def _tool_done(tid: str, status: str, text: str) -> dict:
    return {
        "sessionUpdate": "tool_call_update",
        "toolCallId": tid,
        "status": status,
        "content": [{"type": "content", "content": {"type": "text", "text": text}}],
    }


# ---------------------------------------------------------------------------
# Content extraction
# ---------------------------------------------------------------------------

_MIME_LANG: dict[str, str] = {
    "text/x-python": "python", "text/javascript": "javascript",
    "text/typescript": "typescript", "text/x-c": "c", "text/x-c++": "cpp",
    "text/x-rust": "rust", "text/x-go": "go", "text/x-java": "java",
    "application/json": "json", "text/html": "html", "text/css": "css",
    "text/x-sh": "bash", "text/markdown": "markdown",
}


def _extract(prompt: list) -> list[dict]:
    parts: list[dict] = []
    for b in prompt:
        if not isinstance(b, dict):
            continue
        t = b.get("type", "")
        if t == "text":
            s = b.get("text", "").strip()
            if s:
                parts.append({"type": "text", "text": s})
        elif t in ("resource", "resource_link"):
            r = b.get("resource", {})
            uri = r.get("uri", b.get("uri", ""))
            text = r.get("text", b.get("text", ""))
            mime = r.get("mimeType", b.get("mimeType", ""))
            if text:
                lang = _MIME_LANG.get(mime, "")
                parts.append({"type": "text", "text": f"\n```{lang}\n# {uri}\n{text}\n```"})
        elif t == "image":
            data = b.get("data", "")
            mime = b.get("mimeType", "image/png")
            if data:
                parts.append({
                    "type": "image_url",
                    "image_url": {"url": f"data:{mime};base64,{data}"},
                })
    return parts or [{"type": "text", "text": "(empty message)"}]


# ---------------------------------------------------------------------------
# TLS - BerryCore canonical path: berrycore/ssl/cert.pem
# ---------------------------------------------------------------------------

def _make_ssl() -> ssl.SSLContext:
    ctx = ssl.create_default_context()
    candidates = [
        "/accounts/1000/shared/misc/berrycore/ssl/cert.pem",
        "/etc/ssl/certs/ca-certificates.crt",
        "/etc/ssl/cert.pem",
        "/usr/local/share/certs/ca-root-nss.crt",
        os.path.join(os.path.dirname(os.path.abspath(__file__)), "ssl", "cert.pem"),
        os.path.join(os.path.dirname(os.path.abspath(__file__)), "cert.pem"),
        os.path.expanduser("~/certs/cert.pem"),
    ]
    for p in candidates:
        if os.path.exists(p):
            try:
                ctx.load_verify_locations(p)
                _log(f"TLS: {p}")
                return ctx
            except Exception:
                pass
    _log("WARNING: no CA bundle - TLS unverified")
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    return ctx


_SSL = _make_ssl()


# ---------------------------------------------------------------------------
# HTTP streaming
# ---------------------------------------------------------------------------

async def _http_stream(url: str, headers: dict, body: dict) -> asyncio.Queue:
    q: asyncio.Queue[str | None] = asyncio.Queue()
    loop = asyncio.get_running_loop()

    def _blk() -> None:
        data = json.dumps(body, ensure_ascii=False).encode()
        req = urllib.request.Request(url, data=data, headers=headers, method="POST")
        try:
            with urllib.request.urlopen(req, context=_SSL, timeout=120) as resp:
                for raw in resp:
                    loop.call_soon_threadsafe(q.put_nowait, raw.decode("utf-8").rstrip("\n\r"))
        except urllib.error.HTTPError as e:
            bt = e.read().decode("utf-8", errors="replace")[:500]
            loop.call_soon_threadsafe(q.put_nowait, f"__ERROR__:HTTP {e.code}: {bt}")
        except Exception as e:
            loop.call_soon_threadsafe(q.put_nowait, f"__ERROR__:{e}")
        finally:
            loop.call_soon_threadsafe(q.put_nowait, None)

    loop.run_in_executor(None, _blk)
    return q


# ---------------------------------------------------------------------------
# Shell exec tool
# ---------------------------------------------------------------------------

_EXEC_RE = re.compile(r"<exec>(.*?)</exec>", re.DOTALL)


async def _run_cmd(cmd: str, cwd: str) -> tuple[str, int]:
    loop = asyncio.get_running_loop()

    def _blk() -> tuple[str, int]:
        try:
            r = subprocess.run(
                cmd, shell=True,
                cwd=cwd if os.path.isdir(cwd) else "/",
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                timeout=EXEC_TIMEOUT, env=os.environ.copy(),
            )
            return r.stdout.decode("utf-8", errors="replace"), r.returncode
        except subprocess.TimeoutExpired:
            return f"[timeout after {EXEC_TIMEOUT}s]", 124
        except Exception as e:
            return f"[exec error: {e}]", 1

    return await loop.run_in_executor(None, _blk)


async def _process_exec_tags(text: str, session: "Session", transport: Transport) -> str:
    if not ALLOW_EXEC:
        return text
    matches = list(_EXEC_RE.finditer(text))
    if not matches:
        return text
    extra: list[str] = []
    for m in matches:
        cmd = m.group(1).strip()
        tid = f"exec_{uuid.uuid4().hex[:8]}"
        await transport.send_notification(
            "session/update", _su(session.session_id, _tool_start(tid, f"$ {cmd[:60]}")))
        out, code = await _run_cmd(cmd, session.cwd)
        out = out.strip() or "(no output)"
        if len(out) > 4000:
            out = out[:4000] + "\n...[truncated]"
        status = "success" if code == 0 else "error"
        await transport.send_notification(
            "session/update", _su(session.session_id, _tool_done(tid, status, out)))
        extra.append(f"\n**`$ {cmd}`** (exit {code}):\n```\n{out}\n```")
    return text + "\n" + "\n".join(extra)


# ---------------------------------------------------------------------------
# Providers
# ---------------------------------------------------------------------------

class Provider:
    name = "base"

    async def stream(
        self,
        messages: list[dict],
        on_chunk: Any,
        on_thought: Any = None,
    ) -> tuple[str, dict]:
        raise NotImplementedError


class OpenAIProvider(Provider):
    name = "openai"

    def __init__(self, key: str, model: str, base: str = "https://api.openai.com") -> None:
        self.key = key
        self.model = model
        self.base = base.rstrip("/")

    async def stream(self, messages, on_chunk, on_thought=None):
        q = await _http_stream(
            f"{self.base}/v1/chat/completions",
            {"Content-Type": "application/json", "Authorization": f"Bearer {self.key}"},
            {"model": self.model, "messages": messages, "stream": True,
             "stream_options": {"include_usage": True}},
        )
        full: list[str] = []
        usage: dict = {}
        while True:
            line = await q.get()
            if line is None:
                break
            if line.startswith("__ERROR__:"):
                raise RuntimeError(line[10:])
            if not line.startswith("data:"):
                continue
            payload = line[5:].strip()
            if payload == "[DONE]":
                break
            try:
                chunk = json.loads(payload)
            except json.JSONDecodeError:
                continue
            if chunk.get("usage"):
                u = chunk["usage"]
                usage = {
                    "input_tokens": u.get("prompt_tokens", 0),
                    "output_tokens": u.get("completion_tokens", 0),
                }
            choices = chunk.get("choices", [])
            if not choices:
                continue
            delta = choices[0].get("delta", {})
            r = delta.get("reasoning_content") or delta.get("reasoning")
            if r and on_thought:
                await on_thought(r)
            c = delta.get("content")
            if c:
                full.append(c)
                await on_chunk(c)
        return "".join(full), usage


class AnthropicProvider(Provider):
    name = "anthropic"

    def __init__(self, key: str, model: str) -> None:
        self.key = key
        self.model = model

    async def stream(self, messages, on_chunk, on_thought=None):
        system = DEFAULT_SYSTEM_PROMPT
        user_msgs = []
        for m in messages:
            if m["role"] == "system":
                c = m.get("content", "")
                system = c if isinstance(c, str) else " ".join(
                    p.get("text", "") for p in c if isinstance(p, dict)
                )
            else:
                user_msgs.append(m)
        q = await _http_stream(
            "https://api.anthropic.com/v1/messages",
            {"Content-Type": "application/json", "x-api-key": self.key,
             "anthropic-version": "2023-06-01"},
            {"model": self.model, "max_tokens": 8096, "system": system,
             "messages": user_msgs, "stream": True},
        )
        full: list[str] = []
        usage: dict = {}
        while True:
            line = await q.get()
            if line is None:
                break
            if line.startswith("__ERROR__:"):
                raise RuntimeError(line[10:])
            if not line.startswith("data:"):
                continue
            try:
                ev = json.loads(line[5:].strip())
            except json.JSONDecodeError:
                continue
            et = ev.get("type", "")
            if et == "content_block_delta":
                d = ev.get("delta", {})
                dt = d.get("type", "")
                if dt == "text_delta":
                    t = d.get("text", "")
                    if t:
                        full.append(t)
                        await on_chunk(t)
                elif dt == "thinking_delta" and on_thought:
                    th = d.get("thinking", "")
                    if th:
                        await on_thought(th)
            elif et == "message_delta":
                u = ev.get("usage", {})
                if u:
                    usage = {
                        "input_tokens": u.get("input_tokens", 0),
                        "output_tokens": u.get("output_tokens", 0),
                    }
        return "".join(full), usage


class _NoKeyProvider(Provider):
    name = "none"

    async def stream(self, messages, on_chunk, on_thought=None):
        msg = (
            "No API key configured.\nSet one of:\n"
            "  export OPENAI_API_KEY=sk-...\n"
            "  export ANTHROPIC_API_KEY=sk-ant-...\n"
            "  export OPENROUTER_API_KEY=sk-or-..."
        )
        await on_chunk(msg)
        return msg, {}


def _build_provider() -> Provider:
    ak = os.environ.get("ANTHROPIC_API_KEY", "")
    ok = os.environ.get("OPENROUTER_API_KEY", "")
    ek = os.environ.get("OPENAI_API_KEY", "")
    if ak:
        m = os.environ.get("ANTHROPIC_MODEL", "claude-3-5-haiku-20241022")
        _log(f"provider: Anthropic / {m}")
        return AnthropicProvider(ak, m)
    if ok:
        m = os.environ.get("OPENROUTER_MODEL", "openai/gpt-4o-mini")
        _log(f"provider: OpenRouter / {m}")
        return OpenAIProvider(ok, m, "https://openrouter.ai/api")
    if ek:
        m = os.environ.get("OPENAI_MODEL", "gpt-4o-mini")
        _log(f"provider: OpenAI / {m}")
        return OpenAIProvider(ek, m)
    _log("WARNING: no API key")
    return _NoKeyProvider()


# ---------------------------------------------------------------------------
# Session
# ---------------------------------------------------------------------------

class Session:
    def __init__(self, sid: str, cwd: str, provider: Provider) -> None:
        self.session_id = sid
        self.cwd = cwd
        self.provider = provider
        self.history: list[dict] = []
        self.cancelled = False
        self.total_input = 0
        self.total_output = 0
        self.created_at = time.time()
        self._hfile: Path | None = None

    def set_history_file(self, p: Path) -> None:
        self._hfile = p
        if p.exists():
            try:
                d = json.loads(p.read_text("utf-8"))
                self.history = d.get("history", [])
                self.total_input = d.get("total_input", 0)
                self.total_output = d.get("total_output", 0)
                _log(f"loaded history {p} ({len(self.history)} msgs)")
            except Exception as e:
                _log(f"history load error: {e}")

    def save(self) -> None:
        if not self._hfile:
            return
        try:
            self._hfile.parent.mkdir(parents=True, exist_ok=True)
            self._hfile.write_text(json.dumps({
                "session_id": self.session_id,
                "cwd": self.cwd,
                "created_at": self.created_at,
                "total_input": self.total_input,
                "total_output": self.total_output,
                "history": self.history,
            }, indent=2, ensure_ascii=False), "utf-8")
        except Exception as e:
            _log(f"history save error: {e}")

    def add_user(self, content: list[dict]) -> None:
        if self.history and self.history[-1]["role"] == "user":
            ex = self.history[-1]["content"]
            if isinstance(ex, list):
                ex.extend(content)
            else:
                self.history[-1]["content"] = [{"type": "text", "text": ex}] + content
        else:
            self.history.append({"role": "user", "content": content})
        self._trim()

    def add_assistant(self, text: str) -> None:
        self.history.append({"role": "assistant", "content": text})
        self._trim()
        self.save()

    def _trim(self) -> None:
        while len(self.history) > MAX_HISTORY:
            self.history.pop(0)

    def build_messages(self) -> list[dict]:
        return [{"role": "system", "content": DEFAULT_SYSTEM_PROMPT}] + self.history


# ---------------------------------------------------------------------------
# ACP error
# ---------------------------------------------------------------------------

class _AcpError(Exception):
    def __init__(self, code: int, message: str) -> None:
        super().__init__(message)
        self.code = code
        self.message = message


# ---------------------------------------------------------------------------
# Agent
# ---------------------------------------------------------------------------

class BerrycoreAgent:
    def __init__(self) -> None:
        self._t = Transport()
        self._sessions: dict[str, Session] = {}
        self._provider: Provider | None = None

    async def run(self) -> None:
        await self._t.connect()
        _log(f"{AGENT_TITLE} v{VERSION} ready (exec={'on' if ALLOW_EXEC else 'off'})")
        while True:
            msg = await self._t.read_message()
            if msg is None:
                _log("stdin closed")
                break
            asyncio.create_task(self._dispatch(msg))

    async def _dispatch(self, msg: dict) -> None:
        method = msg.get("method", "")
        rid = msg.get("id")
        params = msg.get("params") or {}
        if "result" in msg or ("error" in msg and "method" not in msg):
            return
        try:
            result = await self._handle(method, params)
            if rid is not None:
                await self._t.send_response(rid, result)
        except _AcpError as e:
            if rid is not None:
                await self._t.send_error(rid, e.code, e.message)
        except Exception as e:
            _log(f"error in {method}:", traceback.format_exc())
            if rid is not None:
                await self._t.send_error(rid, -32603, str(e))

    async def _handle(self, method: str, params: dict) -> Any:
        handlers: dict[str, Any] = {
            "initialize": self._init,
            "session/new": self._new,
            "session/prompt": self._prompt,
            "session/cancel": self._cancel,
            "session/list": self._list,
            "session/load": self._load,
            "session/setMode": self._noop,
            "session/setModel": self._set_model,
            "session/setConfigOption": self._noop,
            "authenticate": self._noop,
        }
        fn = handlers.get(method)
        if fn is None:
            raise _AcpError(-32601, f"Method not found: {method}")
        return await fn(params)

    async def _init(self, p: dict) -> dict:
        info = p.get("clientInfo", {})
        _log(f"initialize from {info.get('name','?')} v{info.get('version','?')}")
        if self._provider is None:
            self._provider = _build_provider()
        return {
            "protocolVersion": min(p.get("protocolVersion", 1), PROTOCOL_VERSION),
            "agentInfo": {"name": AGENT_NAME, "title": AGENT_TITLE, "version": VERSION},
            "agentCapabilities": {
                "loadSession": False,
                "promptCapabilities": {"image": True, "audio": False, "embeddedContext": True},
                "mcpCapabilities": {"http": False, "sse": False},
                "sessionCapabilities": {},
            },
            "authMethods": [],
        }

    async def _new(self, p: dict) -> dict:
        assert self._provider is not None
        sid = f"sess_{uuid.uuid4().hex[:12]}"
        cwd = p.get("cwd", "/")
        s = Session(sid, cwd, self._provider)
        s.set_history_file(HISTORY_DIR / f"{sid}.json")
        self._sessions[sid] = s
        _log(f"new session {sid} cwd={cwd}")
        return {"sessionId": sid}

    async def _load(self, p: dict) -> None:
        raise _AcpError(-32601, "session/load not supported")

    async def _list(self, p: dict) -> dict:
        return {"sessions": [], "nextCursor": None}

    async def _cancel(self, p: dict) -> None:
        s = self._sessions.get(p.get("sessionId", ""))
        if s:
            s.cancelled = True
            _log(f"cancel {s.session_id}")

    async def _set_model(self, p: dict) -> None:
        s = self._sessions.get(p.get("sessionId", ""))
        mid = p.get("modelId", "")
        if s and mid:
            old = s.provider
            if isinstance(old, OpenAIProvider):
                s.provider = OpenAIProvider(old.key, mid, old.base)
            elif isinstance(old, AnthropicProvider):
                s.provider = AnthropicProvider(old.key, mid)
            _log(f"session {s.session_id} model -> {mid}")

    async def _noop(self, p: dict) -> None:
        return None

    async def _prompt(self, p: dict) -> dict:
        sid = p.get("sessionId", "")
        s = self._sessions.get(sid)
        if s is None:
            raise _AcpError(-32602, f"Unknown session: {sid}")

        s.cancelled = False
        s.add_user(_extract(p.get("prompt", [])))
        messages = s.build_messages()
        full: list[str] = []

        async def on_chunk(text: str) -> None:
            if s.cancelled:
                return
            full.append(text)
            await self._t.send_notification("session/update", _su(sid, _chunk(text)))

        async def on_thought(text: str) -> None:
            if s.cancelled:
                return
            await self._t.send_notification("session/update", _su(sid, _thought(text)))

        try:
            _, usage = await s.provider.stream(messages, on_chunk, on_thought)
        except Exception as e:
            err = f"\n\n**Error:** {e}"
            await self._t.send_notification("session/update", _su(sid, _chunk(err)))
            _log("provider error:", traceback.format_exc())
            full.append(err)
            usage = {}

        if s.cancelled:
            _log(f"prompt {sid} cancelled")
            return {"stopReason": "cancelled"}

        response = "".join(full)

        if ALLOW_EXEC and "<exec>" in response:
            response = await _process_exec_tags(response, s, self._t)
            extra = response[len("".join(full)):]
            if extra:
                await self._t.send_notification("session/update", _su(sid, _chunk(extra)))

        if response:
            s.add_assistant(response)

        s.total_input += usage.get("input_tokens", 0)
        s.total_output += usage.get("output_tokens", 0)
        _log(
            f"prompt {sid} done "
            f"in={usage.get('input_tokens',0)} out={usage.get('output_tokens',0)} "
            f"total={s.total_input}in/{s.total_output}out"
        )

        result: dict = {"stopReason": "end_turn"}
        if usage:
            result["usage"] = {
                "inputTokens": usage.get("input_tokens", 0),
                "outputTokens": usage.get("output_tokens", 0),
                "totalTokens": usage.get("input_tokens", 0) + usage.get("output_tokens", 0),
            }
        return result


def main() -> None:
    try:
        asyncio.run(BerrycoreAgent().run())
    except KeyboardInterrupt:
        _log("interrupted")


if __name__ == "__main__":
    main()
