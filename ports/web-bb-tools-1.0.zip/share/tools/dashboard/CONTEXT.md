# BerryCore Dashboard – Context

Tech dashboard with live device data. Same style as other tools.

## Path

`tools/dashboard/index.html`

## Layout

1. **ASCII header** – "BerryCore" in block chars (#4a7)
2. **Subtitle** – "QNX Extended Userland"
3. **Data grid** – Battery, IP, Geo, Accel X/Y/Z, Alpha/Beta/Gamma
4. **Apps** – Buttons to Drawing Board, Markdown, Code Editor, Keyboard, Messenger

## Data APIs

| Card | Source | Fallback |
|------|--------|----------|
| Battery | navigator.getBattery() | "N/A" |
| Local IP | WebRTC ICE | "—" |
| Location | navigator.geolocation | "Denied"/"Error" |
| Accel | DeviceMotionEvent | "N/A" |
| Gyro | DeviceOrientationEvent | "N/A" |

## ES5

- var, function, no arrows
- Same colors as tools: #1e1e1e, #252525, #4a7, #5b8
