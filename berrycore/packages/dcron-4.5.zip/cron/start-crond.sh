#!/bin/sh
# Start dcron if not already running (BerryCore / BB10 paths)
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
CROND="${ROOT}/sbin/crond"
LOG="${ROOT}/cron/crond.log"
PIDFILE="${ROOT}/cron/crond.pid"
CTABS="${ROOT}/cron/crontabs"
STAMPS="${ROOT}/cron/cronstamps"
SDIR="${ROOT}/cron/cron.d"
mkdir -p "$CTABS" "$STAMPS" "$SDIR" 2>/dev/null
if [ -f "$PIDFILE" ] && kill -0 "$(cat "$PIDFILE")" 2>/dev/null; then
  echo "crond already running (pid $(cat "$PIDFILE"))"
  exit 0
fi
rm -f "$PIDFILE"
nohup "$CROND" -f -L "$LOG" -c "$CTABS" -t "$STAMPS" -s "$SDIR" >>"$LOG" 2>&1 &
echo $! >"$PIDFILE"
echo "crond started pid $(cat "$PIDFILE") (log: $LOG)"
