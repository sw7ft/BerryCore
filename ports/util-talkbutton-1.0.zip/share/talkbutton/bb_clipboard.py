"""BB10 system clipboard via libclipboard (text/plain)."""
from ctypes import CDLL, POINTER, c_char, c_char_p, c_int, c_uint, c_void_p
import os
import threading

LIB_PATH = '/lib/libclipboard.so.1'
TYPE_PLAIN = b'text/plain'

_lock = threading.Lock()
_lib = None
_err = ''


def _load():
    global _lib, _err
    if _lib is not None:
        return _lib
    if not os.path.isfile(LIB_PATH):
        _err = 'libclipboard.so.1 missing'
        return None
    lib = CDLL(LIB_PATH)
    lib.empty_clipboard.restype = c_int
    lib.set_clipboard_data.argtypes = [c_char_p, c_uint, c_void_p]
    lib.set_clipboard_data.restype = c_int
    lib.get_clipboard_data.argtypes = [c_char_p, POINTER(c_char_p)]
    lib.get_clipboard_data.restype = c_uint
    lib.is_clipboard_format_present.argtypes = [c_char_p]
    lib.is_clipboard_format_present.restype = c_int
    _lib = lib
    _err = ''
    return _lib


def copy_text(text):
    """Copy unicode/str to the system clipboard as text/plain."""
    if text is None:
        return False, 'empty'
    if not isinstance(text, str):
        try:
            text = text.decode('utf-8')
        except Exception:
            text = str(text)
    raw = text.encode('utf-8')
    if not raw:
        return False, 'empty'
    with _lock:
        lib = _load()
        if lib is None:
            return False, _err or 'no libclipboard'
        try:
            lib.empty_clipboard()
            buf = (c_char * len(raw)).from_buffer_copy(raw)
            n = lib.set_clipboard_data(TYPE_PLAIN, len(raw), buf)
            if n < 0:
                return False, 'set_clipboard_data failed'
            return True, ''
        except Exception as e:
            return False, str(e)


def last_error():
    return _err
