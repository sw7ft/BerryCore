"""Warm in-process Vosk decoder (libvosk ctypes). Reloading the model is ~12s."""
import ctypes
import json
import os
import threading
import time

STT_LEGACY = '/accounts/1000/shared/misc/stt'


def _native_root(base_dir):
    return os.path.abspath(os.path.join(base_dir, '..', '..'))


def vosk_lib_path(base_dir):
    native = _native_root(base_dir)
    for p in (
        os.path.join(native, 'lib', 'libvosk.so'),
        os.path.join(STT_LEGACY, 'lib', 'libvosk.so'),
        os.path.join(native, 'share', 'stt', 'lib', 'libvosk.so'),
    ):
        if os.path.isfile(p):
            return p
    return os.path.join(STT_LEGACY, 'lib', 'libvosk.so')


def vosk_model_path(base_dir):
    native = _native_root(base_dir)
    for p in (
        os.path.join(native, 'share', 'stt', 'model', 'vosk-en'),
        os.path.join(STT_LEGACY, 'model', 'vosk-en'),
    ):
        if os.path.isdir(p):
            return p
    return os.path.join(STT_LEGACY, 'model', 'vosk-en')


def goforward_wav():
    for p in (
        os.path.join(STT_LEGACY, 'tmp', 'goforward16.wav'),
        os.path.join(STT_LEGACY, 'share', 'goforward.wav'),
    ):
        if os.path.isfile(p):
            return p
    return ''


def parse_vosk_text(raw):
    if not raw:
        return ''
    if isinstance(raw, bytes):
        s = raw.decode('utf-8', 'replace')
    else:
        s = str(raw)
    try:
        obj = json.loads(s)
        return (obj.get('text') or '').strip()
    except Exception:
        pass
    i = s.find('"text"')
    if i < 0:
        return s.strip()
    i = s.find('"', i + 6)
    if i < 0:
        return s.strip()
    j = s.find('"', i + 1)
    if j < 0:
        return s.strip()
    return s[i + 1:j]


def read_wav_pcm(path):
    try:
        data = open(path, 'rb').read()
    except IOError:
        return None, 0
    if len(data) < 44 or data[:4] != b'RIFF':
        return None, 0
    rate = data[24] | (data[25] << 8) | (data[26] << 16) | (data[27] << 24)
    return data[44:], rate


class VoskEngine(object):
    def __init__(self, base_dir):
        self.base_dir = base_dir
        self.lib = None
        self.model = None
        self.rec = None
        self.rate = 16000
        self.lock = threading.Lock()
        self._load_lock = threading.Lock()
        self.err = ''
        self.ready = False
        self.load_ms = 0

    def load(self):
        with self._load_lock:
            return self._load()

    def _load(self):
        if self.ready:
            return True
        libpath = vosk_lib_path(self.base_dir)
        model_dir = vosk_model_path(self.base_dir)
        if not os.path.isfile(libpath):
            self.err = 'libvosk.so missing — qpkg install vosk'
            return False
        if not os.path.isdir(model_dir):
            self.err = 'vosk-en model missing — qpkg install vosk'
            return False
        extra = os.path.dirname(libpath)
        env = os.environ
        env['LD_LIBRARY_PATH'] = extra + ':' + env.get('LD_LIBRARY_PATH', '')
        try:
            lib = ctypes.CDLL(libpath)
            lib.vosk_set_log_level.argtypes = [ctypes.c_int]
            lib.vosk_model_new.argtypes = [ctypes.c_char_p]
            lib.vosk_model_new.restype = ctypes.c_void_p
            lib.vosk_model_free.argtypes = [ctypes.c_void_p]
            lib.vosk_recognizer_new.argtypes = [ctypes.c_void_p, ctypes.c_float]
            lib.vosk_recognizer_new.restype = ctypes.c_void_p
            lib.vosk_recognizer_accept_waveform.argtypes = [
                ctypes.c_void_p, ctypes.c_void_p, ctypes.c_int]
            lib.vosk_recognizer_accept_waveform.restype = ctypes.c_int
            lib.vosk_recognizer_final_result.argtypes = [ctypes.c_void_p]
            lib.vosk_recognizer_final_result.restype = ctypes.c_char_p
            lib.vosk_recognizer_reset.argtypes = [ctypes.c_void_p]
            lib.vosk_recognizer_free.argtypes = [ctypes.c_void_p]
            lib.vosk_set_log_level(-1)
            t0 = time.time()
            model = lib.vosk_model_new(model_dir.encode('utf-8'))
            if not model:
                self.err = 'vosk_model_new failed'
                return False
            rec = lib.vosk_recognizer_new(model, float(self.rate))
            if not rec:
                lib.vosk_model_free(model)
                self.err = 'vosk_recognizer_new failed'
                return False
            self.lib = lib
            self.model = model
            self.rec = rec
            self.ready = True
            self.load_ms = int((time.time() - t0) * 1000)
            self.err = ''
            return True
        except Exception as e:
            self.err = str(e)
            return False

    def decode_pcm(self, pcm, rate=16000):
        t0 = time.time()
        if not self.load():
            return {'ok': False, 'text': '', 'err': self.err, 'ms': 0}
        if not pcm:
            return {'ok': False, 'text': '', 'err': 'empty audio', 'ms': 0}
        with self.lock:
            try:
                arr = (ctypes.c_char * len(pcm)).from_buffer_copy(pcm)
                self.lib.vosk_recognizer_reset(self.rec)
                self.lib.vosk_recognizer_accept_waveform(self.rec, arr, len(pcm))
                raw = self.lib.vosk_recognizer_final_result(self.rec)
                text = parse_vosk_text(raw)
                return {
                    'ok': True,
                    'text': text,
                    'err': '',
                    'ms': int((time.time() - t0) * 1000),
                    'rate': rate,
                    'bytes': len(pcm),
                }
            except Exception as e:
                return {
                    'ok': False,
                    'text': '',
                    'err': str(e),
                    'ms': int((time.time() - t0) * 1000),
                }

    def decode_wav(self, path):
        pcm, rate = read_wav_pcm(path)
        if pcm is None:
            return {'ok': False, 'text': '', 'err': 'bad wav', 'ms': 0}
        return self.decode_pcm(pcm, rate or 16000)
