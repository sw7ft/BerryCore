"""Watch BB10 hardware buttons via /pps/system/buttons/status."""
import os
import threading
import time

PPS_PATH = '/pps/system/buttons/status'
WATCH_KEYS = ('bid_playpause',)


def parse_status(text):
    keys = {}
    if not text:
        return keys
    if isinstance(text, bytes):
        try:
            text = text.decode('utf-8', 'replace')
        except Exception:
            text = str(text)
    for line in text.splitlines():
        if '::' not in line:
            continue
        name, val = line.split('::', 1)
        keys[name.strip()] = val.strip()
    return keys


def read_buttons():
    try:
        with open(PPS_PATH, 'r') as f:
            return parse_status(f.read())
    except Exception:
        return {}


def is_down(keys, name):
    return keys.get(name) == 'b_down'


class ButtonWatch(object):
    def __init__(self, on_press, interval=0.05):
        self.on_press = on_press
        self.interval = interval
        self._stop = threading.Event()
        self._thread = None
        self.last = {}
        self.ok = os.path.isfile(PPS_PATH)
        self.err = '' if self.ok else 'no /pps/system/buttons/status'

    def start(self):
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        th = threading.Thread(target=self._loop)
        try:
            th.daemon = True
        except Exception:
            pass
        self._thread = th
        th.start()

    def stop(self):
        self._stop.set()

    def _loop(self):
        prev = read_buttons()
        self.last = prev
        if not prev and not os.path.isfile(PPS_PATH):
            self.ok = False
            self.err = 'buttons pps missing'
            return
        self.ok = True
        self.err = ''
        while not self._stop.is_set():
            cur = read_buttons()
            if cur:
                self.last = cur
                for name in WATCH_KEYS:
                    if is_down(cur, name) and not is_down(prev, name):
                        try:
                            self.on_press(name)
                        except Exception as e:
                            self.err = str(e)
                prev = cur
            time.sleep(self.interval)
