# Drawing Board – BB10 Whiteboard

A minimal Pencil-style drawing tool for BB10 browser. ES5-only, no build step.

## Features

- **White board** – Clean canvas for diagrams
- **Rectangles** – Drag to draw boxes
- **Text inside** – Click a rectangle in Text mode to add/edit text
- **Select & delete** – Select mode: click to select, Delete/Backspace to remove

## Usage

1. Open `index.html` in the BB10 browser (file:// or via HTTP).
2. **Rectangle** – Drag on the canvas to create a box.
3. **Text** – Switch to Text mode, click a rectangle, type in the popup, OK.
4. **Select** – Click a shape to select (highlighted), press Delete to remove.
5. **Clear** – Wipes the board.

## BB10 / ES5

- Pure ES5 (no arrow functions, `let`/`const`, template literals).
- Touch and mouse events supported.
- Works with BB10 WebKit browser.

## Serving locally

```bash
# From BerryCore root, with Python:
python -m SimpleHTTPServer 8080
# Open http://localhost:8080/tools/drawing-board/

# Or with PHP:
php -S localhost:8080
```

Or open `index.html` directly (file://) if your browser allows.
