# shellcheck shell=sh
# Start berrybridge-run-job --watch if not already running (idempotent)

bb_watcher_running() {
	if [ -f "${BRIDGE_ROOT}/agent.pid" ]; then
		_pid=$(cat "${BRIDGE_ROOT}/agent.pid" 2>/dev/null)
		if [ -n "$_pid" ] && kill -0 "$_pid" 2>/dev/null; then
			return 0
		fi
	fi
	if ps -ef 2>/dev/null | grep -v grep | grep -q 'berrybridge-run-job --watch'; then
		return 0
	fi
	return 1
}

bb_start_watcher() {
	_agent_home="$(bb_agent_home)"
	_runner="${_agent_home}/bin/berrybridge-run-job"
	if [ ! -x "$_runner" ]; then
		bb_log "ERROR: cannot start watcher — missing $_runner"
		return 1
	fi
	if bb_watcher_running; then
		bb_log "watcher already running"
		return 0
	fi
	bb_ensure_dirs || return 1
	nohup "$_runner" --watch >>"$AGENT_LOG" 2>&1 &
	_pid=$!
	printf '%s\n' "$_pid" >"${BRIDGE_ROOT}/agent.pid" 2>/dev/null || true
	bb_log "watcher started pid=${_pid}"
	return 0
}

bb_install_cron_fallback() {
	# Optional: poll inbox every minute if watcher dies (needs BerryCore dcron)
	_agent_home="$(bb_agent_home)"
	_runner="${_agent_home}/bin/berrybridge-run-job"
	_ensure="${_agent_home}/bin/berrybridge-ensure-sshd"
	_cron_dir="${_agent_home}/etc/berrybridge/cron"
	_crontab="${_cron_dir}/berrybridge.crontab"
	mkdir -p "$_cron_dir" 2>/dev/null || true
	cat >"$_crontab" <<EOF
# Berry Bridge agent — inbox poll + sshd after reboot (BerryCore dcron)
# Install: export CRON_USER=berrycore; crontab $_crontab
SHELL=/bin/sh
PATH=${BERRYCORE_PATH}/bin:${BERRYCORE_PATH}/sbin:/bin
* * * * * $_runner --once >> $AGENT_LOG 2>&1
@reboot $_ensure >> $AGENT_LOG 2>&1
EOF
	bb_log "cron template written: $_crontab"
}
