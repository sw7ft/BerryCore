/**
 * Virtual Keyboard - ES5 compatible, reusable
 * Include: <script src="keyboard.js"></script>
 * Auto-inits. Or: VirtualKeyboard.init({ triggerPosition: 'bottom-right' });
 */
(function(global) {
  "use strict";

  var LAYOUT = {
    default: [
      ["`","1","2","3","4","5","6","7","8","9","0","-","=","{bksp}"],
      ["{tab}","q","w","e","r","t","y","u","i","o","p","[","]","\\"],
      ["{caps}","a","s","d","f","g","h","j","k","l",";","'","{enter}"],
      ["{shift}","z","x","c","v","b","n","m",",",".","/","{shift}"],
      ["{space}"]
    ],
    shift: [
      ["~","!","@","#","$","%","^","&","*","(",")","_","+","{bksp}"],
      ["{tab}","Q","W","E","R","T","Y","U","I","O","P","{","}","|"],
      ["{caps}","A","S","D","F","G","H","J","K","L",":","\"","{enter}"],
      ["{shift}","Z","X","C","V","B","N","M","<",">","?","{shift}"],
      ["{space}"]
    ]
  };

  var SPECIAL = {
    "{bksp}": "\b",
    "{tab}": "\t",
    "{enter}": "\n",
    "{space}": " ",
    "{caps}": "caps",
    "{shift}": "shift"
  };

  var container = null;
  var keyboardEl = null;
  var triggerBtn = null;
  var shiftOn = false;
  var capsOn = false;
  var lastFocused = null;

  function getTarget() {
    var el = document.activeElement;
    var isInput = el && (el.tagName === "TEXTAREA" || el.tagName === "INPUT" || el.isContentEditable);
    if (isInput) return el;
    return lastFocused;
  }

  function insertText(str) {
    var el = getTarget();
    if (!el) return;
    var isInput = el.tagName === "TEXTAREA" || el.tagName === "INPUT";
    if (!isInput && !el.isContentEditable) return;
    if (el.tagName === "TEXTAREA" || el.tagName === "INPUT") {
      var start = el.selectionStart;
      var end = el.selectionEnd;
      var val = el.value;
      if (str === "\b") {
        if (start === end && start > 0) {
          el.value = val.slice(0, start - 1) + val.slice(end);
          el.setSelectionRange(start - 1, start - 1);
        } else {
          el.value = val.slice(0, start) + val.slice(end);
          el.setSelectionRange(start, start);
        }
      } else {
        el.value = val.slice(0, start) + str + val.slice(end);
        el.setSelectionRange(start + str.length, start + str.length);
      }
      try {
        var ev = document.createEvent("HTMLEvents");
        ev.initEvent("input", true, false);
        el.dispatchEvent(ev);
      } catch (e) {}
      el.focus();
    } else if (el.isContentEditable) {
      if (str === "\b") {
        try {
          var ev = document.createEvent("KeyboardEvent");
          if (ev.initKeyboardEvent) {
            ev.initKeyboardEvent("keydown", true, true, window, "Backspace", 0, false, false, false, false);
            el.dispatchEvent(ev);
          } else if (typeof KeyboardEvent !== "undefined") {
            el.dispatchEvent(new KeyboardEvent("keydown", { key: "Backspace", keyCode: 8 }));
          }
        } catch (e) {}
      } else {
        document.execCommand("insertText", false, str);
      }
      el.focus();
    }
  }

  function onKeyClick(key) {
    var k = key.toLowerCase();
    if (k === "{shift}") {
      shiftOn = !shiftOn;
      renderKeys();
      return;
    }
    if (k === "{caps}") {
      capsOn = !capsOn;
      renderKeys();
      return;
    }
    var special = SPECIAL[key];
    if (special === "shift" || special === "caps") return;
    var char = special !== undefined ? special : key;
    if (char === "\b" || char === "\t" || char === "\n" || char === " ") {
      insertText(char);
      if (key === key.toUpperCase() && key !== key.toLowerCase()) shiftOn = false;
      renderKeys();
      return;
    }
    insertText(char);
    if (shiftOn && key.length === 1) shiftOn = false;
    renderKeys();
  }

  function renderKeys() {
    if (!keyboardEl) return;
    var useShift = (shiftOn && !capsOn) || (capsOn && !shiftOn);
    var layout = useShift ? LAYOUT.shift : LAYOUT.default;
    keyboardEl.innerHTML = "";
    for (var r = 0; r < layout.length; r++) {
      var row = document.createElement("div");
      row.className = "vk-row";
      for (var c = 0; c < layout[r].length; c++) {
        var key = layout[r][c];
        var btn = document.createElement("button");
        btn.type = "button";
        btn.className = "vk-key";
        if (key === "{space}") btn.className += " vk-space";
        else if (key === "{bksp}" || key === "{tab}" || key === "{enter}" || key === "{shift}" || key === "{caps}") btn.className += " vk-special";
        btn.textContent = key === "{bksp}" ? "⌫" : key === "{tab}" ? "Tab" : key === "{enter}" ? "↵" : key === "{space}" ? "" : key === "{shift}" ? "⇧" : key === "{caps}" ? "Caps" : key;
        btn.setAttribute("data-key", key);
        btn.tabIndex = -1;
        (function(k) {
          btn.onclick = function() { onKeyClick(k); };
          btn.onmousedown = function(e) { e.preventDefault(); };
        })(key);
        row.appendChild(btn);
      }
      keyboardEl.appendChild(row);
    }
  }

  function createKeyboard() {
    container = document.createElement("div");
    container.id = "virtual-keyboard-root";
    container.innerHTML = "<div class=\"vk-panel\"><div class=\"vk-header\"><button type=\"button\" class=\"vk-close\" title=\"Close\">✕</button></div><div class=\"vk-keys\"></div></div>";
    keyboardEl = container.querySelector(".vk-keys");
    container.querySelector(".vk-close").onclick = function() {
      container.classList.remove("vk-open");
    };
    container.querySelector(".vk-close").onmousedown = function(e) {
      e.preventDefault();
    };
    document.body.appendChild(container);
    renderKeys();
  }

  function createTrigger() {
    triggerBtn = document.createElement("button");
    triggerBtn.type = "button";
    triggerBtn.className = "vk-trigger";
    triggerBtn.title = "Virtual keyboard";
    triggerBtn.textContent = "⌨";
    triggerBtn.onmousedown = function(e) {
      e.preventDefault();
      container.classList.toggle("vk-open");
    };
    triggerBtn.onclick = function(e) {
      e.preventDefault();
    };
    document.body.appendChild(triggerBtn);
  }

  function trackFocus() {
    document.addEventListener("focusin", function(e) {
      var el = e.target;
      if (el.tagName === "TEXTAREA" || el.tagName === "INPUT" || el.isContentEditable) {
        lastFocused = el;
      }
    }, true);
  }

  function injectStyles() {
    var style = document.createElement("style");
    style.textContent = "#virtual-keyboard-root{position:fixed;bottom:0;left:0;right:0;background:#1a1a1a;border-top:1px solid #333;z-index:9999;transform:translateY(100%);transition:transform 0.2s;padding:0;max-height:45vh;overflow:auto}#virtual-keyboard-root.vk-open{transform:translateY(0)}.vk-panel{display:flex;flex-direction:column;gap:0}.vk-header{display:flex;justify-content:flex-end;padding:6px 8px;background:#252525;border-bottom:1px solid #333}.vk-close{width:36px;height:36px;font-size:18px;line-height:1;background:#333;color:#eee;border:1px solid #444;cursor:pointer;padding:0}.vk-close:hover{background:#e55;border-color:#f66;color:#fff}.vk-keys{display:flex;flex-direction:column;gap:4px;max-width:960px;margin:0 auto;padding:8px}.vk-row{display:flex;gap:4px;justify-content:center;flex-wrap:nowrap}.vk-key{min-width:34px;height:40px;padding:0 8px;font-size:15px;background:#333;color:#eee;border:1px solid #444;cursor:pointer;font-family:Arial,sans-serif;flex:0 0 auto}.vk-key:hover{background:#444;color:#fff}.vk-key:active{background:#555}.vk-key.vk-space{flex:1;min-width:120px}.vk-key.vk-special{min-width:44px;font-size:12px}.vk-trigger{position:fixed;bottom:12px;right:12px;width:44px;height:44px;font-size:20px;background:#333;color:#eee;border:1px solid #444;cursor:pointer;z-index:9998;border-radius:0}.vk-trigger:hover{background:#4a7;border-color:#5b8;color:#fff}.vk-key,.vk-trigger,.vk-close{-webkit-touch-callout:none;-webkit-user-select:none;user-select:none;touch-action:manipulation}#virtual-keyboard-root{touch-action:manipulation}";
    document.head.appendChild(style);
  }

  function init(opts) {
    opts = opts || {};
    if (document.getElementById("virtual-keyboard-root")) return;
    injectStyles();
    trackFocus();
    createKeyboard();
    createTrigger();
  }

  global.VirtualKeyboard = { init: init };
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", function() { init(); });
  } else {
    init();
  }
})(typeof window !== "undefined" ? window : this);
