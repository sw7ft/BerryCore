#!/bin/sh
# Example: show first JPEG found on SD card
export PATH=/accounts/1000/shared/misc/chafa/bin:$PATH
export TERM="${TERM:-xterm-256color}"

PHOTO=$(find /accounts/1000/removable/sdcard /accounts/1000/r -name '*.jpg' 2>/dev/null | head -1)

if [ -z "$PHOTO" ]; then
  echo "No .jpg found on SD card. Try:" >&2
  echo "  chafa-show -w 48 /path/to/your/photo.jpg" >&2
  exit 1
fi

echo "Showing: $PHOTO" >&2
exec chafa-show -w 48 -f symbols "$PHOTO"
