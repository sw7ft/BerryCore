# Term49-Web - QNX Web Terminal

**Browser-based terminal for BlackBerry QNX**

Access your QNX shell from any browser using xterm.js!

## Features

- 🌐 **Web-based** - Access terminal from any browser
- 📱 **BB10 Compatible** - Works on BlackBerry Passport browser
- 🖥️  **Multiple Sessions** - Open multiple terminal tabs
- ⚡ **Lightweight** - Only 9.5KB binary + 450KB assets
- 🔒 **Local Access** - Runs on localhost by default
- 🎨 **Modern Terminal** - xterm.js with 256 colors

## Installation

### Via BerryCore (Recommended)
```bash
qpkg install term49-web
```

### Manual Installation
```bash
# Extract package
tar xzf net-term49-web-1.0.tar.gz -C ~/

# Add to PATH
export PATH="$HOME/bin:$PATH"
```

## Usage

### Start the Server

```bash
# Default port 7681
term49-web

# Custom port
term49-web -p 8080
```

### Access from Browser

**On the device:**
```
http://localhost:7681/
```

**From another device (same network):**
```
http://YOUR_DEVICE_IP:7681/
```

To find your IP:
```bash
ifconfig
```

### Keyboard Shortcuts

The terminal uses standard xterm keybindings:
- `Ctrl+C` - Interrupt
- `Ctrl+D` - EOF
- `Ctrl+L` - Clear screen
- `Tab` - Autocomplete
- Arrow keys - Navigation/history

### Stop the Server

Press `Ctrl+C` in the terminal running term49-web

## Examples

### Simple Usage
```bash
$ term49-web
QNX Web Terminal Server
=======================
Server listening on port 7681
Open http://localhost:7681/ in your browser
```

Then open your browser and navigate to the URL!

### Custom Port
```bash
$ term49-web -p 9000
Server listening on port 9000
```

### Background Mode
```bash
$ term49-web &
[1] 12345
$ # Server runs in background
```

## Browser Compatibility

### Tested Browsers
- ✅ **BlackBerry 10 Browser** (Passport)
- ✅ Chrome/Chromium
- ✅ Firefox
- ✅ Safari
- ✅ Edge

### Requirements
- WebSocket support
- ES5 JavaScript
- Basic CSS support

## Technical Details

### Architecture
```
Browser ←→ WebSocket ←→ PTY ←→ Shell
(xterm.js)     (C)     (BSD)  (bash)
```

### Components
- **Frontend**: xterm.js v3.14.5 (ES5-compatible)
- **Backend**: Custom C WebSocket server
- **PTY**: BSD-style (/dev/ptyp*) from tmux port
- **Shell**: BerryCore bash or /bin/sh

### Network Details
- Protocol: WebSocket (RFC 6455)
- Default Port: 7681
- Max Connections: 10 simultaneous

## Configuration

### Environment Variables

```bash
# Set default shell
export SHELL=/path/to/your/shell

# Custom port
term49-web -p 8080
```

### WWW Root

The server looks for web assets in `./www/` relative to the binary.

Default structure:
```
bin/
  term49-web
www/
  index.html
  js/
    xterm.js
    fit.js
  css/
    xterm.css
```

## Security Notes

⚠️ **Important Security Information**

1. **No Authentication** - Anyone who can access the port can access your shell
2. **HTTP Only** - No HTTPS/TLS support (traffic is unencrypted)
3. **Local Use** - Designed for localhost access
4. **Firewall** - Block port 7681 from external access

### Recommended Usage

**Safe:**
```bash
# Local access only
term49-web
# Access from: http://localhost:7681/
```

**Risky:**
```bash
# Accessible from network
term49-web
# Access from: http://192.168.1.x:7681/
# ⚠️ Anyone on your network can access!
```

### Production Use

For remote/production use, consider:
- Use SSH tunneling instead
- Add authentication layer
- Use HTTPS/TLS proxy
- Restrict by IP address

## Troubleshooting

### Server won't start
```bash
# Check if port is in use
netstat -an | grep 7681

# Try different port
term49-web -p 8080
```

### Can't connect from browser
```bash
# Check server is running
ps | grep term49-web

# Check firewall
# (QNX firewall configuration)
```

### Terminal not displaying
- Refresh the browser page
- Check browser console for errors
- Try different browser

### Shell exits immediately
- Check SHELL environment variable
- Verify bash is at `/accounts/1000/shared/misc/berrycore/bin/bash`
- Try: `export SHELL=/bin/sh`

## FAQ

### Q: Can I access this from my phone?
**A:** Yes! If on the same network, use `http://DEVICE_IP:7681/`

### Q: Does it work on BB10 browser?
**A:** Yes! That's the primary target. Uses xterm.js v3.14.5 for ES5 compatibility.

### Q: Can I run multiple instances?
**A:** Yes, use different ports: `term49-web -p 8000`, `term49-web -p 8001`

### Q: How many terminals can I open?
**A:** Up to 10 simultaneous WebSocket connections.

### Q: Does it support colors?
**A:** Yes! Full 256-color support with xterm-256color.

### Q: Can I copy/paste?
**A:** Depends on browser. Most modern browsers support it.

## Integration

### With BerryCore

Add to startup script:
```bash
# In ~/.profile or startup script
term49-web -p 7681 &
```

### With tmux

Use both together!
```bash
# Start web terminal
term49-web &

# Start tmux
tmux
```

Access shell via browser OR tmux!

## Uninstallation

### BerryCore
```bash
qpkg remove term49-web
```

### Manual
```bash
rm ~/bin/term49-web
rm -rf ~/www
```

## Credits

- **xterm.js**: https://xtermjs.org/
- **tmux PTY code**: BSD-style PTY implementation
- **BerryCore**: https://github.com/sw7ft/BerryCore

## License

MIT License

## Version

1.0 - October 2025

---

**Enjoy your web-based terminal on QNX!** 🚀


