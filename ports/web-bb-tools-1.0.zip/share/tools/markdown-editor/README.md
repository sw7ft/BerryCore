# Markdown Editor – BB10

Browser-based markdown viewer and editor. ES5-only, no build step.

## Features

- **Edit** – Write markdown in a textarea
- **Preview** – Rendered HTML output
- **Split** – Edit and preview side by side
- **Save** – localStorage + download .md file
- **Open** – Load from .md file
- **New** / **Clear** – Start fresh
- **☰ Menu** – Hamburger dropdown with markdown shortcuts (headers, bold, italic, lists, links, code blocks, etc.)

## Supported Markdown

- Headers: `# ## ###`
- Bold: `**text**`
- Italic: `*text*`
- Links: `[text](url)`
- Code: `` `inline` `` and ` ``` ` blocks
- Lists: `- item` and `1. item`
- Blockquotes: `> quote`

## Usage

```bash
# Serve on port 8766 (drawing board on 8765)
python3 -m http.server 8766
# Open http://localhost:8766/tools/markdown-editor/
```

## BB10 / ES5

- Pure ES5, no dependencies
- Touch and mouse supported
- Works in BB10 WebKit browser
