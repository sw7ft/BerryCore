# bdk-cli for BB10

Bitcoin Dev Kit command-line wallet (testnet-first). Syncs via Electrum over TLS.
OpenSSL is linked statically; wallet DB uses embedded SQLite.

**Experimental** — use testnet only; do not store mainnet funds on-device.

## Requires

- Network access (Wi‑Fi)
- CA bundle for TLS (BerryCore `cacert` package):
  `/accounts/1000/shared/misc/berrycore/certs/cacert.pem`

## Setup

```bash
export PATH=/accounts/1000/shared/misc/bdk-cli/bin:$PATH
export DATADIR=/accounts/1000/shared/misc/bdk-cli/data
export SSL_CERT_FILE=/accounts/1000/shared/misc/berrycore/certs/cacert.pem
mkdir -p "$DATADIR"
```

## Quick start (testnet)

```bash
# Generate keys (save output securely)
bdk-cli key generate

# Derive account xpub (replace XPRV)
bdk-cli -n testnet key derive --xprv 'tprv...' --path "m/84'/1'/0'"

# Check balance / sync (replace descriptor)
bdk-cli -n testnet wallet -w mywallet \
  -e "wpkh([fp/84'/1'/0']tpub.../*)" \
  --client-type electrum --database-type sqlite \
  --url "ssl://electrum.blockstream.info:60002" \
  sync

bdk-cli -n testnet wallet -w mywallet \
  -e "wpkh([fp/84'/1'/0']tpub.../*)" \
  --client-type electrum --database-type sqlite \
  --url "ssl://electrum.blockstream.info:60002" \
  new_address
```

## Install path

`/accounts/1000/shared/misc/bdk-cli/bin/bdk-cli`
