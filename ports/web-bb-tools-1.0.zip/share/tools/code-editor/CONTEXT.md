# Code Editor – App Builder Context

Browser-only code editor with syntax highlighting for BB10. Single-file HTML, ES5-only, no build step.

## Overview

- **Path:** `tools/code-editor/index.html`
- **Target:** BB10 WebKit (touch + mouse)
- **Storage:** localStorage + file export/import (.js, .json, .html, .css, .sh, .txt)

## View Modes

| Mode    | Layout                          |
|---------|----------------------------------|
| Edit    | Textarea only (with line numbers) |
| Preview | Syntax-highlighted output (with line numbers) |
| Split   | Textarea left, highlighted right (both with line numbers) |

Line numbers sync with scroll in both editor and preview panes.

## Toolbar Structure

```
[Edit] [Preview] [Split] [Save] [Open] [New] [Clear] ............ [☰]
```

- **Edit / Preview / Split:** Toggle view layout
- **Save:** localStorage + download (extension from language)
- **Open:** Load from file; language auto-detected from extension
- **New / Clear:** Start fresh
- **☰:** Hamburger menu – Language selector + code snippets

## ☰ Menu

| Section   | Options                                                                 |
|-----------|-------------------------------------------------------------------------|
| Language  | JavaScript, Python, JSON, HTML, CSS, Shell, Plain                      |
| Snippets  | function, if/else, for loop, try/catch, switch, // comment, /* block */ |

Language sets highlighting mode and save extension. Snippets insert at cursor/line.

## Syntax Highlighting

Regex-based highlighters (no deps). Span classes: `.kw` (keyword), `.str` (string), `.com` (comment), `.num` (number), `.tag` (HTML tag / CSS selector), `.attr` (attribute), `.pun` (punctuation).

| Lang     | Highlights                                              |
|----------|---------------------------------------------------------|
| JavaScript | keywords, strings, comments, numbers                    |
| Python   | keywords, strings, comments, numbers, decorators       |
| JSON     | keys, strings, true/false/null, numbers                 |
| HTML     | tags, attributes, comments, strings                     |
| CSS      | selectors, properties, values, comments, numbers        |
| Shell    | keywords, comments, strings, $vars                      |
| Plain    | No highlighting                                         |

## Key Functions

| Function           | Purpose                                      |
|--------------------|----------------------------------------------|
| `updateLineNumbers()` | Update editor line numbers; sync scroll     |
| `render()`         | Highlight editor value → preview; update preview line numbers |
| `highlight(lang, text)` | Parse and wrap spans by language         |
| `setLang(lang)`| Set current language, persist, re-render     |
| `insertSnippet(key)` | Insert snippet at cursor/line            |
| `doSave()`     | localStorage + download                      |
| `doLoad()`     | Restore from localStorage on init            |
| `setView(mode)`| Edit / Preview / Split                       |
| `getExt()`     | File extension for current language          |

## Storage

- **localStorage** keys: `code-editor-data`, `code-editor-lang`
- **Save:** Writes to localStorage + downloads `document.{js|json|html|css|sh|txt}`
- **Open:** File input accepts .js, .json, .html, .css, .sh, .txt; language inferred from extension

## Snippets

| Key     | Inserts                                           |
|---------|---------------------------------------------------|
| function| `function name() { }` (cursor at "name")          |
| if      | `if () { } else { }`                              |
| for     | `for (var i = 0; i < n; i++) { }`                |
| try     | `try { } catch (e) { }`                            |
| switch  | `switch () { case : break; default: }`            |
| comment | `// `                                             |
| block   | `/*  */` (cursor between)                         |

## UI Elements

- `#editor`: Main textarea
- `#line-numbers`: Editor pane line numbers (scroll-synced)
- `#preview-line-numbers`: Preview pane line numbers (scroll-synced)
- `#preview-content`: Syntax-highlighted HTML (read-only)
- `#editor-pane` / `#preview-pane`: Flex panes; `.hidden` toggles visibility
- `#file-input`: Hidden file input for Open
- `#save-toast`: "Saved!" feedback

## Indentation

- **Tab:** Inserts 4 spaces (no tab character)
- **Enter:** Smart indent – copies leading whitespace from current line; for Python, adds one level after lines ending with `:`
- **Save/Load:** Raw content preserved; spaces and tabs kept as-is

## ES5 Constraints

- `var` only (no `let`/`const`)
- `function () {}` (no arrows)
- String concatenation (no template literals)
- No classes
- `slice(-n)` for `endsWith`-style checks
