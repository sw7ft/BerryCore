# WiFi Chat Port — P2P Chat over Local Network

Peer-to-peer chat over WiFi/local network. Discovers devices via UDP broadcast, sends messages via TCP.

## Overview

| Item | Value |
|------|-------|
| **Port** | wifi-chat |
| **Category** | util |
| **Binary** | bin/wifi-chat |
| **Protocol** | UDP 9876 (discovery), TCP 9877 (chat) |

## Build

```bash
cd /root/ports/messenger
./build-messenger.sh
```

Output: `output/bin/wifi-chat`

## Usage

```bash
wifi-chat [-p port] [name]
```

- `-p port` — chat port (default 9877; discovery = port-1)
- `name` — optional display name (default: hostname)

### Commands

| Command | Description |
|---------|-------------|
| `p`, `peers` | List discovered peers |
| `s N msg` | Send message to peer N |
| `s name msg` | Send message to peer by name |
| `b`, `broadcast` | Send message to all peers |
| `r`, `refresh` | Force immediate peer scan |
| `c`, `clear` | Clear screen |
| `i`, `info` | Show our name, IP, port |
| `h`, `help` | Show help |
| `q`, `quit` | Exit |

### Example

```
$ wifi-chat alice
WiFi Chat - alice @ 192.168.1.42:9877
Type 'h' for help, 'q' to quit.

> p
Peers:
  1. bob (192.168.1.43:9877) - seen 1s ago

> s 1 Hello from alice!
Sent to bob.

> b Hey everyone!
Broadcast to 2 peer(s): 2 sent, 0 failed.

> i
You: alice
IP:  192.168.1.42
Port: 9877 (discovery: 9876)

> q
Bye.
```

## Protocol

- **Discovery (UDP)**: Broadcasts `LANMSG|1|name|ip|port` every 3 seconds
- **Chat (TCP)**: Connects, sends `sender\nmessage\n`, closes
- **Received messages**: Displayed with timestamp `[HH:MM:SS] sender: message`

## Requirements

- Devices on same LAN/subnet
- UDP broadcast allowed (typical for home/office WiFi)
- Ports 9876 (UDP) and 9877 (TCP) free (or use `-p` for alternate)

## QNX Notes

- Uses `getifaddrs()` for local IP when available; falls back to connect+getsockname
- `_QNX_SOURCE` defined for QNX builds
- No external dependencies beyond libc and POSIX sockets
