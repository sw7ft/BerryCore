# Virtual Keyboard – BB10

ES5-compatible virtual keyboard. Reusable across apps.

## Features

- Full QWERTY layout (letters, numbers, symbols)
- Shift, Caps Lock
- Tab, Enter, Backspace, Space
- Trigger button (⌨) in bottom right
- Works with textarea, input, contenteditable

## Include in Your App

```html
<script src="path/to/keyboard.js"></script>
```

Auto-inits on load. Adds a ⌨ button (bottom right). Click to show/hide the keyboard.

## Usage

1. Focus a textarea or input
2. Click the ⌨ button
3. Type with the virtual keyboard

## Standalone Demo

```bash
# Serve and open
python3 -m http.server 8768
# http://localhost:8768/tools/virtual-keyboard/
```

## Included In

- Code Editor
- Markdown Editor

## ES5

- Pure ES5, no dependencies
- Touch and mouse supported
